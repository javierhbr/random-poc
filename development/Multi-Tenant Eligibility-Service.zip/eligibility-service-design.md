# Multi-Tenant Eligibility Service — Design

**Status:** Draft for review
**Scope:** Conceptual architecture. No implementation code.

---

## 1. Problem statement

Multiple platforms (tenants) need to answer one question: *is this customer eligible?*

Today that logic is duplicated or scattered. We want a single service where:

- The **evaluation process** is identical for every tenant — same steps, same order, same decision semantics.
- The **rules** differ per tenant, expressed as versioned configuration rather than code.
- The **feature domain is fixed**: five groups of customer/account characteristics, sourced from four downstream services.
- Downstream calls are **minimized** — a tenant only calls what its active rules actually need.
- A tenant with genuinely exceptional logic can be accommodated **without contaminating the core**.

### Goals

| Goal | Success looks like |
|---|---|
| One engine, many tenants | Adding a tenant = adding a YAML file, not a deployment of new logic |
| Predictable decisions | Same input + same ruleset version ⇒ same output, always |
| Downstream efficiency | A tenant using 2 feature groups never calls the other providers |
| Auditability | Any past decision can be explained: which rules ran, which version, what data |
| Safe change | Rules can be modified and rolled back without a code release |

### Non-goals

- Not a general-purpose rules engine (no arbitrary expression language, no Turing-complete DSL).
- Not a data store — the service owns no customer data, it orchestrates reads.
- Not a workflow engine — evaluation is a single synchronous request/response.

---

## 2. Core concepts

The whole design rests on five nouns. Getting these right is most of the work.

| Concept | Definition |
|---|---|
| **Subject** | Who we are evaluating. Identified by a `SubjectRef` = `(idType, idValue)`. `idType` varies per tenant (account ID, customer ID, other); the rest of the system only sees the normalized ref. |
| **Feature** | One atomic, typed, named fact about the subject. E.g. `customer.type : Enum<CustomerType>`, `account.openedAt : Date`. Features live in a global **Feature Catalog**, organized into the five groups. |
| **Provider** | An adapter over one downstream service. Declares which features it produces. Protocol (REST, GraphQL) is an implementation detail hidden behind the port. |
| **Rule** | A named predicate over one or more features, producing `PASS` / `FAIL` / `NO_DATA`. Either declarative (feature + operator + value) or a registered named predicate. |
| **Ruleset** | An ordered, immutable, versioned list of rules for one tenant, plus policy settings. This is the YAML file. |

**Critical invariant:** every rule declares the features it consumes, and every feature is produced by exactly one provider. This declared dependency chain is what makes the planner possible — it is not documentation, it is executable metadata.

```
Rule ──consumes──▶ Feature ──produced by──▶ Provider ──calls──▶ Downstream
```

---

## 3. Architecture

Hexagonal (ports & adapters). The core knows nothing about HTTP, YAML, GraphQL, or any specific tenant.

```mermaid
graph TB
    subgraph INBOUND[" "]
        API["Eligibility API<br/><i>single contract, all tenants</i>"]
    end

    subgraph CORE["EVALUATION CORE — identical for every tenant"]
        RES["Resolver<br/><small>request → SubjectRef</small>"]
        PLAN["Planner<br/><small>rules → features → providers → tiers</small>"]
        ORCH["Fetch Orchestrator<br/><small>tiered, parallel, timeouts</small>"]
        NORM["Feature Assembler<br/><small>raw payloads → typed features</small>"]
        EVAL["Rule Evaluator<br/><small>ordered, short-circuit</small>"]
        RESP["Decision Builder<br/><small>outcome + reasons + trace</small>"]
    end

    subgraph PORTS["PORTS"]
        P1["«port»<br/>FeatureProvider"]
        P2["«port»<br/>RulesetRepository"]
        P3["«port»<br/>Predicate"]
        P4["«port»<br/>DecisionSink"]
    end

    subgraph ADAPTERS["ADAPTERS — where variability lives"]
        A1["REST adapters<br/>svc A, B, C"]
        A2["GraphQL adapter<br/>svc D"]
        A3["YAML loader<br/>+ schema validator"]
        A4["Custom predicates<br/><small>acme/*, globex/*</small>"]
        A5["Audit log / events"]
    end

    API --> RES --> PLAN --> ORCH --> NORM --> EVAL --> RESP
    PLAN -.reads.-> P2
    ORCH --> P1
    EVAL --> P3
    RESP --> P4

    P1 --> A1
    P1 --> A2
    P2 --> A3
    P3 --> A4
    P4 --> A5

    style CORE fill:#eef4ff,stroke:#3b6ea5,stroke-width:2px
    style PORTS fill:#f7f3e8,stroke:#a58b3b
    style ADAPTERS fill:#f0f0f0,stroke:#888
```

**Reading the diagram:** everything in the blue box is written once and never changes when a tenant is added. Everything tenant-specific enters through the yellow ports — as configuration (`RulesetRepository`) or as registered extensions (`Predicate`).

---

## 4. Evaluation pipeline

Six stages, fixed order, no tenant may reorder or skip them.

```mermaid
flowchart LR
    A["1. RESOLVE<br/><small>normalize identity</small>"] --> B["2. PLAN<br/><small>what do we need?</small>"]
    B --> C["3. FETCH<br/><small>tier by tier</small>"]
    C --> D["4. ASSEMBLE<br/><small>typed features</small>"]
    D --> E["5. EVALUATE<br/><small>rules in order</small>"]
    E -->|"more tiers &<br/>still undecided"| C
    E --> F["6. DECIDE<br/><small>outcome + trace</small>"]

    style A fill:#e8f0fe
    style B fill:#e8f0fe
    style C fill:#fff0e0
    style D fill:#e8f0fe
    style E fill:#fff0e0
    style F fill:#e8f5e9
```

| Stage | Responsibility | Tenant-variable? |
|---|---|---|
| 1. Resolve | Validate request, extract `SubjectRef` using the tenant's declared `idType` | Config only (which `idType`) |
| 2. Plan | Load active ruleset, compute feature closure, map to providers, group into tiers | Derived — never hand-written |
| 3. Fetch | Call providers of the current tier in parallel, apply timeouts, circuit breakers, cache | No |
| 4. Assemble | Map raw responses into typed features; mark missing ones as `NO_DATA` | Adapter-level only |
| 5. Evaluate | Run rules in declared order, short-circuit on first terminal result | Config (which rules, what order) |
| 6. Decide | Build response: outcome, reasons, ruleset version, trace ID | No |

---

## 5. The Planner — minimizing downstream load

This is the mechanism that satisfies *"only call the downstreams that are required."*

It is **derived**, never configured. A tenant never writes "I use services A and C." Stating downstreams by hand creates a second source of truth that silently drifts from the rules — the classic bug this design exists to prevent.

```mermaid
flowchart TB
    subgraph L1["Active ruleset — ordered"]
        R1["R1 · customer type"]
        R2["R2 · account status"]
        R3["R3 · account age"]
        R4["R4 · risk flags"]
    end

    subgraph L2["Feature closure"]
        F1["customer.type"]
        F2["account.status"]
        F3["account.openedAt"]
        F4["risk.flags"]
    end

    subgraph L3["Providers"]
        PA["Provider A<br/><small>Customer svc · REST</small>"]
        PB["Provider B<br/><small>Account svc · REST</small>"]
        PC["Provider C<br/><small>Risk svc · GraphQL</small>"]
        PD["Provider D<br/><small>Product svc · REST</small>"]
    end

    R1 --> F1 --> PA
    R2 --> F2 --> PB
    R3 --> F3 --> PB
    R4 --> F4 --> PC

    PD -.->|"no active rule<br/>consumes its features<br/><b>NOT CALLED</b>"| X[" "]

    style PD fill:#f5f5f5,stroke-dasharray: 5 5,color:#999
    style X fill:none,stroke:none
```

### Tiering

Because the policy is **deny-fast**, fetching everything up front wastes calls: if rule 1 fails, we already paid for four requests. The planner therefore assigns each provider to the **earliest tier in which one of its features is first needed**:

```mermaid
flowchart LR
    T0["TIER 0<br/>Provider A, B<br/><small>rules 1–3</small>"] --> E0{"decided?"}
    E0 -->|"DENY / INDETERMINATE"| STOP["return<br/><small>Tier 1 never called</small>"]
    E0 -->|"all passed"| T1["TIER 1<br/>Provider C<br/><small>rule 4</small>"]
    T1 --> E1{"decided?"}
    E1 -->|no more rules| OK["ELIGIBLE"]
    E1 -->|"terminal"| STOP2["return"]

    style STOP fill:#ffe0e0
    style STOP2 fill:#ffe0e0
    style OK fill:#e0f5e0
```

Within a tier: **parallel**. Between tiers: **sequential**. Fewer tiers = lower latency; more tiers = fewer wasted calls. The tenant tunes this simply by ordering rules — cheap, high-selectivity rules first.

**Design consequence to accept:** rule order is now both a *semantic* choice (which reason wins) and a *performance* choice (how many calls). This is intentional and should be documented for tenant owners, not hidden.

---

## 6. Decision semantics

Three outcomes. Two short-circuit conditions. One precedence rule.

```mermaid
stateDiagram-v2
    [*] --> Evaluating
    Evaluating --> Evaluating: rule PASS → next rule
    Evaluating --> DENY: rule FAIL
    Evaluating --> INDETERMINATE: required feature NO_DATA<br/>(provider failed/timeout)
    Evaluating --> ELIGIBLE: all rules passed
    DENY --> [*]
    INDETERMINATE --> [*]
    ELIGIBLE --> [*]
```

| Outcome | Meaning | Caller guidance |
|---|---|---|
| `ELIGIBLE` | Every rule passed | Proceed |
| `DENY` | A rule failed on real data | Business decision — final, safe to cache |
| `INDETERMINATE` | Could not be determined; data unavailable | **Not a denial.** Retry or degrade — never present as a rejection to the customer |

### Precedence: first terminal result in declared order wins

If rule 1 fails and rule 3's provider is down, the answer is `DENY` — rule 3 is never reached.

The rejected alternative was "INDETERMINATE always dominates." It is more conservative but makes the outcome depend on *which downstream happened to be unhealthy that day*, so the same customer gets different answers on different days for reasons unrelated to their data. Deterministic ordering is far easier to explain to support and to test.

---

## 7. Configuration model

### Layout

```
config/
  schema/
    ruleset.schema.json          # versioned alongside the engine
    feature-catalog.yaml         # global: all features, types, domains, owning provider
  tenants/
    acme/
      v7.yaml                    # immutable once merged
      v7.cases.yaml              # golden tests
      v8.yaml
      v8.cases.yaml
    globex/
      v3.yaml
      v3.cases.yaml
  registry.yaml                  # tenant → active version  ← the only mutable file
```

Separating the **pin** (`registry.yaml`) from the **content** (`vN.yaml`) is what makes rollback a one-line change with a full audit trail in version control.

### Ruleset shape (conceptual)

```mermaid
classDiagram
    class Ruleset {
        schemaVersion
        tenant
        version
        subject.idType
        policy.mode = ALL_OF
        policy.onNoData = INDETERMINATE
        rules[] ordered
    }
    class Rule {
        id  (unique)
        description
        consumes[]  features
    }
    class DeclarativeRule {
        feature
        operator
        value
    }
    class PredicateRule {
        predicateRef
        params
    }
    Ruleset "1" *-- "n" Rule
    Rule <|-- DeclarativeRule
    Rule <|-- PredicateRule
```

Two rule kinds, one contract. Both declare `consumes` so the planner works identically for either — a custom predicate does not get to bypass the dependency graph or fetch data on its own.

### Versioning rules

- A merged version file is **immutable**. Changes create `v(N+1)`.
- Store a **content hash** next to the version number to detect environment drift.
- Each tenant **pins independently** — a deployment never silently advances anyone's rules.
- Every response carries `rulesetVersion`; without it, past decisions are unexplainable.

---

### Worked example

Four files, one scenario: tenant `acme`, ruleset `v8`. Together they show everything the engine reads.

**1 — Feature catalog** (global, shared by all tenants). The single source of truth for what exists, what type it is, and who produces it.

```yaml
schemaVersion: 1
features:
  # ── Group 1 · Customer identity & type ──────────────── provider: customer-svc
  - name: customer.status
    type: enum
    domain: [ACTIVE, DORMANT, CLOSED]
    provider: customer-svc
  - name: customer.type
    type: enum
    domain: [RETAIL, PREMIUM, BUSINESS, INTERNAL]
    provider: customer-svc
  - name: customer.residencyCountry
    type: string          # ISO 3166-1 alpha-2
    provider: customer-svc

  # ── Group 2 · Account type ───────────────────────────── provider: account-svc
  - name: account.productType
    type: enum
    domain: [CHECKING, SAVINGS, CREDIT, INVESTMENT]
    provider: account-svc

  # ── Group 3 · Account characteristics ────────────────── provider: account-svc
  - name: account.status
    type: enum
    domain: [OPEN, FROZEN, CLOSED]
    provider: account-svc
  - name: account.openedAt
    type: date
    provider: account-svc
  - name: account.balance
    type: money
    provider: account-svc

  # ── Group 4 · Holdings  (provisional — see §14 Q1) ───── provider: product-svc
  - name: holdings.activeProducts
    type: set<string>
    provider: product-svc

  # ── Group 5 · Risk & compliance (provisional) ────────── provider: risk-svc
  - name: risk.flags
    type: set<enum>
    domain: [SANCTIONS_HIT, FRAUD_HOLD, PEP, NONE]
    provider: risk-svc      # GraphQL
  - name: risk.kycLevel
    type: enum
    domain: [NONE, BASIC, FULL]
    provider: risk-svc
```

**2 — Tenant ruleset** (`config/tenants/acme/v8.yaml`). Immutable once merged.

```yaml
schemaVersion: 1
tenant: acme
version: 8

subject:
  idType: ACCOUNT_ID

policy:
  mode: ALL_OF
  onNoData: INDETERMINATE
  precedence: FIRST_TERMINAL_IN_ORDER   # see §6

# Order is significant: it decides which reason wins AND how many
# downstream calls a denial costs. Cheap + selective first.
rules:
  - id: customer-status-active
    description: Closed or dormant customers are never eligible.
    consumes: [customer.status]
    when: { feature: customer.status, op: EQUALS, value: ACTIVE }

  - id: customer-type-allowed
    description: Retail and premium only; business goes through another flow.
    consumes: [customer.type]
    when: { feature: customer.type, op: IN, value: [RETAIL, PREMIUM] }

  - id: account-open
    consumes: [account.status]
    when: { feature: account.status, op: EQUALS, value: OPEN }

  - id: account-seasoned
    description: Account must be at least 90 days old.
    consumes: [account.openedAt]
    when: { feature: account.openedAt, op: OLDER_THAN, value: P90D }

  - id: no-blocking-risk-flags
    consumes: [risk.flags]
    when:
      feature: risk.flags
      op: NOT_INTERSECTS
      value: [SANCTIONS_HIT, FRAUD_HOLD]

  # Escape hatch (§9 level 2): registered logic, referenced by name.
  # Still declares `consumes`, so the planner treats it like any other rule.
  - id: acme-legacy-migration
    description: Pre-2020 migrated cohort has bespoke product constraints.
    consumes: [account.productType, holdings.activeProducts]
    predicateRef: acme/legacyMigrationCheck
    params:
      cutoffCohort: "2019-Q4"
```

**3 — What the planner derives from it.** Nobody writes this; it is computed and printed in CI (§8, layer 3).

| Tier | Rules | Providers called | Note |
|---|---|---|---|
| 0 | `customer-status-active`, `customer-type-allowed` | `customer-svc` | Most denials stop here — one call |
| 1 | `account-open`, `account-seasoned` | `account-svc` | |
| 2 | `no-blocking-risk-flags` | `risk-svc` | GraphQL |
| 3 | `acme-legacy-migration` | `product-svc` | `account-svc` already fetched in tier 1 |

A fully eligible subject costs four calls; a customer-type denial costs one.

**4 — Version registry** (`config/registry.yaml`) — the only mutable file, and the rollback lever.

```yaml
schemaVersion: 1
pins:
  acme:
    version: 8
    hash: "sha256:9f2c1ab7…"
    since: "2026-08-04"
  globex:
    version: 3
    hash: "sha256:41ab08de…"
    since: "2026-06-19"

# Evaluated in parallel, logged only, never served (§12)
shadow:
  acme:
    candidate: 9
    sampleRate: 1.0
```

**5 — Golden cases** (`config/tenants/acme/v8.cases.yaml`). Runs in CI with no network.

```yaml
schemaVersion: 1
tenant: acme
rulesetVersion: 8
cases:
  - name: eligible retail customer
    given:
      customer.status: ACTIVE
      customer.type: RETAIL
      account.status: OPEN
      account.openedAt: "2024-01-15"
      risk.flags: []
      account.productType: CHECKING
      holdings.activeProducts: ["CHK-STD"]
    expect: { outcome: ELIGIBLE }

  - name: business customer denied on type
    given:
      customer.status: ACTIVE
      customer.type: BUSINESS
    expect: { outcome: DENY, decidingRule: customer-type-allowed }

  - name: risk service unavailable
    given:
      customer.status: ACTIVE
      customer.type: PREMIUM
      account.status: OPEN
      account.openedAt: "2019-03-02"
      risk.flags: NO_DATA
    expect: { outcome: INDETERMINATE, decidingRule: no-blocking-risk-flags }

  # Pins the precedence rule from §6: an earlier DENY beats a later NO_DATA.
  - name: deny outranks unavailable data
    given:
      customer.status: ACTIVE
      customer.type: BUSINESS
      risk.flags: NO_DATA
    expect: { outcome: DENY, decidingRule: customer-type-allowed }
```

That final case is the most valuable one in the file: it is the only thing preventing someone from "fixing" precedence later and silently changing every tenant's behaviour during a downstream outage.

---

## 8. Validation — three layers

Schema validation alone is not sufficient. Roughly half the ways a ruleset can be wrong are invisible to JSON Schema.

```mermaid
flowchart TB
    Y["ruleset.yaml"] --> V1

    subgraph V1["LAYER 1 · Structural — JSON Schema"]
        direction LR
        S1["required fields"]
        S2["types & enums"]
        S3["additionalProperties: false<br/><small>catches typos that would<br/>otherwise be ignored silently</small>"]
    end

    V1 --> V2

    subgraph V2["LAYER 2 · Semantic — needs catalog + registry"]
        direction LR
        M1["feature exists in catalog"]
        M2["predicateRef is registered"]
        M3["operator valid for feature type"]
        M4["literal within feature domain"]
        M5["rule IDs unique"]
        M6["idType supported by required providers"]
    end

    V2 --> V3

    subgraph V3["LAYER 3 · Structural dry-run — the Planner"]
        direction LR
        P1["dependency graph closes"]
        P2["every feature has a provider"]
        P3["emit tier plan + downstream impact"]
    end

    V3 --> OK["valid ✓"]

    style V1 fill:#e8f0fe
    style V2 fill:#fff4e0
    style V3 fill:#e8f5e9
```

### Where each layer runs

| Trigger | Layers | On failure |
|---|---|---|
| **CI on pull request** | 1, 2, 3 + golden tests | Block merge. *This is the real gate.* |
| **Service startup** | 1, 2, 3 on the active set | Refuse to start. Never boot on partially valid config. |
| **Hot reload** (if adopted) | 1, 2, 3 in memory | Keep previous ruleset, raise alert. Atomic swap only on full success. |

**Layer 3 side benefit:** the planner's dry-run output — "tenant acme v8 will call Customer and Account services, not Risk" — posted on the PR gives reviewers downstream impact analysis for free.

### Golden tests

Each `vN.cases.yaml` holds fixtures: feature inputs → expected outcome → expected deciding rule. They run in CI with no network. This is what turns "change a rule" from a risky operation into a routine one, and it doubles as living documentation of each rule's intent.

---

## 9. Extension points for exceptional tenants

Ordered from most preferred to least. Escalate only when the level above genuinely cannot express the requirement.

```mermaid
flowchart TB
    L1["<b>1 · Configuration</b><br/>different rules, order, thresholds<br/><small>covers the large majority</small>"]
    L2["<b>2 · Named predicate</b><br/>registered logic, namespaced per tenant<br/><small>same Rule contract, still declares consumes</small>"]
    L3["<b>3 · Custom provider</b><br/>tenant-specific data source behind<br/>the standard FeatureProvider port"]
    L4["<b>4 · Tenant hook</b><br/>preFetch / postDecision, no-op by default<br/><small>build only when a real case demands it</small>"]

    L1 --> L2 --> L3 --> L4

    style L1 fill:#e0f2e0
    style L2 fill:#f0f5d0
    style L3 fill:#fdf0d5
    style L4 fill:#fadbd8
```

The rule that protects the core: **no `if (tenant == "acme")` anywhere in the pipeline.** Tenant-specific behavior is always registered under a name and referenced from that tenant's configuration. It stays isolated, independently testable, and greppable.

---

## 10. Contracts

### Request (identical across tenants)

| Field | Notes |
|---|---|
| `tenantId` | Selects the ruleset; may also come from auth context |
| `subject.idType` | Must match the tenant's declared type |
| `subject.idValue` | The identifier |
| `context` | Optional, tenant-agnostic evaluation context (channel, timestamp) |

### Response (identical across tenants)

| Field | Purpose |
|---|---|
| `outcome` | `ELIGIBLE` / `DENY` / `INDETERMINATE` |
| `reasons[]` | Rule IDs with result — the deciding rule first |
| `rulesetVersion` | Tenant version + content hash |
| `decisionId` | Correlation key for audit |
| `evaluatedAt` | Timestamp |
| `trace` | Optional/debug: rules evaluated, providers called, latencies |

Reason codes should be **stable rule IDs**, not prose. Callers will build UI on them, so treat them as part of the public contract and version them accordingly.

---

## 11. Cross-cutting concerns

| Concern | Approach |
|---|---|
| **Timeouts** | Per provider, plus a global evaluation budget. Exhausted budget ⇒ `INDETERMINATE`, never a hung request. |
| **Circuit breakers** | Per provider *and per tenant*, so one tenant's traffic spike cannot open a breaker that starves the others. |
| **Caching** | Cache at the **feature** layer, not the decision layer. Decisions depend on ruleset version and would be invalidated by every config change; features have natural, data-driven TTLs. |
| **Idempotency** | Evaluation is a pure function of (features, ruleset). Safe to retry. |
| **Observability** | Metrics by tenant × outcome × deciding rule. A spike in `INDETERMINATE` is a downstream health alarm; a shift in deciding-rule distribution signals a data or rule change. |
| **Audit** | Emit every decision to `DecisionSink` with inputs referenced (not necessarily copied — mind PII retention policy). |
| **Isolation** | Bulkhead thread pools / concurrency limits per provider so a slow downstream degrades one tier, not the whole service. |

---

## 12. Rollout of rule changes

```mermaid
flowchart LR
    A["author v8<br/><small>+ golden cases</small>"] --> B["CI validates<br/><small>3 layers + cases</small>"]
    B --> C["merge<br/><small>v8 exists, inactive</small>"]
    C --> D["shadow mode<br/><small>evaluate v7 & v8,<br/>log diffs, serve v7</small>"]
    D --> E{"diffs<br/>expected?"}
    E -->|no| A
    E -->|yes| F["pin acme → v8<br/><small>one-line change</small>"]
    F --> G["monitor<br/><small>outcome mix by rule</small>"]
    G -->|regression| H["repin → v7<br/><small>instant rollback</small>"]

    style D fill:#fff4e0
    style H fill:#ffe0e0
```

Shadow mode is what makes rule changes psychologically safe: you see the real-traffic delta before anything is served. It requires the evaluator to be side-effect free — another reason the core does no writes.

---

## 13. Onboarding

The design succeeds only if both onboarding paths are **pull requests, not projects**. This section defines what each one requires and where it can go wrong.

### 13.1 Onboarding a new tenant

Everything hinges on one early question: does this tenant need anything the platform does not already have? Answering it first separates a config-only onboarding (days) from one that requires an engine release (weeks).

```mermaid
flowchart TB
    START["New tenant request"] --> INTAKE["Rule intake<br/><small>business rules in plain language</small>"]
    INTAKE --> Q1{"Every rule maps to<br/>an existing catalog feature?"}

    Q1 -->|No| CODE["<b>Type C path</b><br/>extend catalog / add provider<br/>or register a predicate<br/><small>engine release required</small>"]
    CODE --> Q2

    Q1 -->|Yes| Q2{"idType supported by<br/>all required providers?"}
    Q2 -->|No| IDENT["Identity resolution needed<br/><small>most common blocker</small>"]
    IDENT --> Q2

    Q2 -->|Yes| AUTH["Author v1.yaml<br/><small>from tenants/_template/</small>"]
    AUTH --> CASES["Author v1.cases.yaml<br/><small>≥1 case per outcome,<br/>including INDETERMINATE</small>"]
    CASES --> CI["CI: 3 validation layers<br/>+ golden cases"]
    CI --> IMPACT["Planner dry-run on the PR<br/><small>which downstreams, expected<br/>calls per evaluation</small>"]
    IMPACT --> CAP{"Downstream owners<br/>approve added load?"}
    CAP -->|No| AUTH
    CAP -->|Yes| MERGE["Merge · pin tenant → v1"]
    MERGE --> DARK["Dark launch<br/><small>pinned but callers not routed,<br/>or shadow traffic only</small>"]
    DARK --> MON{"Outcome distribution<br/>as expected?"}
    MON -->|No| AUTH
    MON -->|Yes| LIVE["Route live traffic"]

    style CODE fill:#fadbd8
    style IDENT fill:#fdf0d5
    style IMPACT fill:#fff4e0
    style LIVE fill:#e0f2e0
```

**Checklist**

| # | Step | Gate |
|---|---|---|
| 1 | Identity | `idType` accepted by every provider the rules will need |
| 2 | Rule intake | Each rule maps to a catalog feature, or is escalated to Type C |
| 3 | Author `v1.yaml` | Rules ordered cheap-and-selective first (see §5, §6) |
| 4 | Author `v1.cases.yaml` | At least one case per outcome, `INDETERMINATE` included |
| 5 | Impact review | Planner dry-run posted on the PR; downstream owners sign off |
| 6 | Dark launch | Outcome mix reviewed before real traffic is routed |

A `tenants/_template/` directory containing a skeleton ruleset and case file makes steps 3–4 mechanical rather than creative.

> **Capacity is the non-obvious gate.** A new tenant is new load on shared downstreams. The planner states precisely which providers are activated and the expected calls per evaluation — make that a required section of the onboarding PR, not an afterthought.

### 13.2 Onboarding a new policy

Classify the change first. The three types carry very different risk and lead time, and misclassification is the main failure mode.

```mermaid
flowchart TB
    CH["Policy change requested"] --> C1{"Needs a feature not in<br/>the catalog, a new provider,<br/>or new custom logic?"}
    C1 -->|Yes| TC["<b>TYPE C</b><br/>catalog + code + release<br/><small>weeks</small>"]
    C1 -->|No| C2{"Uses a catalog feature this<br/>tenant does not use today?"}
    C2 -->|Yes| TB["<b>TYPE B</b><br/>config PR — but <b>activates a<br/>downstream call</b><br/><small>hours + capacity check</small>"]
    C2 -->|No| TA["<b>TYPE A</b><br/>thresholds, order,<br/>enable/disable<br/><small>hours</small>"]

    TA --> FLOW
    TB --> FLOW
    TC --> FLOW["Standard rollout — §12"]

    style TA fill:#e0f2e0
    style TB fill:#fff4e0
    style TC fill:#fadbd8
```

| Type | What changed | Requires | Lead time |
|---|---|---|---|
| **A** | Thresholds, rule order, enable/disable | Config PR | Hours |
| **B** | New rule using a catalog feature not yet used by this tenant | Config PR **+ capacity check** | Hours |
| **C** | New feature, new provider, or new custom predicate | Catalog change, code, engine release | Weeks |

**Type B is the one that bites.** It looks like an ordinary config edit but silently activates a provider that this tenant has never called. The planner diff on the pull request is what surfaces it — which is why the dry-run belongs in CI output, not in a runbook.

Once classified, all three follow the same rollout defined in §12: author `vN+1` → CI → merge inactive → shadow against `vN` → repin → monitor → repin back on regression.

**Two guardrails worth enforcing mechanically:**

1. **Diff budget in shadow mode.** If a change labelled "minor" flips more than an agreed percentage of decisions, block the promotion and require explicit sign-off. This catches the transposed threshold and the inverted operator.
2. **No version skipping in production.** Tenants advance one version at a time, so any regression maps to exactly one change and rollback is unambiguous.

---

## 14. Open questions to close before building

1. **The five feature groups.** Three are known (customer type, account type, account characteristics). Defining the remaining two precisely *now* prevents the feature model from being deformed later to accommodate them.
2. **Feature ↔ provider cardinality.** Assumed one producer per feature. If two downstreams can produce the same feature, precedence and conflict resolution must be specified.
3. **`ALL_OF` only, or also `ANY_OF` / grouped conditions?** Starting with `ALL_OF` keeps the engine trivial. Adding OR-groups later is a schema-compatible extension — adding a full expression language is not, and should be resisted.
4. **Is `INDETERMINATE` acceptable to every calling platform?** If some caller cannot handle a third state, that needs an explicit per-tenant fallback policy rather than a silent mapping to `DENY`.
5. **PII in traces and audit.** Which feature values may be logged, and for how long.
6. **Hot reload or deploy-to-apply?** Deploy-to-apply is simpler and safer; hot reload is worth it only if rule change frequency justifies the added failure mode.
