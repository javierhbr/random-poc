# 04 — Config reference

Everything is driven by `.github/project-config.json`. To use this kit on a new
project, **edit only that file** — no code changes. Every key below has a default
(see `scripts/config.py` → `DEFAULTS`), so a minimal config still runs. Validate any
change with `python3 scripts/validate_config.py`.

## `project`
| key | meaning |
|-----|---------|
| `owner` | org or user login that owns the Project |
| `owner_type` | `"org"` or `"user"` |
| `project_number` | the Projects v2 number (0 = no board, labels-only mode) |
| `project_id` | opaque `PVT_…` id (only needed to *write* fields) |
| `repos` | list of `owner/repo` to scan for issues |

## `source` — where each attribute is read from
This is what makes the kit portable. For each of `status`, `objective`, `iteration`,
`priority`, pick a `mode`:
- `"field"` + `field_name` — read from a Projects v2 custom field.
- `"label"` + `prefix` — derive from a label (e.g. prefix `status:` → label `status:doing` ⇒ `doing`).
- `"milestone"` — use the issue's milestone title.

So a project with **no Project board** can still work: set `status` to label-mode and
`objective` to milestone-mode.

## `fields` — opaque IDs for write-back
Only needed if you let the tool *set* Projects fields. Discover with
`bash scripts/discover-ids.sh` and paste the `id` / option ids in.

## `statuses` — map YOUR column names to roles
Each role is a **list**, so synonyms and renames are fine. Roles: `backlog`, `ready`,
`in_progress`, `review`, `validation`, `done`. Plus two controls:
- `stale_watch` — which statuses the staleness clock applies to.
- `release_to` — where a released issue's status is sent back to.

## `labels` — rename anything
`epic`, `stale`, `blocked`, `needs_info`, `at_risk`, `size_split` are *logical keys*;
their values are whatever your project calls them. `namespaces` lists every label for
`setup-labels.sh` and validation. `colors` is optional (hex, no `#`).

## `wip_limits`
`in_progress_column_max`, `per_person_assigned_max`. Tune to real team hours.

## `staleness_days`
`aging` < `stale` < `release` (validator enforces the ordering).

## `relations` — body-convention keywords
Rename the keywords the graph parser looks for: `parent_keywords`,
`depends_keywords`, `blocks_keywords`. Matching is case-insensitive, line-anchored,
e.g. `Epic: #100` or `Blocked by: #5, #6`.

## `templates`
`stale_comment` and `release_comment`. `{stale_label}` is substituted with your
configured stale label.

## `focus`
`active_objectives` (the 2–3 you're concentrating on) and a free-text
`iteration_label`.

## `report`
`title` and `shortlist_size` (how many "up for grabs" items to surface).

---

### Onboarding a brand-new project (checklist)
1. `cp` this repo's `.github/` and `scripts/` into your project.
2. Edit `project`, `statuses` (your column names), `labels` (your scheme), `source`.
3. `python3 scripts/validate_config.py` → fix any `✗`.
4. `bash scripts/setup-labels.sh` → creates the labels on your repos.
5. `bash scripts/discover-ids.sh` → paste IDs into `fields` (only if writing fields).
6. `bash scripts/sync.sh` → dry-run; read the report; then `--apply`.
