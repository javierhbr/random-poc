#!/usr/bin/env python3
"""
analyze.py — Read data/snapshot.json; write a status report + relationship graph;
optionally (--apply) take the agreed staleness actions. Fully config-driven via
config.py: status roles, label names, thresholds, comment templates are all knobs.
Read-only unless --apply.
"""
import argparse
import json
import os
import subprocess
from datetime import datetime, timezone

import config as cfgmod

ROOT = cfgmod.ROOT
SNAP_PATH = os.path.join(ROOT, "data", "snapshot.json")
GRAPH_PATH = os.path.join(ROOT, "data", "graph.json")


def days_since(iso):
    if not iso:
        return None
    dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    return (datetime.now(timezone.utc) - dt).days


def classify_health(iss, cfg):
    if not cfg.is_stale_watch(iss.get("status")):
        return "fresh"
    d = days_since(iss.get("updatedAt"))
    th = cfg.thresholds
    if d is None:
        return "fresh"
    if d >= th["release"]:
        return "released"
    if d >= th["stale"]:
        return "stale"
    if d >= th["aging"]:
        return "aging"
    return "fresh"


def build_graph(issues, cfg):
    by_num = {i["number"]: i for i in issues}
    epic_label = cfg.label("epic")
    nodes, edges = [], []
    for i in issues:
        nodes.append({"id": i["number"], "title": i["title"], "status": i.get("status"),
                      "objective": i.get("objective"), "epic": epic_label in i.get("labels", [])})
        rel = i.get("relations", {})
        if rel.get("parent") in by_num:
            edges.append({"from": rel["parent"], "to": i["number"], "type": "parent"})
        for d in rel.get("depends_on", []):
            if d in by_num:
                edges.append({"from": d, "to": i["number"], "type": "blocks"})
        for b in rel.get("blocks", []):
            if b in by_num:
                edges.append({"from": i["number"], "to": b, "type": "blocks"})
    return {"nodes": nodes, "edges": edges}


def wip_report(issues, cfg):
    in_prog = [i for i in issues if cfg.is_in_progress(i.get("status"))]
    per_person = {}
    for i in in_prog:
        for a in i.get("assignees", []):
            per_person.setdefault(a, []).append(i["number"])
    violations = []
    if len(in_prog) > cfg.wip["in_progress_column_max"]:
        violations.append(f"In-Progress at {len(in_prog)} (max {cfg.wip['in_progress_column_max']}).")
    for person, nums in per_person.items():
        if len(nums) > cfg.wip["per_person_assigned_max"]:
            violations.append(f"@{person} has {len(nums)} in progress (max {cfg.wip['per_person_assigned_max']}): {nums}")
    return len(in_prog), violations


def render_report(snap, cfg):
    issues = snap["issues"]
    active = cfg.active_objectives
    for i in issues:
        i["_health"] = classify_health(i, cfg)

    in_prog_count, wip_violations = wip_report(issues, cfg)
    groups = {}
    for i in issues:
        groups.setdefault(i.get("objective") or "— Unassigned —", []).append(i)
    stale = [i for i in issues if i["_health"] in ("stale", "released")]
    aging = [i for i in issues if i["_health"] == "aging"]
    blocked = [i for i in issues if cfg.label("blocked") in i.get("labels", [])]
    ready_status = cfg.d["statuses"]["ready"]
    ready_in_focus = [i for i in issues
                      if i.get("status") in ready_status and i.get("objective") in active]

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    L = [f"# {cfg.report_title} — {today}\n",
         f"_{snap['count']} open issues · generated {snap['generated_at']}_\n",
         "## 🎯 Focus this iteration\n",
         f"Active objectives: {', '.join(sorted(active)) or '(none set)'}\n"]
    for obj in sorted(active):
        g = groups.get(obj, [])
        done = sum(1 for i in g if cfg.is_done(i.get("status")))
        L.append(f"- **{obj}** — {done}/{len(g)} complete; "
                 f"{sum(1 for i in g if cfg.is_in_progress(i.get('status')))} in progress, "
                 f"{sum(1 for i in g if i.get('status') in ready_status)} ready")
    L.append("\n## 🩺 Health\n")
    L.append(f"- In Progress: **{in_prog_count}** (limit {cfg.wip['in_progress_column_max']})")
    if wip_violations:
        L.append("- ⚠️ WIP violations:")
        L += [f"    - {v}" for v in wip_violations]
    L.append(f"- 🕒 Stale/release: **{len(stale)}**" + ((": " + ", ".join(f"#{i['number']}" for i in stale)) if stale else ""))
    L.append(f"- 👀 Aging: **{len(aging)}**" + ((": " + ", ".join(f"#{i['number']}" for i in aging)) if aging else ""))
    L.append(f"- 🚧 Blocked: **{len(blocked)}**" + ((": " + ", ".join(f"#{i['number']}" for i in blocked)) if blocked else ""))

    if stale:
        L.append("\n## ♻️ Recommended releases\n")
        for i in stale:
            who = ", ".join("@" + a for a in i["assignees"]) or "(unassigned)"
            L.append(f"- #{i['number']} — {i['title']} — {who}, {days_since(i['updatedAt'])}d idle → **{i['_health']}**")

    if ready_in_focus:
        L.append("\n## ✅ Up for grabs (Ready, in focus)\n")
        for i in ready_in_focus[:cfg.shortlist_size]:
            L.append(f"- #{i['number']} — {i['title']} ({i.get('objective')})")

    L.append("\n## 📦 All objectives\n")
    for obj, g in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        flag = "🎯 " if obj in active else ""
        L.append(f"- {flag}**{obj}** — {len(g)} issues")
    return "\n".join(L) + "\n", issues


def apply_actions(issues, cfg):
    stale_label = cfg.label("stale")
    for i in issues:
        repo, num = i["repo"], i["number"]
        if i["_health"] == "stale" and stale_label not in i["labels"]:
            subprocess.run(["gh", "issue", "edit", str(num), "--repo", repo, "--add-label", stale_label])
            subprocess.run(["gh", "issue", "comment", str(num), "--repo", repo, "--body", cfg.template("stale_comment")])
            print(f"[apply] stale -> {repo}#{num}")
        elif i["_health"] == "released":
            for a in i["assignees"]:
                subprocess.run(["gh", "issue", "edit", str(num), "--repo", repo, "--remove-assignee", a])
            subprocess.run(["gh", "issue", "comment", str(num), "--repo", repo, "--body", cfg.template("release_comment")])
            print(f"[apply] released -> {repo}#{num}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="take staleness actions on GitHub")
    args = ap.parse_args()

    cfg = cfgmod.load()
    snap = json.load(open(SNAP_PATH))
    report, issues = render_report(snap, cfg)

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    rep_path = os.path.join(ROOT, "reports", f"status-{today}.md")
    os.makedirs(os.path.dirname(rep_path), exist_ok=True)
    open(rep_path, "w").write(report)
    print(f"[analyze] wrote report -> {rep_path}")

    graph = build_graph(issues, cfg)
    json.dump(graph, open(GRAPH_PATH, "w"), indent=2)
    print(f"[analyze] graph: {len(graph['nodes'])} nodes, {len(graph['edges'])} edges -> {GRAPH_PATH}")

    if args.apply:
        print("[analyze] --apply: acting on GitHub...")
        apply_actions(issues, cfg)
    else:
        print("[analyze] dry-run (no writes). Use --apply to act.")


if __name__ == "__main__":
    main()
