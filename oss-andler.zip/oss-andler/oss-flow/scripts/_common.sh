# _common.sh — shared resolution for OSS-Flow CLI scripts. `source` this; do not run it.
# Sets:
#   SCRIPT_DIR   absolute dir of the kit's scripts (where the .py files live)
#   PROJECT_DIR  the project being operated on (.github/project-config.json + data/ + reports/)
#   CONFIG       path to that project's config
# Project resolution: OSS_FLOW_PROJECT env  >  current working directory.
SCRIPT_DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${OSS_FLOW_PROJECT:-$PWD}"
PROJECT_DIR="$(cd "$PROJECT_DIR" 2>/dev/null && pwd || echo "$PROJECT_DIR")"
CONFIG="$PROJECT_DIR/.github/project-config.json"
export OSS_FLOW_PROJECT="$PROJECT_DIR"

if [ ! -f "$CONFIG" ]; then
  echo "✗ No config found at: $CONFIG" >&2
  echo "  Set OSS_FLOW_PROJECT or run from a project dir; scaffold one with: oss-flow init" >&2
  exit 1
fi