#!/usr/bin/env bash
# sync.sh — orchestrate the full sync. Entry point for cron / GitHub Actions / the CLI.
#   oss-flow sync            # dry-run (no GitHub writes)
#   oss-flow sync --apply    # also take staleness actions
set -euo pipefail
source "$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"

echo "==> [0/3] Validating config..."
python3 "$SCRIPT_DIR/validate_config.py"

echo "==> [1/3] Extracting board snapshot..."
python3 "$SCRIPT_DIR/gh_extract.py"

echo "==> [2/3] Analyzing + reporting..."
python3 "$SCRIPT_DIR/analyze.py" "$@"

echo "==> [3/3] Done. Latest report: $(ls -t "$PROJECT_DIR"/reports/status-*.md 2>/dev/null | head -1)"
