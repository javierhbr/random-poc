#!/usr/bin/env bash
# discover-ids.sh — print the opaque GitHub Projects v2 IDs for project-config.json.
#   oss-flow discover-ids
set -euo pipefail
source "$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"
OWNER=$(jq -r '.project.owner' "$CONFIG")
NUM=$(jq -r '.project.project_number' "$CONFIG")

echo "==> project_id (paste into .project.project_id):"
gh project view "$NUM" --owner "$OWNER" --format json | jq -r '.id'
echo
echo "==> fields + single-select option IDs (paste into .fields):"
gh project field-list "$NUM" --owner "$OWNER" --format json \
  | jq -r '.fields[] | "FIELD  \(.name)  id=\(.id)  type=\(.type)",
            ( (.options // [])[] | "   OPTION  \(.name)  id=\(.id)" )'
