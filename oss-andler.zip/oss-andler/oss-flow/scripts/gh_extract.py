#!/usr/bin/env python3
"""
gh_extract.py — Pull the GitHub Project board + issue details into data/snapshot.json.
Fully config-driven (see config.py): field names, source modes, and relation keywords
all come from .github/project-config.json. Read-only.
"""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

import config as cfgmod

ROOT = cfgmod.ROOT
OUT_PATH = os.path.join(ROOT, "data", "snapshot.json")


def run(cmd):
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        sys.stderr.write(f"\n[gh_extract] failed: {' '.join(cmd)}\n{res.stderr}\n")
        sys.exit(1)
    return json.loads(res.stdout) if res.stdout.strip() else {}


def field_value(item, name):
    """gh flattens custom field values as item properties keyed by field name."""
    candidates = {name, name.lower(), name.replace(" ", ""), name.lower().replace(" ", "")}
    for k, v in item.items():
        if k in candidates or k.lower() == name.lower():
            return v.get("name") or v.get("title") or v.get("text") if isinstance(v, dict) else v
    return None


def extract_project_items(cfg):
    if not cfg.project_number:
        return {}
    data = run(["gh", "project", "item-list", str(cfg.project_number),
                "--owner", cfg.owner, "--format", "json", "--limit", "500"])
    items = {}
    # collect every configured source field name we may need
    field_names = [cfg.field_name(a) for a in ("status", "objective", "iteration", "priority")
                   if cfg.source_mode(a) == "field"]
    for it in data.get("items", []):
        content = it.get("content", {}) or {}
        if content.get("type") != "Issue":
            continue
        key = f"{content.get('repository','')}#{content.get('number')}"
        items[key] = {fn: field_value(it, fn) for fn in field_names}
    return items


def extract_issue_details(repo):
    return run(["gh", "issue", "list", "--repo", repo, "--state", "open", "--limit", "500",
                "--json", "number,title,url,labels,assignees,updatedAt,createdAt,body,milestone"])


def parse_relations(body, regexes):
    rel = {"parent": None, "depends_on": [], "blocks": []}
    if not body:
        return rel
    import re
    for line in body.splitlines():
        m = regexes["parent"].match(line)
        if m:
            nums = re.findall(r"#(\d+)", m.group(1))
            if nums:
                rel["parent"] = int(nums[0])
        m = regexes["depends"].match(line)
        if m:
            rel["depends_on"] += [int(n) for n in re.findall(r"#(\d+)", m.group(1))]
        m = regexes["blocks"].match(line)
        if m:
            rel["blocks"] += [int(n) for n in re.findall(r"#(\d+)", m.group(1))]
    return rel


def main():
    cfg = cfgmod.load()
    regexes = cfg.relation_regexes()
    project_items = extract_project_items(cfg)

    records = {}
    for repo in cfg.repos:
        for iss in extract_issue_details(repo):
            key = f"{repo}#{iss['number']}"
            pfields = project_items.get(key, {})
            labels = [l["name"] for l in iss.get("labels", [])]
            milestone = (iss.get("milestone") or {}).get("title")
            records[key] = {
                "key": key, "repo": repo, "number": iss["number"],
                "title": iss["title"], "url": iss["url"],
                "labels": labels,
                "assignees": [a["login"] for a in iss.get("assignees", [])],
                "updatedAt": iss.get("updatedAt"), "createdAt": iss.get("createdAt"),
                "milestone": milestone,
                # logical attributes resolved via whatever source this project uses
                "status":    cfg.resolve_attribute("status", pfields, labels, milestone),
                "objective": cfg.resolve_attribute("objective", pfields, labels, milestone),
                "iteration": cfg.resolve_attribute("iteration", pfields, labels, milestone),
                "priority":  cfg.resolve_attribute("priority", pfields, labels, milestone),
                "relations": parse_relations(iss.get("body", ""), regexes),
            }

    snapshot = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "count": len(records), "issues": list(records.values()),
    }
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    json.dump(snapshot, open(OUT_PATH, "w"), indent=2)
    print(f"[gh_extract] wrote {len(records)} issues -> {OUT_PATH}")


if __name__ == "__main__":
    main()
