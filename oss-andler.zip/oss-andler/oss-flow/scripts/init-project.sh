#!/usr/bin/env bash
# init-project.sh — scaffold an OSS-Flow project dir: config template + data/ + reports/.
# Non-destructive: never overwrites an existing config.
#   oss-flow init [DIR]      (DIR defaults to $OSS_FLOW_PROJECT or the current dir)
set -euo pipefail
SCRIPT_DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(cd -P "$SCRIPT_DIR/.." && pwd)"

TARGET="${1:-${OSS_FLOW_PROJECT:-$PWD}}"
mkdir -p "$TARGET/.github" "$TARGET/data" "$TARGET/reports"
TARGET="$(cd "$TARGET" && pwd)"
touch "$TARGET/data/.gitkeep" "$TARGET/reports/.gitkeep"

CFG="$TARGET/.github/project-config.json"
if [ -f "$CFG" ]; then
  echo "= Config already exists: $CFG (left untouched)"
else
  cp "$KIT/.github/project-config.json" "$CFG"
  echo "+ Created $CFG"
fi
echo
echo "Next:"
echo "  1. Edit $CFG (owner, repos, statuses, source modes — see $KIT/docs/04-config.md)"
echo "  2. oss-flow --project \"$TARGET\" discover-ids   # fill in opaque IDs"
echo "  3. oss-flow --project \"$TARGET\" validate"
echo "  4. oss-flow --project \"$TARGET\" sync           # dry-run"
