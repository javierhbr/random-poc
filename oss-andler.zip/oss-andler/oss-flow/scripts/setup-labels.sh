#!/usr/bin/env bash
# setup-labels.sh — ensure every namespaced label from the config exists on every repo.
# Adopts existing labels as-is: fetches each repo's current labels, reuses any that
# already exist (never overwriting their color/description), and only CREATES the config
# defaults for the ones that are missing. Idempotent and non-destructive.
# Written for bash 3.2 (macOS) — no mapfile / associative arrays.
#   oss-flow labels
set -euo pipefail
source "$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_common.sh"

LABELS_TSV="$(mktemp "${TMPDIR:-/tmp}/oss_flow_labels.XXXXXX")"
trap 'rm -f "$LABELS_TSV"' EXIT

# Flatten all labels across namespaces, pairing each with its color (default ededed).
jq -r '
  .labels.namespaces as $ns | .labels.colors as $c
  | [ $ns[] ] | add | unique[]
  | "\(.)\t\($c[.] // "ededed")"
' "$CONFIG" > "$LABELS_TSV"

jq -r '.project.repos[]' "$CONFIG" | while IFS= read -r repo; do
  [ -n "$repo" ] || continue
  echo "==> $repo"

  # Existing labels on this repo, one name per line.
  existing="$(gh label list --repo "$repo" --limit 500 --json name -q '.[].name')"

  created=0; reused=0
  while IFS=$'\t' read -r name color; do
    [ -n "$name" ] || continue
    if printf '%s\n' "$existing" | grep -Fxq -- "$name"; then
      echo "   = $name (already exists — reusing)"
      reused=$((reused + 1))
    else
      gh label create "$name" --repo "$repo" --color "$color" >/dev/null \
        && echo "   + $name (#$color, created)"
      created=$((created + 1))
    fi
  done < "$LABELS_TSV"

  echo "   ($created created, $reused reused)"
done
echo "Done. Verify with: gh label list --repo <repo>"
