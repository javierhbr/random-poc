#!/usr/bin/env python3
"""
validate_config.py — sanity-check .github/project-config.json before you rely on it.
Prints PASS / WARN / FAIL lines. Exit code 1 if any FAIL. Run after editing the config
or onboarding a new project:  python3 scripts/validate_config.py
"""
import sys
import config as cfgmod

ok = warn = fail = 0


def line(level, msg):
    global ok, warn, fail
    icon = {"PASS": "✓", "WARN": "!", "FAIL": "✗"}[level]
    print(f"[{icon}] {msg}")
    if level == "PASS": ok += 1
    elif level == "WARN": warn += 1
    else: fail += 1


def main():
    cfg = cfgmod.load()
    d = cfg.d

    # project basics
    if cfg.owner and "YOUR_" not in str(cfg.owner):
        line("PASS", f"owner set: {cfg.owner}")
    else:
        line("FAIL", "project.owner not set (still placeholder).")
    if cfg.repos and all("YOUR_" not in r for r in cfg.repos):
        line("PASS", f"repos set: {cfg.repos}")
    else:
        line("FAIL", "project.repos not set (still placeholder).")

    # source modes
    for attr in ("status", "objective", "iteration", "priority"):
        mode = cfg.source_mode(attr)
        if mode in ("field", "label", "milestone"):
            line("PASS", f"source.{attr} mode = {mode}")
        else:
            line("FAIL", f"source.{attr} mode '{mode}' invalid (field|label|milestone).")
    if any(cfg.source_mode(a) == "field" for a in ("status", "objective")) and not cfg.project_number:
        line("WARN", "a field-mode source is set but project_number is 0 — fields won't resolve.")

    # status roles reference real columns
    role_values = set()
    for role in ("backlog", "ready", "in_progress", "review", "validation", "done"):
        role_values |= set(d["statuses"].get(role, []))
    for watched in d["statuses"]["stale_watch"]:
        if watched in role_values:
            line("PASS", f"stale_watch '{watched}' is a known status.")
        else:
            line("WARN", f"stale_watch '{watched}' is not in any status role list.")
    if d["statuses"]["release_to"] in role_values:
        line("PASS", f"release_to '{d['statuses']['release_to']}' is a known status.")
    else:
        line("FAIL", f"release_to '{d['statuses']['release_to']}' is not a known status.")

    # thresholds strictly increasing
    th = cfg.thresholds
    if th["aging"] < th["stale"] < th["release"]:
        line("PASS", f"staleness thresholds increasing: {th['aging']}<{th['stale']}<{th['release']}")
    else:
        line("FAIL", f"staleness thresholds must satisfy aging<stale<release, got {th}.")

    # label keys resolve and live in a namespace
    flat = set(cfg.all_namespaced_labels)
    for key in ("epic", "stale", "blocked", "size_split"):
        name = cfg.label(key)
        if name in flat:
            line("PASS", f"label '{key}' = '{name}' (in a namespace).")
        else:
            line("WARN", f"label '{key}' = '{name}' is not listed under labels.namespaces.")

    # focus
    if cfg.active_objectives:
        line("PASS", f"focus.active_objectives: {sorted(cfg.active_objectives)}")
    else:
        line("WARN", "focus.active_objectives is empty — no focus will be highlighted.")

    print(f"\nSummary: {ok} pass, {warn} warn, {fail} fail")
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
