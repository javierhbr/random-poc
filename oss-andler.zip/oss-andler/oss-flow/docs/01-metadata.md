# 01 — Metadata

This is the vocabulary the entire system reads. Three tools, three jobs. Don't mix
them up.

| Tool | Job | Cardinality |
|------|-----|-------------|
| **Labels** | Flat, multi-value tags for filtering & script parsing | many per issue |
| **Project fields** | Single structured value (Status, Objective, Iteration) | one each |
| **Relationships** | Hierarchy (sub-issues) & dependencies (blocks) | the graph |

## 1. Labels — namespaced dimensions

Always `dimension:value`. Namespacing is what lets the script group reliably and
keeps the label list from rotting into chaos. Create these once with `gh label create`.

```
type:bug          area:<component>      size:xs   health:stale
type:feature      (project-specific,    size:s    health:blocked
type:docs          one per subsystem)    size:m    health:needs-info
type:chore                               size:l    health:at-risk
type:epic                                size:xl   good-first-issue
                                                   help-wanted
```

Rules:
- **`type:`** — exactly one per issue. `type:epic` marks a container, not work.
- **`area:`** — your subsystems (e.g. `area:auth`, `area:parser`). One or two max.
- **`size:`** — rough effort. **`size:xl` is a signal, not a state**: it means
  "too big for one part-timer — split into sub-issues."
- **`health:`** — applied by the **sync script**, not humans. Don't set these by hand.

## 2. Project fields (GitHub Projects v2)

| Field | Type | Values |
|-------|------|--------|
| **Status** | single-select | Backlog → Ready → In Progress → In Review → Validation → Done |
| **Objective** | single-select | your active epics, e.g. `Q3 — Auth Migration` |
| **Iteration** | iteration | the monthly focus window (GitHub's native "sprint") |
| **Priority** | single-select | P0 / P1 / P2 |

Why fields *and* labels for similar-sounding things? A field holds **one** value and
powers board grouping/filtering natively; a label is **multi-value** and is what the
script greps. Objective is a field (an issue belongs to one epic). Health is a label
(an issue can be both stale and blocked).

## 3. Relationships — this is your graph

- **Sub-issues (native)** = `Epic → task`. Use GitHub's built-in sub-issues. Parent
  progress rolls up automatically and shows in Projects.
- **Dependencies** = `blocks / blocked-by`. Use GitHub's native issue dependencies,
  *or* the body convention below if you prefer plain text the script can parse.

Body conventions the sync script understands (put on their own line in the issue body):

```
Parent: #123          → this issue is a sub-task of the epic #123
Depends on: #45, #67  → this issue is blocked until #45 and #67 are done
Blocks: #89           → #89 cannot start until this is done
```

## Definition of Ready (entry gate to "Ready"/focus)

An issue may only enter the monthly focus if it has: a `type:`, a `size:` (and is
**not** `size:xl`), an **Objective**, and acceptance criteria in the body. This single
gate is what stops the Backlog → In Progress leak that inflates your board.

## Naming is non-negotiable

The `dimension:value` prefix convention is load-bearing — `analyze.py` groups by
splitting on `:`. A stray label like `bug` (no prefix) is invisible to the system.
