# 02 — Process & Flow

Two flows run at once: the **issue lifecycle** (how one task moves) and the **sync
loop** (how the whole board stays visible without meetings).

## A. Issue lifecycle (Kanban + focus)

### Mermaid

```mermaid
flowchart LR
    NEW([New issue]) --> TRIAGE{Triage:<br/>type, area, size}
    TRIAGE -->|size:xl| SPLIT[Split into<br/>sub-issues]
    SPLIT --> BACKLOG
    TRIAGE -->|sized ok| BACKLOG[(Backlog)]

    BACKLOG -->|Definition of Ready met<br/>+ assigned to an Objective| READY[(Ready)]
    READY -->|claimed, WIP slot free| PROG[(In Progress)]
    PROG --> REVIEW[(In Review)]
    REVIEW --> VALID[(Validation)]
    VALID --> DONE([Done])

    PROG -. no update ≥21d .-> STALE{{health:stale}}
    STALE -. no update ≥35d .-> READY
```

Two things to notice: the **size:xl → split** branch (big tasks never enter the board
whole), and the dashed **staleness loop** that returns abandoned work to `Ready`
instead of letting it rot in `In Progress`.

### ASCII board (with WIP limits)

```
 BACKLOG        READY          IN PROGRESS     IN REVIEW   VALIDATION   DONE
 (Objective-    (DoR met)      (WIP ≤ 8)       (WIP ≤ 4)
  grouped)
┌───────────┐  ┌───────────┐  ┌───────────┐  ┌────────┐  ┌────────┐  ┌──────┐
│ ▪ #210    │  │ ▪ #181    │  │ ▪ #142 👤 │  │ ▪ #120 │  │ ▪ #98  │  │ #71  │
│ ▪ #208    │  │ ▪ #179    │  │ ▪ #138 👤 │  │ ▪ #119 │  │        │  │ #70  │
│ ▪ #205    │  │ ▪ #176    │  │ ▪ #131 🕒 │← stale  │     │        │  │ ...  │
│ ▪ ...     │  │ ▪ ...     │  │   (≥21d)  │  └────────┘  └────────┘  └──────┘
│  (big)    │  │           │  │ [3 / 8]   │
└───────────┘  └───────────┘  └───────────┘
                              ▲ when full, pull is blocked
```

## B. Sync loop (the daemon)

Runs twice a day via cron or GitHub Actions. Read-only by default; `--apply` lets it
act on the agreed policy.

### Mermaid sequence

```mermaid
sequenceDiagram
    autonumber
    participant Cron as Cron / Action (2×/day)
    participant GH as GitHub (gh CLI)
    participant EX as gh_extract.py
    participant AN as analyze.py
    participant REP as Status report

    Cron->>EX: run sync.sh
    EX->>GH: gh project item-list + gh issue list
    GH-->>EX: items, labels, assignees, updatedAt
    EX->>EX: merge → data/snapshot.json
    AN->>AN: classify staleness, group by Objective, build graph
    AN->>REP: write reports/status-YYYY-MM-DD.md + data/graph.json
    opt --apply
        AN->>GH: label health:stale / ping / release abandoned
    end
    REP-->>Cron: pin/post report = source of truth
```

### ASCII pipeline

```
   ┌──────────────┐
   │ cron / Action│  06:00 & 18:00
   └──────┬───────┘
          ▼
   ┌──────────────┐   gh project item-list      ┌──────────────────┐
   │ gh_extract.py│ ─────────────────────────►  │ data/snapshot.json│
   └──────┬───────┘   gh issue list (merge)      └──────────────────┘
          ▼
   ┌──────────────┐   • staleness vs thresholds  ┌──────────────────┐
   │  analyze.py  │ ─ • group by Objective ─────► │ reports/status-* │
   │              │   • relationship graph        │ data/graph.json  │
   └──────┬───────┘   • WIP violations            └──────────────────┘
          │
          ▼ (only with --apply)
   ┌──────────────┐
   │ gh issue edit│  add health:stale · ping · release
   └──────────────┘
```

## C. Where the report lives

Pin one issue titled **"📊 Weekly Status (auto)"** or post to a Discussion / Slack.
That artifact replaces the meeting as the source of truth. A contributor who skips the
bi-weekly sync still has full, current visibility — which is the whole point.

## D. The AI layer (optional, on top)

`analyze.py` is deterministic. The Claude Code **issue-triage skill** sits above it for
the judgment calls a script can't make: *should this be an epic? which sub-issues?
what's the real priority given the Objective?* See `.claude/skills/issue-triage/`.
