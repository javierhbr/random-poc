# 03 — Policies

These are the *human* rules. Software can't fix abandoned tasks; an agreed policy
can. Tune every number to your team's real available hours — the defaults assume a
small part-time team on a bi-weekly cadence.

## WIP limits

| Limit | Default | Why |
|-------|---------|-----|
| **In-Progress column max** | 8 | A full column blocks new pulls. This is the core Kanban fix for your bloated "in progress." |
| **Per-person assigned max** | 2 | Part-timers spreading across 5 issues finish none. |

When the In-Progress column is full, nothing new enters until something exits. The
sync report flags violations; it does not silently move cards.

## Staleness lifecycle

The point: reclaim abandoned issues **without** ever yanking a task from someone — the
contributor accepts the auto-release rule *when they claim it*. Releasing ≠ reassigning.
It's a public, uniform policy, not a judgment call you make case-by-case.

```
fresh ──(no update ≥10d)──► aging ──(no update ≥21d)──► stale ──(no update ≥35d)──► released
 │                            │                           │                            │
 (nothing)            (flagged in report,          (health:stale label        (unassigned + comment,
                       no label yet)                + ping comment)             back to Ready)
```

| Stage | Default threshold | Action (by the script) |
|-------|-------------------|------------------------|
| **aging** | 10 days no update | Listed in report under "watch list." No label. |
| **stale** | 21 days no update | Add `health:stale`, post a friendly ping comment to the assignee. |
| **released** | 35 days no update | Remove assignee, set Status → Ready, comment that it's up for grabs. |

"No update" uses the issue's `updatedAt` (comments, edits, label changes all reset it).
Adjust thresholds in `.github/project-config.json` → `staleness_days`.

## Definition of "claimed"

Claiming an issue = a commitment to leave an update at least every **{stale} days**.
No update = no claim. State this in `CONTRIBUTING.md` so the auto-release is expected,
not a surprise.

## Focus policy

- Each month, the co-leads pick **2–3 active Objectives**. Everything else is
  *explicitly out of scope* that month.
- Volunteer freedom is preserved but bounded: "pick any task **within these
  Objectives**," not "pick anything."
- The backlog is prioritized **by Objective**, never task-by-task (impossible with
  volunteers).

## Governance note

Because this is open source, these rules are **proposed and agreed**, not imposed.
Land them as a PR to `CONTRIBUTING.md` and let the community react before turning on
the `--apply` (write) mode of the sync.
