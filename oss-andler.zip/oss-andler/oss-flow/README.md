# OSS-Flow — a focus & sync system for part-time GitHub Projects

A lightweight, **fully configurable** kit for running an open-source project where
contributors are part-time and work scatters across a huge backlog. Drop it on *any*
GitHub project — every parameter (status column names, label scheme, field names,
thresholds, ping messages, relationship keywords) lives in one config file. It:

1. **Focuses effort** around 2–3 monthly *Objectives*, not free-for-all task picking.
2. **Kills zombie tasks** via a staleness lifecycle that flags and releases abandoned
   issues *without* breaking the "don't reassign" norm.
3. **Removes the meeting dependency** — a sync runs twice a day and posts a status
   report that becomes the source of truth.

```
oss-flow/
├── README.md
├── .github/
│   ├── project-config.json        ← THE ONLY FILE YOU EDIT (all parameters)
│   └── workflows/sync.yml          ← twice-daily GitHub Action
├── docs/
│   ├── 01-metadata.md              ← labels, fields, conventions
│   ├── 02-process.md               ← the flow + Mermaid & ASCII diagrams
│   ├── 03-policies.md              ← WIP limits + staleness thresholds
│   └── 04-config.md                ← reference for every config parameter
├── scripts/
│   ├── config.py                   ← shared loader (defaults + helpers)
│   ├── validate_config.py          ← sanity-check the config
│   ├── setup-labels.sh             ← create all labels from config (idempotent)
│   ├── discover-ids.sh             ← find project/field/option IDs
│   ├── gh_extract.py               ← pull board → data/snapshot.json
│   ├── analyze.py                  ← classify + graph + report (+ --apply)
│   └── sync.sh                     ← orchestrator (validate → extract → analyze)
└── .claude/
    ├── skills/issue-triage/SKILL.md  ← AI triage skill (+ gh-actions reference)
    └── commands/                     ← /triage, /focus, /sync-status
```

## How to read the docs (in order)
1. `docs/01-metadata.md` — the vocabulary everything else reads.
2. `docs/03-policies.md` — the human rules (WIP, staleness) to agree on.
3. `docs/02-process.md` — the flow and diagrams.
4. `docs/04-config.md` — how to retarget the kit to your project.

## Install the CLI once
The scripts run as a single `oss-flow` CLI — install it once and point it at any project
dir; you never copy the scripts around. Each *project* only needs its own
`.github/project-config.json` + `data/` + `reports/` (scaffold them with `oss-flow init`).

```bash
ln -sf "$PWD/scripts/oss-flow" /usr/local/bin/oss-flow   # or ~/.local/bin (no sudo)
oss-flow --help
```

The project dir is resolved as: `--project DIR`  >  `$OSS_FLOW_PROJECT`  >  current dir.

## Use it on any project (turnkey)
```bash
gh auth login && gh auth refresh -s project        # gh needs the project scope

oss-flow init my-project                           # 1. scaffold config + data/ + reports/
cd my-project                                      #    (run subsequent commands here, or
                                                   #     pass --project my-project)
# 2. Edit .github/project-config.json: project, statuses (your columns),
#    labels (your scheme), source modes. Nothing is hardcoded — see docs/04-config.md.

oss-flow validate                                  # 3. fix any ✗
oss-flow discover-ids                              # 4. (optional) IDs for field write-back
oss-flow labels                                    # 5. create missing labels (reuses existing)

oss-flow sync                                      # 6. dry-run: report only, no writes
oss-flow sync --apply                              # 7. when trusted: take actions
```

### Portable by design
- **No Projects board?** Set `source.status` to label-mode and `source.objective` to
  milestone-mode — it works on plain issues + labels + milestones.
- **Different column names / labels?** Just list yours in `statuses` and `labels`.
- **Different cadence?** Tune `staleness_days` and `wip_limits` to your team's hours.

> Repo content is in English for international contributors. Ask for Spanish docs.
