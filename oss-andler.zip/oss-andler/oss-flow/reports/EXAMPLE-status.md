# 📊 Status report — 2026-06-30

_7 open issues · generated 2026-06-30T15:06:22.716580+00:00_

## 🎯 Focus this iteration

Active objectives: Q3 — Auth Migration, Q3 — Docs Overhaul

- **Q3 — Auth Migration** — 0/5 complete; 4 in progress, 1 ready
- **Q3 — Docs Overhaul** — 0/0 complete; 0 in progress, 0 ready

## 🩺 Health

- In Progress: **5** (limit 8)
- 🕒 Stale/release: **2**: #131, #118
- 👀 Aging: **0**
- 🚧 Blocked: **1**: #90

## ♻️ Recommended releases

- #131 — Token refresh flow — @marco, 26d idle → **stale**
- #118 — Legacy session cleanup — @sam, 40d idle → **released**

## ✅ Up for grabs (Ready, in focus)

- #181 — Document OAuth setup (Q3 — Auth Migration)

## 📦 All objectives

- 🎯 **Q3 — Auth Migration** — 5 issues
- **— Unassigned —** — 2 issues
