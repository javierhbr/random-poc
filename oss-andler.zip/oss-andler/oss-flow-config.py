#!/usr/bin/env python3
"""
config.py — single, fully-parameterized config loader shared by all scripts.

Loads .github/project-config.json, deep-merges it over DEFAULTS, and exposes
helpers so NOTHING is hardcoded in the other scripts: field names, status column
names, label names, staleness thresholds, relationship keywords, comment templates
— all come from here. Drop the kit on any GitHub project by editing the JSON only.
"""
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(ROOT, ".github", "project-config.json")

# Every customizable knob has a default here, so a minimal config still runs.
DEFAULTS = {
    "project": {
        "owner": "", "owner_type": "org", "project_number": 0,
        "project_id": "", "repos": [],
    },
    # Where each logical attribute is read FROM. mode: field | label | milestone
    "source": {
        "status":    {"mode": "field", "field_name": "Status"},
        "objective": {"mode": "field", "field_name": "Objective"},
        "iteration": {"mode": "field", "field_name": "Iteration"},
        "priority":  {"mode": "field", "field_name": "Priority"},
    },
    # Opaque IDs for write-back (only needed if the tool SETS fields).
    "fields": {
        "status": {"id": "", "options": {}},
        "objective": {"id": "", "options": {}},
        "priority": {"id": "", "options": {}},
        "iteration": {"id": ""},
    },
    # Map YOUR column names to roles. Lists, so synonyms/renames are fine.
    "statuses": {
        "backlog": ["Backlog"],
        "ready": ["Ready"],
        "in_progress": ["In Progress"],
        "review": ["In Review"],
        "validation": ["Validation"],
        "done": ["Done", "Closed"],
        "stale_watch": ["In Progress", "In Review"],
        "release_to": "Ready",
    },
    # Rename any label to match your project's scheme.
    "labels": {
        "epic": "type:epic",
        "stale": "health:stale",
        "blocked": "health:blocked",
        "needs_info": "health:needs-info",
        "at_risk": "health:at-risk",
        "size_split": "size:xl",
        "namespaces": {
            "type": ["type:bug", "type:feature", "type:docs", "type:chore", "type:epic"],
            "size": ["size:xs", "size:s", "size:m", "size:l", "size:xl"],
            "health": ["health:stale", "health:blocked", "health:needs-info", "health:at-risk"],
        },
        "colors": {},  # optional: { "type:epic": "5319e7" }; used by setup-labels.sh
    },
    "wip_limits": {"in_progress_column_max": 8, "per_person_assigned_max": 2},
    "staleness_days": {"aging": 10, "stale": 21, "release": 35},
    # Body conventions for the relationship graph. Keywords are case-insensitive.
    "relations": {
        "parent_keywords": ["Parent", "Epic"],
        "depends_keywords": ["Depends on", "Blocked by"],
        "blocks_keywords": ["Blocks"],
    },
    "templates": {
        "stale_comment": (
            "👋 This issue has had no update in a while and is now flagged "
            "`{stale_label}`. A quick status comment keeps it yours; otherwise it "
            "may be released to others per our contributor policy. Thanks!"
        ),
        "release_comment": (
            "♻️ Released back to the pool after extended inactivity (per contributor "
            "policy). It's now up for grabs — comment to claim it."
        ),
    },
    "focus": {"active_objectives": [], "iteration_label": ""},
    "report": {"shortlist_size": 6, "title": "📊 Status report"},
}


def _deep_merge(base, override):
    out = dict(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class Config:
    def __init__(self, raw):
        self.d = _deep_merge(DEFAULTS, raw)

    # ---- project ----
    @property
    def owner(self): return self.d["project"]["owner"]
    @property
    def project_number(self): return self.d["project"]["project_number"]
    @property
    def repos(self): return self.d["project"]["repos"]
    @property
    def project_id(self): return self.d["project"]["project_id"]

    # ---- source resolution ----
    def source_mode(self, attr): return self.d["source"][attr]["mode"]
    def field_name(self, attr): return self.d["source"][attr].get("field_name", attr.title())

    def resolve_attribute(self, attr, project_fields, labels, milestone):
        """Resolve a logical attribute (status/objective/...) from whichever source
        this project uses. Returns a string or None."""
        src = self.d["source"][attr]
        mode = src["mode"]
        if mode == "field":
            return project_fields.get(self.field_name(attr))
        if mode == "label":
            prefix = src.get("prefix", attr + ":")
            for l in labels:
                if l.startswith(prefix):
                    return l[len(prefix):]
            return None
        if mode == "milestone":
            return milestone
        return None

    # ---- status roles ----
    def status_role(self, status):
        for role in ("backlog", "ready", "in_progress", "review", "validation", "done"):
            if status in self.d["statuses"].get(role, []):
                return role
        return None

    def is_stale_watch(self, status): return status in self.d["statuses"]["stale_watch"]
    def is_in_progress(self, status): return status in self.d["statuses"]["in_progress"]
    def is_done(self, status): return status in self.d["statuses"]["done"]
    @property
    def release_to(self): return self.d["statuses"]["release_to"]

    # ---- labels ----
    def label(self, key): return self.d["labels"].get(key, key)
    @property
    def all_namespaced_labels(self):
        out = []
        for vals in self.d["labels"]["namespaces"].values():
            out += vals
        return out
    def label_color(self, name): return self.d["labels"]["colors"].get(name, "ededed")

    # ---- thresholds / limits ----
    @property
    def thresholds(self): return self.d["staleness_days"]
    @property
    def wip(self): return self.d["wip_limits"]

    # ---- relations ----
    def relation_regexes(self):
        def rx(keywords):
            alt = "|".join(re.escape(k) for k in keywords)
            return re.compile(rf"(?i)^\s*(?:{alt})\s*:\s*(.+)$")
        r = self.d["relations"]
        return {
            "parent": rx(r["parent_keywords"]),
            "depends": rx(r["depends_keywords"]),
            "blocks": rx(r["blocks_keywords"]),
        }

    # ---- templates / focus / report ----
    def template(self, key):
        return self.d["templates"][key].format(stale_label=self.label("stale"))
    @property
    def active_objectives(self): return set(self.d["focus"]["active_objectives"])
    @property
    def shortlist_size(self): return self.d["report"]["shortlist_size"]
    @property
    def report_title(self): return self.d["report"]["title"]


def load(path=CONFIG_PATH):
    with open(path) as f:
        raw = json.load(f)
    return Config(raw)
