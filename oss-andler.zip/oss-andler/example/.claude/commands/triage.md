---
description: Pull the board and run a full AI triage (classify, epics, focus shortlist)
argument-hint: "[objective name or 'all']"
allowed-tools: Bash(oss-flow:*), Bash(python3:*), Bash(gh:*), Read, Glob
---

Use the **issue-triage** skill.

1. Run `oss-flow extract` then `oss-flow analyze` (dry-run). From the project dir, or add `--project DIR`.
2. Read `data/snapshot.json`, `data/graph.json`, and the latest `reports/status-*.md`.
3. Produce a full triage for: ${ARGUMENTS:-the active objectives in project-config.json}.

Follow the skill's output format exactly. Do NOT apply any change to GitHub — end with
the "Actions to apply (awaiting approval)" block and wait for my go-ahead.
