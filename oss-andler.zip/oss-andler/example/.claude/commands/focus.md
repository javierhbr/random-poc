---
description: Set or review the monthly focus objectives and build the pick-up plan
argument-hint: "[\"Objective A\" \"Objective B\"]"
allowed-tools: Bash(oss-flow:*), Bash(python3:*), Bash(gh:*), Read, Edit
---

Use the **issue-triage** skill, focus workflow.

If arguments are given, update `.github/project-config.json` →
`focus.active_objectives` to: $ARGUMENTS (show me the diff before saving).

Then refresh a snapshot with `oss-flow sync` (dry-run; from the project dir, or add
`--project DIR`) and report per active objective:
- progress (done / total), what's In Progress, what's Ready to pick up,
- what's stale or blocked and dragging it,
- a 3–6 item "if you have 2 hours" shortlist for a part-time contributor.

Everything that is NOT under an active objective should be listed once, briefly, as
"out of focus this iteration." Do not modify any issue.
