---
description: Run the full sync and summarize health, stale work, and WIP violations
argument-hint: "[--apply]"
allowed-tools: Bash(oss-flow:*), Bash(bash:*), Bash(python3:*), Bash(gh:*), Read
---

Run `oss-flow sync $ARGUMENTS` (from the project dir, or add `--project DIR`).

- With no argument: dry-run. Read the generated `reports/status-*.md` and give me a
  tight summary: WIP violations, stale/aging counts, blocked items, and progress per
  active objective.
- With `--apply`: only after I've seen a dry-run this session. Summarize exactly what
  was changed on GitHub (which issues got `health:stale`, which were released).

Flag anything that needs a human decision (e.g. an issue about to be released that
looks important) instead of acting silently.
