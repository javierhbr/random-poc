# gh-actions — exact mutation commands

Read this before applying any change. Read-only commands are safe; mutations are
marked ⚠️ and require user approval.

> **Use the `oss-flow` CLI for the standard paths**, and these raw `gh` commands only for
> the triage *judgment* mutations the CLI doesn't do (label/field edits, epics,
> sub-issues) or as a fallback:
> - Snapshot + report → `oss-flow extract` / `oss-flow analyze` (writes `data/snapshot.json`).
> - Create the namespaced labels → `oss-flow labels` (reuses existing, creates missing).
> - Project/field/option IDs → `oss-flow discover-ids`.
> - Staleness flag/ping/release → `oss-flow sync --apply` (never hand-roll it).
>
> `<NUM>`/`<OWNER>`/`<OWNER/REPO>` below come from `.github/project-config.json`.

## Read (safe)

```bash
# Board items with field values
gh project item-list <NUM> --owner <OWNER> --format json --limit 500

# Fields and their option IDs
gh project field-list <NUM> --owner <OWNER> --format json

# Rich issue data
gh issue list --repo <OWNER/REPO> --state open \
  --json number,title,labels,assignees,updatedAt,body --limit 500

# Filter on the board directly (Projects filter syntax)
gh project item-list <NUM> --owner <OWNER> --format json \
  --query "label:type:epic -status:Done"
```

> Known issue: on boards with 200+ items, `item-list --format json` can time out. If
> so, fall back to a lean GraphQL query (`gh api graphql`) requesting only
> `Status` + `content.number`, paginating with `items(first: 50, after: ...)`.

## Labels ⚠️

```bash
# Create the namespaced labels once — prefer the CLI (reuses existing, creates missing):
oss-flow labels
# (raw primitive, if you must create one by hand:)
gh label create "type:epic"     --repo <OWNER/REPO> --color 5319e7

# Apply / remove on an issue
gh issue edit <N> --repo <OWNER/REPO> --add-label "type:feature,size:m"
gh issue edit <N> --repo <OWNER/REPO> --remove-label "health:stale"
```

## Project fields ⚠️ (single-select)

Needs project-id + field-id + option-id (from `.github/project-config.json`, or print
them with `oss-flow discover-ids`):
```bash
# First get the item id for an issue
ITEM_ID=$(gh project item-list <NUM> --owner <OWNER> --format json \
  --jq '.items[] | select(.content.number==<N>) | .id')

gh project item-edit --id "$ITEM_ID" --project-id "$PROJECT_ID" \
  --field-id "$STATUS_FIELD_ID" --single-select-option-id "$OPTION_ID"
```

## Sub-issues ⚠️ (native hierarchy)

The stable CLI has no `gh issue sub-issue` command yet; use the GraphQL API.
```bash
# 1. Create the child issue
CHILD_URL=$(gh issue create --repo <OWNER/REPO> \
  --title "Sub: <scope>" --body "Parent: #<EPIC>" --label "type:feature,size:s" )

# 2. Resolve node IDs
PARENT_ID=$(gh issue view <EPIC> --repo <OWNER/REPO> --json id --jq .id)
CHILD_ID=$(gh issue view "$CHILD_URL" --json id --jq .id)

# 3. Link as native sub-issue
gh api graphql -f query='
  mutation($parent:ID!, $child:ID!){
    addSubIssue(input:{issueId:$parent, subIssueId:$child}){ issue { number } }
  }' -F parent="$PARENT_ID" -F child="$CHILD_ID"
```

## Assignment & comments ⚠️

```bash
gh issue edit <N> --repo <OWNER/REPO> --remove-assignee <login>   # release
gh issue comment <N> --repo <OWNER/REPO> --body "<message>"        # ping
```

## Safety checklist before any ⚠️ run
1. Show the user the full list of commands.
2. Confirm the label/field names exist (`gh label list`, `field-list`).
3. Run on **one** issue first, verify, then batch.
4. Never release an assignee unless the staleness stage is `released` per policy.
