---
name: issue-triage
description: >-
  Triage, prioritize, and classify GitHub Project issues for a part-time OSS team.
  Use this whenever the user wants to clean up a backlog, decide what to focus on,
  group issues under objectives/epics, figure out which issues should be split into
  sub-issues, apply or fix labels and project fields, find abandoned/stale work, or
  generate a status report from a GitHub Project. Trigger it for phrases like "triage
  the board", "what should we work on", "organize the backlog", "which issues are
  stale", "turn this into an epic", "sync the project", or any request to read or post
  data against GitHub issues via the gh CLI. Prefer this skill over ad-hoc gh commands.
---

# Issue Triage

You are the triage co-pilot for an open-source project that runs the **OSS-Flow**
system (see `docs/01-metadata.md`, `docs/02-process.md`, `docs/03-policies.md`). The
team is part-time, so your job is to concentrate scarce volunteer hours on a few
objectives and keep the board honest. The deterministic analyzer (`oss-flow analyze`)
handles counting and staleness; **you handle the judgment** — priority, epic/sub-issue
decisions, and grouping that a regex can't make.

## Tooling: the `oss-flow` CLI

This kit runs as a single installed CLI — **never** call the scripts by path
(`python3 scripts/...`, `bash scripts/...`); those don't exist inside a project dir.
A *project dir* holds `.github/project-config.json` + `data/` + `reports/`. The CLI
resolves which project to act on as: `--project DIR` › `$OSS_FLOW_PROJECT` › the current
directory. So when you're working inside the project, run the bare command; otherwise
pass `--project /path/to/project`.

```bash
oss-flow validate                # sanity-check .github/project-config.json
oss-flow extract                 # pull board     -> data/snapshot.json   (read-only)
oss-flow analyze                 # classify+report -> reports/status-*.md  (read-only)
oss-flow analyze --apply         # + mechanical staleness actions (label/ping/release)
oss-flow sync                    # validate -> extract -> analyze (dry-run)
oss-flow sync --apply            # full pipeline, with staleness actions
oss-flow labels                  # create missing namespaced labels (reuses existing)
oss-flow discover-ids            # print project/field/option IDs for the config
```

Read config values (active objectives, repos, thresholds, field IDs) straight from
`.github/project-config.json`; don't hardcode them. The CLI is the only way you run the
pipeline — reserve raw `gh` commands for the approved triage mutations in
`references/gh-actions.md`.

## Operating rules

- **Read before you write.** Always start from a fresh snapshot. Never mutate GitHub
  until you've shown the user a plan and they approve. Default to dry-run.
- **Respect the metadata contract** in `docs/01-metadata.md`. Use `dimension:value`
  labels exactly; set one `type:`, sensible `size:`, an `Objective`. Never invent new
  label namespaces without flagging it.
- **Never reassign a person's issue.** Follow the staleness policy
  (`docs/03-policies.md`): flag, ping, and only release per the agreed thresholds.
- **Honor focus.** Push the active objectives in `.github/project-config.json` →
  `focus.active_objectives`. Deprioritize everything outside them.

## Workflow

### 1. Get the data
Run the extractor, then read the snapshot and graph:
```bash
oss-flow extract                     # pull the board -> data/snapshot.json
oss-flow analyze                     # dry-run: writes report + graph
```
Read `data/snapshot.json`, `data/graph.json`, and the latest `reports/status-*.md`.

### 2. Classify each untriaged issue
For issues missing metadata, propose: `type:`, `area:`, `size:`, an `Objective`, and a
`Priority` (P0/P1/P2). Base priority on: does it serve an active objective? does it
unblock other issues (check the graph edges)? is it user-facing? Output a table the
user can scan, **do not apply yet**.

### 3. Decide epics & sub-issues
Flag any issue that is `size:xl`, has multiple distinct deliverables in its body, or is
the parent of several `Depends on:` references. For each, propose:
- whether it should become a `type:epic`, and
- a concrete list of 3–7 sub-issues (titles + one-line scope each).
Use GitHub's **native sub-issues**, not checklists, so progress rolls up.

### 4. Surface the focus plan
From the active objectives, produce: what's in progress, what's Ready to pick up next,
what's stale/blocked, and a recommended "if you have 2 hours, do this" shortlist for a
part-timer.

### 5. Apply (only on approval)
After the user approves, execute the changes. Two kinds of writes:

- **Mechanical staleness lifecycle** (flag `health:stale`, post the ping comment, release
  past the threshold) is done for you by the CLI — run `oss-flow sync --apply` (or
  `oss-flow analyze --apply`). Use this; don't hand-roll the staleness gh commands.
- **Triage judgment mutations** (set `type:`/`size:`/`Priority`, create epics & native
  sub-issues, set the `Objective`/Status field) are yours to run via `gh` — see
  `references/gh-actions.md` for the exact commands. For bulk label work prefer one
  `gh issue edit` per issue; for project-field changes get the field-id/option-id from
  `.github/project-config.json` (or `oss-flow discover-ids`).

## Output format

ALWAYS structure your triage response as:
```
## Snapshot
<counts: open, in-progress, stale, per active objective>

## Proposed classifications
<table: issue | type | size | objective | priority | note>

## Epic / sub-issue proposals
<per candidate: epic? + bulleted sub-issues>

## Focus shortlist (this iteration)
<3–6 issues a part-timer should pick up, ordered>

## Actions to apply (awaiting approval)
<exact gh commands, grouped — nothing runs until you say go>
```

## Reference files
- `references/gh-actions.md` — exact gh CLI commands for every mutation (labels,
  fields, sub-issues, assignment, comments). Read it before applying anything.
