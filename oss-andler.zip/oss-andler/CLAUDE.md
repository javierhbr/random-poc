# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

**OSS-Flow** is a turnkey, fully-configurable kit for running a part-time open-source GitHub project. It focuses scarce volunteer hours around 2–3 monthly *Objectives*, reclaims abandoned ("zombie") issues via a staleness lifecycle, and replaces sync meetings with a twice-daily auto-generated status report. The actual project lives in **`oss-flow/`** — the loose `oss-flow-*.{py,md,json}` files and `oss-flow.zip` at the repo root are flattened copies/packaging artifacts; edit the canonical files under `oss-flow/`, not the root duplicates.

This is not a git repository.

## Commands

All commands run from inside `oss-flow/`:

```bash
python3 scripts/validate_config.py    # sanity-check config; exit 1 on any FAIL. Run after editing config.
bash scripts/setup-labels.sh          # create all namespaced labels on every repo (idempotent, --force)
bash scripts/discover-ids.sh          # print project/field/option opaque IDs to paste into config
bash scripts/sync.sh                  # full pipeline, DRY-RUN: validate → extract → analyze → report
bash scripts/sync.sh --apply          # same, but also writes to GitHub (label/ping/release stale issues)

python3 scripts/gh_extract.py         # extract step only → data/snapshot.json
python3 scripts/analyze.py            # analyze step only → reports/status-*.md + data/graph.json
python3 scripts/analyze.py --apply    # analyze + take staleness actions on GitHub
```

Prerequisites: `gh` CLI authenticated with the project scope (`gh auth login && gh auth refresh -s project`), Python 3.12, and `jq` (used by the shell scripts). There is no build, test suite, or linter — the Python scripts are run directly.

## Architecture

The system is two cooperating flows: an **issue lifecycle** (how one task moves Backlog → Ready → In Progress → Review → Validation → Done) and a **sync loop** (a read-only daemon that keeps the whole board visible). Read `docs/02-process.md` for the diagrams, `docs/03-policies.md` for the human rules (WIP limits, staleness thresholds).

### The one rule that governs everything: nothing is hardcoded

Every parameter — status column names, label scheme, field names, staleness thresholds, WIP limits, relationship keywords, comment templates, active objectives — lives in **`.github/project-config.json`**. To retarget the kit onto any GitHub project you edit *only* that file (reference: `docs/04-config.md`).

`scripts/config.py` is the single loader that enforces this. It deep-merges the JSON over a `DEFAULTS` dict and exposes a `Config` object with helper methods. **Every other script imports `config as cfgmod` and reads through `Config` — never hardcode a status name, label, or threshold in `gh_extract.py` or `analyze.py`; add/read a knob via `config.py` instead.**

Key `config.py` concept — **source resolution**: a logical attribute (`status`, `objective`, `iteration`, `priority`) can come from different places on different projects. `source.<attr>.mode` is one of `field` (a Projects v2 custom field), `label` (a `prefix:value` label), or `milestone`. `Config.resolve_attribute()` reads from whichever source that project configured, so the kit works equally on a full Projects board or on plain issues + labels + milestones. Status *roles* (backlog/ready/in_progress/…) map your real column names (lists, so synonyms/renames are fine) to the internal roles the logic keys off.

### Data pipeline (`sync.sh` orchestrates these in order)

1. **`gh_extract.py`** (read-only) — calls `gh project item-list` + `gh issue list`, merges them, resolves each logical attribute via `config.py`, parses relationship keywords (`Parent:`/`Depends on:`/`Blocks:`) out of issue bodies, and writes **`data/snapshot.json`**.
2. **`analyze.py`** — reads the snapshot, classifies each watched issue's health by `updatedAt` age against `staleness_days` thresholds (fresh → aging → stale → released), groups by Objective, computes WIP violations, builds a relationship graph, and writes **`reports/status-<date>.md`** + **`data/graph.json`**. Deterministic and read-only **unless `--apply`**, which adds `health:stale` labels, posts ping comments, and unassigns/releases issues past the release threshold.

The staleness lifecycle is the core design intent: it reclaims abandoned work *without ever reassigning a person's issue* — issues are flagged, then publicly released back to the pool per a uniform agreed policy, never yanked case-by-case.

### The AI layer (this is where Claude operates)

`analyze.py` handles counting and staleness mechanically. The **`issue-triage` skill** (`.claude/skills/issue-triage/SKILL.md`) sits on top for the judgment calls a regex can't make: priority, whether something should become a `type:epic`, which sub-issues to split it into, and what a part-timer should pick up. Three slash commands drive it: `/triage`, `/focus`, `/sync-status`.

When acting as the triage co-pilot, follow the skill's hard rules:
- **Read before you write.** Always start from a fresh snapshot (`gh_extract.py` → `analyze.py` dry-run), show a plan, and only mutate GitHub after explicit approval. Default to dry-run; `--apply` only after a dry-run has been seen this session.
- **Respect the metadata contract** (`docs/01-metadata.md`): use `dimension:value` labels exactly, one `type:`, a sensible `size:`, an `Objective`. Don't invent label namespaces.
- **Never reassign** — follow the staleness policy (flag → ping → release).
- **Honor focus** — push `focus.active_objectives` from the config; deprioritize everything outside them.
- Use the exact output format and `references/gh-actions.md` for mutation commands.

## Conventions

- Repo content is English (for international contributors).
- `data/` and `reports/` hold generated artifacts (`.gitkeep`-tracked); the GitHub Action commits regenerated reports back.
- The GitHub Action (`.github/workflows/sync.yml`) runs `sync.sh` twice daily (06:00 & 18:00 UTC) and on `workflow_dispatch`; its `apply` input toggles dry-run vs. write mode. It needs a PAT (`PROJECT_SYNC_TOKEN`) with `project`, `repo`, `read:org` scopes.
