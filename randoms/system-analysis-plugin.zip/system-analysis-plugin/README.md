# System Analysis Plugin

A reusable plugin for understanding complex topics, systems, businesses, products, architectures, habits, or problems using a combined Systems Thinking / System Dynamics method inspired by Donella Meadows and Jay Forrester.

The plugin uses the **Iceberg Model as the backbone** and augments it with:

- System context and boundaries
- Upstream / Input / Transformation / Output / Downstream analysis
- Outcomes and impact
- Stocks and flows
- Reinforcing and balancing feedback loops
- Delays and constraints
- Dependencies and information flows
- Mental models and system goals
- Leverage points
- Chain of implications
- Evidence, assumptions, and validation

## Mental Model

```text
                       SYSTEM CONTEXT

     Upstream -> Input -> [ System ] -> Output -> Downstream
                            |                      |
                      Dependencies             Outcome
                            |                      |
                      Constraints              Impact

================================================================
EVENTS
What is happening?
================================================================
PATTERNS
What repeats or changes over time?
================================================================
STRUCTURE
What produces those patterns?
- Inputs / outputs
- Stocks / flows
- Dependencies
- Rules
- Constraints
- Delays
- Information flows
- Feedback loops
================================================================
MENTAL MODELS
What goals, assumptions, incentives, beliefs, or paradigms keep
this structure in place?
================================================================
                           |
                           v
                    LEVERAGE POINTS
                           |
                           v
                 CHAIN OF IMPLICATIONS
                           |
                           v
                      VALIDATION
```

The goal is not to produce generic advice. The goal is to build a model that explains **why the system behaves the way it does**, then derive interventions from that model.

---

# Commands

The commands are intentionally conversational.

## `/understand`

Best default command. Build a complete system model of a topic or problem.

```text
/understand why our software releases keep getting slower
```

Optional context:

```text
/understand customer eligibility decisions
Context: multi-tenant service, 5 rule groups, 4 downstream data providers.
Goal: understand why onboarding a new tenant is difficult.
```

Expected result:

```text
System summary
System boundary and purpose
Upstream -> input -> transformation -> output -> downstream
Iceberg analysis
Stocks and flows
Feedback loops
Delays / constraints / dependencies
Mental models
Leverage point candidates
Unknowns and evidence gaps
```

---

## `/map-system`

Use when you first need orientation: what the thing is, where inputs come from, where outputs go, and why it matters.

```text
/map-system API gateway
```

Expected result:

```text
Purpose
Boundary
Upstream sources
Inputs
Core transformations / decisions
Outputs
Downstream consumers
Outcomes
Impact
Dependencies
Failure consequences
```

---

## `/iceberg`

Analyze a topic using the four Iceberg layers.

```text
/iceberg engineers are constantly missing deadlines
```

Expected result:

```text
EVENTS
- Current visible symptoms

PATTERNS
- Recurring behaviors and trends

STRUCTURE
- Rules
- Information flows
- Dependencies
- Delays
- Incentives
- Stocks / flows
- Feedback loops

MENTAL MODELS
- Assumptions
- Goals
- Beliefs
- Paradigms
```

---

## `/trace-flow`

Follow information, value, money, decisions, materials, or work from source to impact.

```text
/trace-flow customer complaint from support ticket to product change
```

Expected result:

```text
Source -> Input -> Transformation -> Output -> Consumer -> Outcome -> Impact

For each transition:
- owner
- information/value transferred
- dependency
- delay
- loss/distortion risk
```

---

## `/find-loops`

Find reinforcing and balancing feedback loops.

```text
/find-loops technical debt in a fast-moving product team
```

Expected result:

```text
R1 - Delivery Pressure Loop
Pressure -> shortcuts -> debt -> slower delivery -> missed deadlines -> pressure

B1 - Refactoring Control Loop
Debt -> pain visibility -> refactoring investment -> debt reduction

For each loop:
- polarity
- delay
- trigger
- strength
- evidence
```

---

## `/find-leverage`

Find leverage points only after building enough system context.

```text
/find-leverage our engineering organization has high WIP and slow delivery
```

Expected result:

```text
Candidate 1: WIP policy
System mechanism affected: balancing / reinforcing loop
Chain of implications
Potential blockers
Expected side effects
Evidence confidence
Leverage depth

Ranked candidates
```

The command should reject shallow generic advice when no causal mechanism is available.

---

## `/why-this-matters`

Use when you understand what something does technically but not its relevance.

```text
/why-this-matters eligibility service
```

Expected result:

```text
Immediate output
Downstream consumers
Operational outcomes
Business outcomes
Risk / compliance consequences
What breaks if removed
What becomes possible if improved
```

---

## `/challenge-model`

Attack an existing system model. Look for unsupported causal links, missing loops, hidden dependencies, alternative explanations, and counter-loops.

```text
/challenge-model
Hypothesis: Better documentation is the highest leverage point for AI-assisted development.
```

Expected result:

```text
Supported relationships
Inferred relationships
Unsupported assumptions
Alternative causal explanations
Potential blockers
Counter-loops
Evidence needed
Revised hypothesis
```

---

## `/compare-levers`

Compare multiple interventions using systemic impact rather than popularity.

```text
/compare-levers
1. Hire 3 engineers
2. Reduce WIP
3. Improve CI feedback time
4. Increase sprint length
```

Expected result:

```text
Intervention
System mechanism changed
Leverage depth
Expected chain of implications
Time-to-effect
Potential counter-effects
Ongoing effort
Reversibility
Evidence confidence
Rank
```

---

# Recommended Workflow

For a new topic:

```text
/understand <topic>
```

For deeper work:

```text
/map-system <topic>
/iceberg <problem or topic>
/find-loops <system>
/find-leverage <goal or problem>
/challenge-model <hypothesis>
```

The commands can also be chained by an orchestrator.

---

# Skills

## `system-framing`
Defines purpose, boundary, actors, scope, context, and the question being answered.

## `flow-tracing`
Maps upstream -> input -> transformation -> output -> downstream -> outcome -> impact.

## `iceberg-analysis`
Builds Events -> Patterns -> Structure -> Mental Models.

## `stock-flow-analysis`
Identifies accumulations and the flows that increase/decrease them.

## `feedback-loop-analysis`
Finds reinforcing and balancing loops and their delays.

## `leverage-analysis`
Derives leverage points from system structure and ranks them by systemic impact.

## `causal-validation`
Separates observed evidence from inference and assumption.

## `model-challenger`
Looks for alternative explanations, missing variables, counter-loops, and false causal chains.

## `system-synthesis`
Combines all analyses into one human-readable system model.

---

# Example: Why Are Software Releases Getting Slower?

Prompt:

```text
/understand why our releases are getting slower

Context:
- 25 engineers
- 4 teams
- weekly release target
- many cross-team dependencies
- management measures utilization and sprint completion
```

Expected result (abridged):

```text
SYSTEM PURPOSE
Reliably move validated product changes into production.

BOUNDARY
Starts when work is committed for implementation.
Ends when the change is validated in production.

FLOW
Product priorities
  -> sprint commitments
  -> implementation
  -> review
  -> integration
  -> validation
  -> production release
  -> customer / business outcome

ICEBERG

EVENTS
- Releases miss weekly target.
- Teams frequently carry work across sprints.

PATTERNS
- Lead time is increasing.
- Work in progress is increasing.
- Cross-team blockers are becoming more frequent.

STRUCTURE
- Teams are rewarded for utilization.
- More work is started than the system can finish.
- Shared dependencies create queues.
- Feedback from integration arrives late.

STOCKS
- Work in progress
- Unreviewed code
- Technical debt
- Unresolved dependencies

REINFORCING LOOP R1
Delivery pressure
 -> start more work
 -> higher WIP
 -> more context switching / queues
 -> longer cycle time
 -> missed commitments
 -> more delivery pressure

MENTAL MODEL
"Keeping everyone busy maximizes delivery."

LEVERAGE CANDIDATE
Limit WIP at the system level rather than maximizing individual utilization.

CHAIN OF IMPLICATIONS
Lower WIP
 -> fewer parallel dependencies
 -> shorter queues
 -> faster feedback
 -> shorter cycle time
 -> more predictable releases
 -> less delivery pressure
 -> lower incentive to start excess work

BLOCKERS
- Incentives still reward utilization.
- Leadership may interpret idle capacity as waste.

EVIDENCE TO VALIDATE
- WIP vs lead time over 3-6 months
- blocked time by dependency
- queue time vs active development time
```

---

# Example: Understand a Technical Component

Prompt:

```text
/why-this-matters policy evaluation service
```

Expected result:

```text
INPUT
Customer attributes + account state + tenant policy.

TRANSFORMATION
Evaluate the policy against customer state.

OUTPUT
Eligibility decision + reason codes.

DOWNSTREAM
Application flow, offers, compliance controls, analytics.

OUTCOME
Determines what products/actions are available to the customer.

IMPACT
Customer experience, conversion, risk exposure, and regulatory compliance.

WHY IT MATTERS
The service is not merely a boolean decision engine. It is a control point
that influences customer access, product revenue, and policy enforcement.
```

---

# Design Principles

1. **Iceberg first**: surface symptoms are not root causes.
2. **Context before advice**: no leverage recommendation without a defined system.
3. **Trace inputs and outputs**: understand where the system sits in a larger environment.
4. **Behavior over snapshots**: patterns over time matter more than isolated events.
5. **Loops over linear stories**: causal chains should be checked for feedback.
6. **Mechanism before recommendation**: every intervention must identify what system mechanism it changes.
7. **Evidence-aware**: distinguish observed, inferred, and assumed relationships.
8. **Dynamic models are hypotheses**: every model should be challengeable and updateable.
9. **No generic leverage points**: leverage is context dependent.
10. **Explain relevance**: connect technical outputs to downstream outcomes and impact.

---

# Output Schema

A machine-readable schema is included in `schemas/system-analysis.schema.json`.

A reusable human-readable template is included in `templates/system-analysis.md`.

