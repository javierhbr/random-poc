# Skill: flow-tracing

## Purpose
Understand where information/value/work comes from, what happens to it, where it goes, and why the output matters.

## Canonical Flow
Upstream -> Input -> Transformation -> Output -> Downstream -> Outcome -> Impact

## For each stage identify
- source / owner
- information, value, material, decision, or resource transferred
- format / state
- dependency
- delay
- failure or distortion risk
- consumer

## Important distinction
Output is not the same as Outcome, and Outcome is not the same as Impact.
