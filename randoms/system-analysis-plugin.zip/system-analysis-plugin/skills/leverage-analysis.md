# Skill: leverage-analysis

## Purpose
Derive candidate leverage points from the system model.

## Required Preconditions
Do not recommend leverage points until at least one structural mechanism or feedback loop is identified.

## For each candidate
- intervention
- mechanism changed
- leverage depth
- chain of implications
- expected time to effect
- blockers
- counter-effects
- ongoing effort
- reversibility
- evidence confidence

## Leverage Depth Heuristic
Shallower -> parameters / numbers / buffers
Middle -> information flows / feedback / rules
Deeper -> system goals / self-organization / mental models / paradigms

## Rule
Popular advice without a modeled mechanism is not a leverage point.
