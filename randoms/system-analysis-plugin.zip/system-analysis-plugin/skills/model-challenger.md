# Skill: model-challenger

## Purpose
Try to falsify or weaken the current system model.

## Look for
- missing actors
- missing stocks or flows
- hidden dependencies
- alternative explanations
- counter-loops
- boundary mistakes
- goal conflicts
- delayed effects
- correlation treated as causation
- intervention side effects

## Output
- strongest challenge
- missing elements
- questionable causal links
- alternative model
- evidence needed
- recommended model revision
