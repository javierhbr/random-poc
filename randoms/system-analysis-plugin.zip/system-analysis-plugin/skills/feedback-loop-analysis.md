# Skill: feedback-loop-analysis

## Purpose
Find circular causal mechanisms that generate system behavior.

## Loop Types
- Reinforcing (R): amplifies movement.
- Balancing (B): resists deviation or seeks a goal.

## For each loop output
- name
- type
- causal chain
- loop narrative
- key stock(s)
- delays
- activation conditions
- possible counter-loop
- evidence strength

## Rule
Prefer explicit causal chains, e.g.:
Pressure -> shortcuts -> debt -> slower delivery -> missed deadlines -> pressure.
