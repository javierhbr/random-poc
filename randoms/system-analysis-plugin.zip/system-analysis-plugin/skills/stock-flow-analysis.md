# Skill: stock-flow-analysis

## Purpose
Identify what accumulates and what changes those accumulations.

## Method
For each stock:
- Name the stock.
- Explain why it matters.
- Identify inflows.
- Identify outflows.
- Identify capacity limits.
- Identify measurement signals.

## Examples
Backlog: inflow=new work, outflow=completed/cancelled work.
Trust: inflow=reliable interactions, outflow=failures/betrayals.
Technical debt: inflow=shortcuts/obsolete design, outflow=refactoring/removal.
