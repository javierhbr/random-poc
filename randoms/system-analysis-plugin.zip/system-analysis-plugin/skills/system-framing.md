# Skill: system-framing

## Purpose
Define the system before analyzing it.

## Inputs
- Topic, problem, or decision
- Available context
- User goal

## Method
1. State the question to answer.
2. Define the system purpose.
3. Define what is inside and outside the boundary.
4. Identify actors and major components.
5. Identify current state and constraints.
6. State unknowns explicitly.

## Output
- Analysis question
- Purpose
- Boundary
- Actors
- Current state
- Constraints
- Unknowns
