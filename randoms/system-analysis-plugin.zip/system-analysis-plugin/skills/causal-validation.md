# Skill: causal-validation

## Purpose
Prevent plausible-looking causal stories from being mistaken for evidence.

## Classify every important relationship as
- Observed
- Evidence-supported
- Inferred
- Assumed
- Unknown

## Questions
- What evidence supports A -> B?
- Could B cause A?
- Is there a hidden variable C?
- Is the relationship delayed?
- Is the relationship conditional?
- Is there contradictory evidence?
