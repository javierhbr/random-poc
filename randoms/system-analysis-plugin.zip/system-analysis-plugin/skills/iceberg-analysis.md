# Skill: iceberg-analysis

## Purpose
Use the Iceberg Model as the primary depth model.

## Layers
### Events
Visible symptoms, facts, decisions, incidents, or advice.

### Patterns
Trends, recurrence, behavior over time, repeated relationships.

### Structure
Rules, incentives, information flows, dependencies, stocks, flows, delays, constraints, feedback loops, architecture, organization, process.

### Mental Models
Beliefs, assumptions, goals, paradigms, values, definitions of success.

## Rule
Do not label an event as a root cause. Continue downward until structural mechanisms are identified.
