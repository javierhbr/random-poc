# Skill: system-synthesis

## Purpose
Combine all analyses into a coherent explanation a human can use.

## Required order
1. System question
2. Purpose / boundary
3. Context map
4. Iceberg
5. Stocks and flows
6. Feedback loops
7. Delays / constraints / dependencies
8. Mental models
9. Leverage candidates
10. Evidence / assumptions / unknowns
11. Suggested validation or experiment

## Style
Explain causal mechanisms plainly. Avoid jargon where a simple phrase works.
