# /trace-flow

Trace information, value, work, money, material, or decisions through a system.

Run flow-tracing.

Use the canonical chain:
Upstream -> Input -> Transformation -> Output -> Downstream -> Outcome -> Impact.
