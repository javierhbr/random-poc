# /find-leverage

Find and rank leverage points.

Run system-framing if needed, then feedback-loop-analysis, leverage-analysis, and causal-validation.

Reject recommendations that cannot name the structural mechanism being changed.
