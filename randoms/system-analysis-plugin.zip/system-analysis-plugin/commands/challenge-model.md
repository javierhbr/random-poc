# /challenge-model

Challenge a system model, causal hypothesis, or proposed leverage point.

Run model-challenger + causal-validation.

Prefer falsification over agreement.
