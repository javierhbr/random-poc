# /understand

Build a complete system model of the supplied topic, problem, or decision.

## Orchestration
Run:
1. system-framing
2. flow-tracing
3. iceberg-analysis
4. stock-flow-analysis
5. feedback-loop-analysis
6. causal-validation
7. leverage-analysis
8. system-synthesis

## Behavior
If context is incomplete, make explicit assumptions and mark them as assumptions rather than blocking the analysis.

## Output
Use `templates/system-analysis.md`.
