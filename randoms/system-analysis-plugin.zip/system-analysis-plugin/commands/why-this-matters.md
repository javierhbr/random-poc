# /why-this-matters

Explain the relevance of a topic or component by tracing its downstream consequences.

Run flow-tracing with emphasis on Output -> Consumer -> Outcome -> Impact and failure consequences.
