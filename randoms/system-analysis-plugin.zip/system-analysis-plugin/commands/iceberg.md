# /iceberg

Analyze the supplied topic using Events -> Patterns -> Structure -> Mental Models.

Run iceberg-analysis and causal-validation.

Inside Structure, explicitly include inputs/outputs, stocks/flows, dependencies, rules, constraints, delays, incentives, information flows, and known loops.
