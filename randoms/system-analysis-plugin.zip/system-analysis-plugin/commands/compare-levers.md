# /compare-levers

Compare proposed interventions based on system mechanism and likely systemic effect.

Run leverage-analysis + causal-validation.

Rank by:
- leverage depth
- size of expected systemic effect
- strength of causal mechanism
- blockers / counter-effects
- time to effect
- ongoing effort
- evidence confidence
