# /map-system

Orient the user within a system.

Run system-framing + flow-tracing.

Emphasize:
Purpose, boundary, upstream, inputs, transformation, outputs, downstream, outcomes, impact, dependencies, failure consequences.
