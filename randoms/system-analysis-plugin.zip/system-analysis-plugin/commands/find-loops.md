# /find-loops

Identify reinforcing and balancing loops that explain observed behavior.

Run feedback-loop-analysis + causal-validation.

Do not return isolated linear chains unless you explain whether and where they close into feedback.
