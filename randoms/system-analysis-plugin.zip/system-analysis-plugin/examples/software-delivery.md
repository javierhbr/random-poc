# Example — Software Delivery System

## Prompt

```text
/understand why our releases are getting slower

Context:
- 25 engineers
- 4 teams
- weekly release target
- many cross-team dependencies
- management measures utilization and sprint completion
```

## Expected Shape

### Question
Why is release lead time increasing despite high engineer utilization?

### Context Map

```text
Product priorities -> sprint commitments -> implementation -> review
-> integration -> validation -> production -> customer outcome
```

### Iceberg

**Events**
- Weekly release target is missed.
- Work carries over between sprints.

**Patterns**
- WIP increases.
- Lead time increases.
- More work is blocked by other teams.

**Structure**
- Utilization is rewarded.
- Teams start work before dependencies are ready.
- Integration feedback comes late.
- Shared dependencies create queues.

**Mental Model**
- "Keeping every engineer busy maximizes throughput."

### Feedback Loop

```text
Pressure -> start more work -> higher WIP -> longer queues
-> slower delivery -> missed commitments -> pressure
```

### Leverage Candidate
Limit WIP across the delivery system.

### Chain of Implications

```text
Lower WIP -> fewer parallel dependencies -> shorter queues
-> faster feedback -> shorter cycle time -> more predictability
-> less pressure -> less incentive to overload the system
```

### Validation
Measure WIP, blocked time, queue time, and lead time over multiple releases.
