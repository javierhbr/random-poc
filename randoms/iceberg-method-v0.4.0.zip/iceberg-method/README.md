# iceberg-method

**Understand why something keeps happening — instead of getting another summary of it.**

Ask most AI tools about a problem and you get a description of what you already told them. This
skill does something different: it works downward from what you can see, to what repeats, to the
machinery producing it, to the beliefs that keep rebuilding that machinery. Then it shows you
where to push — and before you act on any of it, sends independent adversaries in to try to
break the whole thing.

It works on recurring workplace problems, a stack of documents you're trying to understand, or a
codebase that keeps breaking in the same place.

---

## The idea in one picture

```
What you see                "Our releases take too long."
       ↓
What repeats                3 days → 17 days over 20 weeks. Headcount never changed.
       ↓
Why it happens              Pressure → more parallel work → context switching → slower
                            → more pressure. A loop that feeds itself.
       ↓
What people believe         "Idle engineers are waste." Remove the loop and this
                            belief rebuilds it within a quarter.
       ↓
Where to push               Cap work-in-progress. Structural, reversible, and it makes
                            the belief visibly false — which no argument does.
       ↓
Try to break it             Four independent critics attack the analysis. One finds a
                            rival explanation that fits the same numbers.
       ↓
What should happen          Worse for 2 weeks, then 8 days by week 6. If nothing moves
                            by week 8, the model is wrong.
```

Each layer has to explain the one above it. That single rule is what stops this from being a
vocabulary exercise.

---

## How to use it

**One prompt, and it runs.** Give it the material and it carries the analysis to the end on its
own, showing you what it found between steps. You don't have to know any commands.

### Starting out — pass it whatever you have

| What you type | What it does |
|---|---|
| `/iceberg why do our releases keep slipping` | A described problem. The description is the starting point. |
| `/iceberg ./docs/onboarding/` | A folder. Reads what's relevant, tells you what it skipped. |
| `/iceberg ./src/payments` | Source code. Computes the trends from git history and CI, instead of guessing them. |
| `/iceberg <paste a long block of text>` | Treats the text itself as the source material. |
| `/iceberg analyse how our escalation process works — ./runbooks/ + this thread` | Mixed input is the normal case. |
| `/iceberg` | Nothing to go on, so it shows you a menu. |

It works out what kind of material it got and adapts. Override with `--mode corpus|org|technical`
if it guesses wrong.

**If you have the `local-search` CLI**, you don't even need a path — ask a question and it
searches your local index, then reads the files behind the results. It runs a different query
strategy per layer (recent specs for trends, the graph and `related` for structure, "we assume"
and "by design" for beliefs, "deprecated" and "postmortem" for what's already been tried), and
writes the queries it ran into the file — because what it *didn't* search is part of the
boundary.

### Steering it — only if you want to

You don't need any of these to get a finished analysis. They're for going back, jumping to a
layer, or re-running one piece.

| What you type | What happens |
|---|---|
| `/iceberg next` | Continues to the next unfinished step |
| `/iceberg back` | Redoes the step you just did |
| `/iceberg scope` | What's inside the system, and what you're leaving out |
| `/iceberg see` | What you're observing — and who's observing it, measured how |
| `/iceberg trends` | What changed over time, and what didn't |
| `/iceberg why 2` | Build the feedback loop behind trend 2 |
| `/iceberg beliefs` | Why that structure exists and keeps coming back |
| `/iceberg options` | Three ranked places to intervene |
| `/iceberg challenge` | Send in independent critics to try to break the analysis |
| `/iceberg predict 1` | Write down what should happen if you do option 1 |
| `/iceberg result "lead time hit 9d in week 5, leadership nervous"` | Record what actually happened, and revise whichever layer was wrong |
| `/iceberg check` | Audit the analysis for holes |
| `/iceberg document` | Write the readable explanation from the analysis |
| `/iceberg export` | Export it as prompts you can paste into another tool |
| `/iceberg new` | Start a fresh analysis instead of continuing the current one |

You refer to things by the number you can see — `why 2`, `predict 1` — not by codes you'd have
to memorise.

### It confirms, it doesn't interrogate

Between steps you get a short checkpoint — what it found, what it's doing next stated as a
decision already made, and a couple of ways to redirect if you want them. Then it **keeps going**.
You don't answer a checkpoint; you interrupt only if you want something different.

> **Trends: lead time 3d → 17d over 20 weeks. Concurrent initiatives 2 → 7. Headcount never moved.**
> Next: building the loop behind those two.
> *Redirect: `/iceberg back` to re-cut the boundary · better numbers for trend 3 · `/iceberg why 3` instead*

It only asks a real question when the material genuinely can't settle something that changes the
analysis — an ambiguous boundary, two archetypes that fit equally well, missing time-series data
you might have, or an unclear "who is actually complaining". Four situations, and even then it
comes with options and a recommendation, never an open question.

**It never assumes silently.** When it can't satisfy a step from your material, it uses what it
has, writes the gap into the file, and tells you at the checkpoint — rather than either stopping
or quietly papering over it.

After a prediction it offers to **schedule the check-in**, a few days after your own falsifier
date. That's the step everyone skips, and it's the one that turns this from analysis into
something you learn from.

**Running unattended?** On a scheduled task it doesn't checkpoint at all — it runs the whole
chain including the adversarial challenge, and records every decision it made for you at the top
of the file.

### Things you can just say

> "Why does this keep happening no matter what we try?"

> "Run the iceberg on these three reports — what system are they actually describing?"

> "Try to break my analysis before I take this to my VP."

> "Here's what happened after we tried it. Which part of my model was wrong?"

---

## What you get out of it

### 1. A document you can hand to someone — and the working file behind it

Two files, not one:

- **`how-<topic>-works.md`** — the explanation, written to be read. No IDs, no scaffolding. This
  is the thing you asked for. It still says plainly what's uncertain and what the critics
  overturned.
- **`<topic>-iceberg.md`** — the working canvas underneath it: every claim with its source
  label, the gaps, the challenge verdicts, the predictions.

Both are written in whatever language you asked in.

The canvas matters more than it sounds:

- **You can stop and come back.** The analysis doesn't evaporate when the conversation ends.
- **You can hand it to someone.** It's a document, not a transcript.
- **You can return after acting.** Six weeks later, `/iceberg result "what happened"` reopens
  the file and checks it against what you predicted.

### 2. Charts of what's actually moving

Where you have real numbers, you get behavior-over-time charts — and one of them is always
something that *didn't* change. Headcount flat while workload tripled tells you more than either
figure alone.

### 3. A loop you can argue with

Not "there are many contributing factors." A specific, named feedback loop, with how long it
takes to show its effects, and a line saying **what would prove it wrong**. If nothing could
disprove it, it isn't an explanation.

### 4. Three ranked places to intervene — scored on whether you can actually do them

Every candidate gets three scores, not one:

- **Leverage** — how deep it acts
- **Tractability** — can you or someone you can reach actually authorise it? What blocks it?
- **Reversibility** — can you undo it cheaply if you're wrong?

Deeper is more powerful *and* harder. The usual failure of systems thinking is diagnosing a
paradigm, telling everyone their beliefs are wrong, and changing nothing. Ranking on all three
axes is the fix.

### 5. An adversarial review by critics who never saw your reasoning

`/iceberg challenge` sends four independent reviewers at the analysis. They get the file and the
underlying data — never the conversation that produced them, because a critic who watched you
build something is no longer independent.

- **Rival explanation** — builds the best *different* structure that fits the same numbers, and
  names the one observation that would tell the two apart. If a credible rival exists, you didn't
  have an explanation, you had a story.
- **Evidence** — checks every claim against your material, catches anything labelled as fact that
  isn't, and names the single claim your whole analysis rests on.
- **Loop mechanics** — finds the weakest link in the chain, and checks whether things moved
  faster than your loop's own timing allows. That one kills a lot of plausible theories.
- **Intervention realism** — argues that each of your three options fails, names the blocker you
  didn't want to see, and says which one it would actually bet on.

Each finding comes back marked **survives**, **weakened**, or **refuted**, tied to the specific
line it attacks. Refuted findings send you back a step rather than being quietly edited away.
Worth running before you take anything to a room full of people.

### 6. A prediction with a date on it

Before you act, you write down what should happen and when — including the part that gets
interventions cancelled: *it will look worse for the first two weeks, and here is the side effect
people will misread as failure.* Plus a specific date by which, if nothing has moved, you were
wrong.

This turns "we tried it and it didn't seem to help" into something you can actually learn from.

### 7. An honesty label on every line

Every claim is tagged:

- **[S]** — stated in your sources or directly observed
- **[I]** — inferred by combining things
- **[G]** — general knowledge from outside your material

That third tag is the point. It's how you tell facts from the model filling in gaps that look
like facts.

And it doubles as a diagnostic: if the deep layers come back mostly **[G]**, the skill says so
outright — *your sources describe only the surface of this system, and you need different
inputs.* That's often the most useful thing it can tell you.

---

## The three modes

The skill adapts to what you brought:

- **org** — recurring workplace and process problems. Delivery slowdowns, rework, attrition,
  meeting load. The natural home of the method.
- **corpus** — documents, papers, research. Strict per-source attribution, and it will tell you
  when your sources are too shallow to support the analysis.
- **technical** — codebases, pipelines, incident histories. The one mode where the patterns get
  *computed* from git and CI rather than guessed at.

Set with `--mode`, or let it detect from what you brought.

---

## When not to use it

The skill will decline and just answer you directly if:

- **It's a one-off failure with a real root cause.** Then debug it. This method is for things
  that come back.
- **There's no behavior over time** — a spec, a contract, a proof. Just read it.
- **You wanted a summary.** Then you should get a summary.

---

## Status

v0.4.0. Deferred to a later version: a script that mechanically audits the analysis for gaps.
Until then `/iceberg check` does those audits by reading the file.

Built on the Iceberg model and Donella Meadows' work on leverage points, with the systems
archetypes from Senge and the firefighting dynamic from Repenning and Sterman.
