---
name: iceberg
description: Runs the Iceberg method on any topic, document set, problem, or system - descending from the visible event to patterns over time, to the structure producing them, to the mental models that keep that structure in place, then scoring leverage points and writing a falsifiable prediction. Use when the user asks why something keeps happening, wants to understand what is really going on beneath a problem, asks what is driving a recurring pattern, wants leverage points or where to intervene, mentions systems thinking, feedback loops, reinforcing or balancing loops, stocks and flows, Meadows, or the Iceberg model, or invokes /iceberg. Also use when the user wants an existing analysis stress-tested, challenged, or attacked by an independent critic before they act on it. Do not use for one-off failures with a single root cause, for static artifacts with no behavior over time, or when the user just wants a summary.
---

# The Iceberg Method

Run a structured descent through four layers of a system, then act on it. State lives in a
**canvas file**, not in the conversation - that is what makes this a method rather than a set of
prompts.

## The one rule

**Every layer must explain the layer above it.**

A stage is not finished when its checklist is covered. It is finished when it accounts for the
specific thing found one level up. Enforce this at every gate. Do not let breadth of vocabulary
substitute for explanatory power.

## Do not use this method when

Say so plainly, offer the direct alternative, and stop:

- **A one-off failure with an actual root cause.** Debug it. The Iceberg is for behavior that
  recurs and resists fixing.
- **A static artifact with no behavior over time** - a proof, a spec, an API contract, a legal
  clause. Explain it directly.
- **The user genuinely wants a summary or a fact.** Give them that.

Do not hijack a summary request. If the request is genuinely ambiguous, run the method and say in
one line at the top that a plain summary is available instead - do not open with a question.

## The commands

**The commands are for steering, not for driving.** The normal path is one invocation -
`/iceberg <material>` - and then confirming at each checkpoint. A user who never types any of
these words should still reach a finished document. They exist for going back, jumping to a
layer, or re-running one piece.

| Command | Works on | Takes |
|---|---|---|
| `next` | runs the next stage whose gate is unmet, then checkpoints | - |
| `back` | redoes the most recently completed stage | - |
| `scope` | FRAME - what is in and out of the system | - |
| `see` | EVENT - what is observed, by whom, measured how | - |
| `trends` | PATTERNS - what changed over time, and what did not | - |
| `why` | STRUCTURE - the loop producing the trends | optional trend number |
| `beliefs` | MENTAL MODELS - why that structure exists | - |
| `options` | LEVERAGE - three ranked places to intervene | - |
| `predict` | PREDICTIONS - what should happen if you act | option number |
| `result` | OBSERVATIONS - what actually happened | quoted text or a file path |
| `challenge` | independent adversaries try to break the analysis | optional canvas ID |
| `document` | writes the readable explanation from the canvas | - |
| `check` | audits the canvas for holes | - |
| `export` | the portable prompt pack for another tool | - |
| `new` | starts a fresh canvas | - |

Modifiers: `--file <path>` targets a specific canvas; `--mode corpus|org|technical` overrides
detection; `strict` **as the final token** makes a failed gate block instead of warn - only as
the last word, so a topic containing the word "strict" is not mangled.

**Numbers, not IDs.** The user says `why 2` and `predict 1`. Map those to the canvas IDs `P2`
and `L1`. Accept `P2` and `L1` typed directly as well, silently.

**`challenge` is the exception** - it takes a full ID (`challenge S1`, `challenge L2`), because
a bare number cannot say which layer is meant. A bare number after `challenge` is ambiguous:
offer the canvas's real structure, belief and option entries as options instead of guessing.

## Parsing the invocation

1. **Extract modifiers first**, conservatively, because pasted material must survive intact:
   `--file <path>` and `--mode <value>` only where they open a token; `strict` only as the very
   last word. Never inside quoted text or a pasted block. Never treat a modifier as material.

2. **First token matches a command word?** Then decide by whether it has a well-formed target:

   - `why`, `predict` take a **number or an ID**; `challenge` takes an **ID**. `why 2` is the
     stage. `why do our releases keep slipping` is a topic - the remainder is prose, not a
     number. Bare `challenge` attacks the whole canvas and is complete as it stands.
   - `new` takes an **optional topic**: bare `new` shows the no-canvas menu; `new <remainder>`
     starts a fresh canvas on that remainder, skipping canvas resolution. A genuine topic that
     begins with the word "new" must be rephrased or run with `--file`.
   - `result` takes **quoted text or a file path**. `result "lead time hit 9d"` is the stage.
     `result of our hiring freeze` is a topic.
   - Everything else takes **no target**. Bare, it is the stage. With a remainder, the whole
     string is a topic - `scope` runs the scope stage, `scope of our on-call rota` is a topic.

3. **Otherwise** the whole string is the material: run the full chain on it, forward, with
   checkpoints. Detect what kind of material it is and set the mode accordingly:

   Material can be a described problem, a directory, a repository, a single file, a pasted
   block, URLs, or a question answerable from a `local-search` index - commonly a mix. Set the
   mode by the ordered test in `references/profiles.md`, which tests for **technical first**
   because misfiling a repo as corpus throws away the computed trends. State the mode you chose
   at the first checkpoint; never ask. `--mode` overrides.

   **No observer in the material?** A source path has no complainant. Record the user as the
   observer, tag it `[I]`, and name it at the checkpoint. This is not one of the four forks.

4. **Nothing at all** - show the menu. Never guess.

5. **A command that needs a canvas, but none exists** - show the menu, prefixed with one line
   saying there is nothing yet to run it against.

**Canvas resolution.** `--file` if given. Otherwise the most recently modified `*-iceberg.md` in
the working folder or the user's connected folder - but use it silently only when no topic was
supplied. If material was given and it does not plausibly match that canvas's `# Iceberg:`
header, ask which the user means before writing anything. `new` skips resolution and starts
fresh.

**The full chain**, run when material is given: `scope`, `see`, `trends`, `why`, `beliefs`,
`options`, `challenge`, `predict`, `document` - checkpointing at every gate and continuing in
the same turn. Scope always runs first; it is what determines what counts as an event. The chain
ends with the written document, not with the canvas.

Running forward, stages that normally take a target take the obvious one and say so: `why` takes
the strongest unexplained trend, `predict` takes the top-ranked option. The "never infer a
missing target" rule governs a bare command the **user** typed, not the forward chain.

**`back`** re-runs the last completed stage. Warn that layers below it are now provisional, and
offer to re-check them afterwards.

### No arguments, or an unrecognised one: show the menu

With no canvas, ask what to run the method on (a recurring problem; documents or sources; a
technical system; explain the method first). With a canvas, read it and offer continuing at the
next open gate, named exactly - "the loop behind trend 2 is missing". An unrecognised first
token gets the same menu with one line saying what was not understood; never error out. Full
wording in `references/interaction.md`.

**A missing target on a command the user typed** - resolve it by presenting the canvas's real
values as options, never by inferring. `why` with no number offers the trends by their actual
text; `predict` with no number offers the scored options; `result` with no target offers the
open predictions and asks what happened. Bare `challenge`, `document` and `new` are complete
commands, not missing targets. This rule does not apply to the forward chain, which takes the
obvious target and says which it took.

**Non-interactive and nothing to work on** - a scheduled run with no material and no canvas:
print the command list as plain text and stop. A non-interactive run that *does* have material
or a canvas runs the full chain instead; see "Unattended runs".

## The canvas

One file per topic: `<slug>-iceberg.md`. Write it to the user's connected folder if one exists,
otherwise the session workspace, and deliver it with SendUserFile after every stage.

Start from `assets/canvas-template.md`. Read `assets/example-release-iceberg.md` when unsure
what a finished canvas should look like. Rules:

- **Stable IDs**: `E1` event, `P1` pattern, `S1` structure, `M1` mental model, `L1` leverage,
  `X1` prediction, `O1` observation. These stay in the file; the user talks in numbers.
- **Explicit links.** P, S and M entries carry `explains: <ids>`. L entries use `targets: <S-id
  or M-id>`; X entries use `for <L-id>`; O entries use `against <X-id>`. These link fields are
  what the gates check.
- **Provenance tag on every substantive line**, three-way:
  - `[S]` stated in a source or directly observed
  - `[I]` inferred by combining sources
  - `[G]` general knowledge from outside the material

  Tag every line that asserts something about the world - including prediction and observation
  lines. Exempt: link fields (`explains:`, `targets:`, `for`, `against`) and enum or score
  fields (`layer:`, `leverage:`, `tractability:`, `reversible:`, `status:`). `[ ]` in the
  template is an empty slot - replace it, never leave it blank. `[G]` is the tag that matters:
  it is how outside knowledge gets smuggled in looking like inference.

After writing the structure and mental-model layers, compute the provenance mix. If those two
sections are more than roughly 80% `[G]`, tell the user directly: *the sources describe only the
surface of this system; the deep layers here are me reasoning, not your material - you need
different inputs.* This is the most useful thing the method can report on a thin corpus.

## Gates

Checkpoint at each gate and show the user what was written.

| Stage | Gate - satisfied when |
|---|---|
| `scope` | something is explicitly named as **outside** the boundary |
| `see` | the observer and the chosen metric are recorded, not just the complaint |
| `trends` | **two or more variables that changed** over the same window, **plus at least one that stayed flat** |
| `why` | every P-id appears in some `explains:`, and every loop has a `falsified if:` line |
| `beliefs` | each model would predict the structure being **rebuilt** if dismantled, and at least one `observer-model:` entry exists |
| `options` | three candidates, each scored on leverage x tractability x reversibility with a blocker named |
| `challenge` | every lens that applies has reported; each attacked ID carries SURVIVES, WEAKENED or REFUTED; and every REFUTED verdict, WEAKENED verdict and provenance correction has been acted on per the table in `references/challenge.md` - not absorbed by editing the claim until it survives |
| `predict` | expected curve, expected delay, worse-before-better named, and a dated falsifier |
| `result` | outcome recorded against the X-id, plus either a named wrong layer with its revision or an explicit statement that no layer needed revising |
| `document` | the readable explanation exists, is written from the canvas, and states what is uncertain |
| `check` | the four audits below have all run |

`why <n>` scopes the work to one trend.

**The challenge gate is conditional.** The forward chain always runs `challenge` after `options`.
But a user who jumped straight to `predict` has not, and their canvas is not broken for it -
`check` reports the gate as "not run" rather than failed. Every other gate is unconditional.

Default on a failed gate: **fill what the material supports, record the gap, keep going** - see
"When a gate cannot be satisfied" below. With `strict`, block.

**Reference loading.**

| Read | When |
|---|---|
| `references/profiles.md` | at the start of any run that creates a canvas |
| `references/interaction.md` | before the first checkpoint of any run |
| `references/stages.md` | before `scope`, `see`, `trends`, `why` or `beliefs` |
| `references/archetypes.md` | before `why` (with `stages.md`) |
| `references/local-search.md` | in corpus mode, when the `local-search` CLI is available |
| `references/leverage.md` | before `options`, `predict` or `result` |
| `references/challenge.md` | before `challenge` |
| `references/document.md` | before `document` |

### The challenge stage

`check` is a self-audit for completeness. `challenge` is stronger: it spawns **independent
subagents whose job is to break the analysis**, in their own context, without the conversation
that produced it. The model that built the iceberg is the worst judge of whether it is true.

Four lenses, spawned in parallel as separate subagents in one message: rival explanation,
evidence and provenance, loop mechanics, intervention realism. Each gets the canvas and the
material and **never the conversation**. Run it by default before `predict`. Read
`references/challenge.md` for the briefs, the verdict rules, and what each verdict obliges.

### The check stage

Append a dated `## CHECK` section to the canvas containing four audits:

1. **Gates** - every gate, pass or fail, with what is missing. Report the challenge gate as
   "not run" rather than failed when no challenge has been attempted.
2. **Orphans** - trends no loop explains; loops with no belief behind them; options unscored or
   with no blocker; predictions with no dated falsifier.
3. **Provenance mix** - the `[S]`/`[I]`/`[G]` ratio per section, plus the thin-corpus warning if
   STRUCTURE and MENTAL MODELS are more than roughly 80% `[G]`.
4. **Whose iceberg is this** - re-read the EVENT `observer:` and every `observer-model:` entry,
   then answer in writing: whose boundary is this, whose metric is this, and who would have
   charted something different. If those answers are thin, the canvas is a single-perspective
   artifact. Say so.

## Running a stage

1. Read the canvas if one exists. Read the reference files for this stage.
2. Derive what the gate requires from the material rather than inventing it. Where the material
   is silent - most often numbers over time - use the closest thing it does contain, tag it
   honestly, and name the substitution at the checkpoint as something the user can replace.
3. Write the result into the canvas with IDs, link fields, and provenance tags.
4. Test the gate. Report pass or fail explicitly.
5. Deliver the updated canvas.
6. **Checkpoint and keep going** - see "Interaction" below. Do not wait for permission.

Never write a whole canvas in one pass from a single prompt. The gates exist because each layer
constrains the next; producing them all at once defeats them.

## Interaction: confirm, do not ask

**The method runs forward.** The user should type as little as possible and should never be
asked something the material already answers. One `/iceberg <material>` should carry the
analysis to the end.

### The checkpoint

**A checkpoint is printed text, not a tool call.** Never use AskUserQuestion for a checkpoint -
it halts the turn, and the whole point is that the run continues. Print the checkpoint, then
**run the next stage in the same turn**.

Each checkpoint has three parts:

1. **What was found** - two to four lines. The finding itself, not a description of the process.
2. **What happens next**, stated as fact: "Next: building the loop behind trend 2."
3. **Redirects** - a short plain list of commands the user could type to change course:
   `/iceberg back`, `/iceberg challenge S1`, better data for a weak trend. Not a question, not
   an invitation to approve.

The user does not answer a checkpoint. They interrupt if they want something different, and the
run carries on if they do not. Never show the whole canvas at a checkpoint - deliver the file,
summarise in the chat. Fill redirects with the canvas's real content ("`/iceberg why 2` -
concurrent initiatives 2 → 7"), never a placeholder, and never name a stage whose inputs do not
exist yet.

### When to ask a real question instead

**This** is where AskUserQuestion belongs - and only here. Four forks, no others: an ambiguous
**boundary** whose two cuts describe different systems; **two archetypes** that fit equally well;
a gate needing **data the material lacks** that the user may hold; an **ambiguous observer**.
Even then, options with one marked as the recommendation and one line of why - never an open
question. `references/interaction.md` has the wording.

**Never ask about** anything the sources answer, anything a defensible default covers, the
format of the deliverable, or whether to continue.

### When a gate cannot be satisfied

Do not stop and do not assume silently. Fill what the material supports, write the gap into the
canvas, tag the affected entries `[I]` or `[G]`, and name it at the checkpoint as a redirect the
user can take. Under `strict`, block instead.

### Unattended runs

When nobody is there - a scheduled task, a headless run - do not checkpoint at all. Run the full
chain through `challenge`, `predict` and `document`, record every decision that would have been
a checkpoint in the `assumptions:` block at the top of the canvas, and deliver. The adversaries
substitute for the missing human.

A scheduled `result` run gathers its own outcome: recompute the metric from the same source
`trends` used. If that is impossible, record "no observation available" against the prediction
and say what would be needed. Never call AskUserQuestion in a run with no human in it.

**Read `references/interaction.md` before composing any checkpoint.** It holds the forward move
for every stage, how to phrase an unmet gate as a redirect rather than a complaint, how to write
the checkpoint text itself, and the scheduling of the check-in after `predict`.

## Two failure modes to actively resist

**Structure becomes a checklist.** The vocabulary - stocks, flows, delays, dependencies,
constraints, rules - is a prompt list to raid when stuck, not a form to complete. The only test
that matters is whether the structure produces the charted trend.

**Mental models become other people's.** The fourth layer conventionally means the actors'
beliefs. There is a second set: the user's own framing, boundary, and choice of metric. Always
write at least one `observer-model:` entry. It is the most commonly skipped and most valuable
line in the canvas.

## Leverage is not just depth

Deeper is higher leverage **and** harder. Score on leverage x tractability x reversibility, name
the blocker, and note when a structural change is the delivery vehicle for a mental-model change.
Never write "small change, massive effect" - see `references/leverage.md`.

## Language

Write the canvas, the document and every checkpoint in **the language the user wrote in**. These
instructions stay in English; what the user reads does not. Keep the canvas field names and the
provenance tags (`[S]` `[I]` `[G]`) unchanged in any language - they are structure, not prose.

## Deliverables

- **The canvas**, always, after every stage - `<slug>-iceberg.md`. The working artifact: IDs,
  provenance, gaps, challenge verdicts.
- **A readable document** once the chain completes - `how-<slug>-works.md` or the equivalent
  phrasing in the user's language. This is the thing they asked for: an explanation written to be
  read, not audited. It carries the findings without the scaffolding - no IDs, no gate talk - but
  it states plainly what is uncertain and what the challenge round overturned. Write it from the
  canvas, not from memory.
- Behavior-over-time charts when the user has real numbers - use the `dataviz` skill for styling.
- `export` emits the chained prompt pack from `references/portable-prompts.md`, pre-filled with
  the current canvas, so the user can continue in a notebook tool or another assistant.
- A one-page HTML report on request: layers, loop diagram, options table, prediction with its
  falsifier date. This is revisit-by-nature, so persist it as an artifact rather than only
  dropping it in chat.
