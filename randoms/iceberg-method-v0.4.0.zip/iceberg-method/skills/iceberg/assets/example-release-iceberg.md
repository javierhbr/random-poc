<!-- Worked example. Read this when unsure what a finished canvas looks like. -->

# Iceberg: release lead time
profile: org | opened: 2026-08-20 | status: predicting

## FRAME
boundary: product org commitment process + delivery pipeline,
commitment → requirements → deploy                                          [I]
upstream: dependency teams, quarterly planning cycle                        [S]
downstream: customers, support load                                         [S]
outside (deliberately): hiring, pricing, exec strategy                      [I]
re-cut at: S1 — originally scoped to requirements → deploy. The pressure
driving the loop originates in the commitment process, so the boundary was
widened to include it and the boundary line above rewritten                 [I]

## EVENT
E1  "Our releases take too long."                                           [S]
    observer: engineering leadership                                        [S]
    metric chosen: lead time, requirement to deploy | chosen by: me         [I]

## PATTERNS
P1  lead time 3d → 17d over 20 weeks, monotone, no inflection    [S]  chart: bot-p1.png
    explains: E1
P2  concurrent initiatives per team 2 → 7 over the same window   [S]  chart: bot-p1.png
    explains: E1
P3  headcount flat at 24 across the whole window                 [S]  ← held constant
    explains: E1

## STRUCTURE
S1  Reinforcing: deadline missed → management pressure → more work started
    in parallel → WIP rises → context switching → throughput falls →
    deadline missed                                                         [I]
    archetype: firefighting / capability trap (Repenning & Sterman)         [G]
    delay: 1–2 sprints between a WIP increase and visible slowdown          [G]
    explains: P1, P2, P3
    falsified if: lead time rose while concurrent initiatives stayed flat —
    P2 is the load-bearing observation. Also falsified if commitment count
    moved before WIP did, which would place the loop upstream of where S1
    puts it (added 2026-08-21 from the rival-explanation lens)               [I]

## MENTAL MODELS
M1  actor: "utilization equals productivity; idle engineers are waste"      [I]
    explains: S1 — predicts the loop rebuilds itself within a quarter of any
    WIP cap being lifted, because the belief survives the intervention
M2  observer-model: I framed this as a throughput problem, not a
    prioritisation problem                                                  [I]
    explains: E1, P1 — someone framing it as "we commit to more than we can
    hold" would have charted commitments made per quarter, not lead time,
    and would likely have landed on the intake process rather than WIP

## LEVERAGE
L1  cap work in progress at two initiatives per team
    layer: structure
    leverage: high | tractability: high | reversible: yes
    blocked by: no single owner of the commitment queue — three directors
    can each start work independently                                       [S]
    targets: S1
    doubles as: the demonstration that damages M1 — lead time falls while
    utilization also falls, which the belief cannot accommodate

L2  change the reported metric from utilization to flow efficiency
    DROPPED 2026-08-21 — see CHALLENGE, intervention-realism lens
    layer: rules
    leverage: very high | tractability: none — the utilization figure is
    contractual in two customer agreements, not merely reported             [S]
    targets: M1
    doubles as: —

L3  publish per-team WIP on the same dashboard as the delivery dates
    layer: rules
    leverage: med | tractability: high | reversible: yes
    blocked by: nothing identified — the data already exists in the tracker [S]
    targets: S1
    doubles as: makes the WIP-to-lead-time relationship visible without
    anyone having to accept the argument first

ranking (revised 2026-08-21 after CHALLENGE): L3, then L1. L2 dropped — its
leverage was real but its blocker turned out to be contractual, not
political. L3 first: nothing blocks it, and it makes L1's case for it. L1
second, and only once the commitment queue has an owner, or the cap erodes
within a quarter.

open question before acting: did commitments or WIP move first? The rival
explanation and S1 make the same prediction unless this is checked.

## PREDICTIONS
X1  for L1, from 2026-09-01 — PROVISIONAL since 2026-08-21: the ranking now
    puts L3 first, and S1 itself is pending the lead-lag check. Re-run
    predict once that question is settled.
    weeks 1–2   lead time flat or slightly worse as in-flight work drains   [G]
    weeks 3–6   lead time falls toward ~8d                                  [I]
    weeks 7–12  stabilises; if it drifts back up, check whether the cap is
                being honoured before revising S1                           [I]
    expected delay before any effect: 1–2 sprints, from S1                  [I]
    side effect to watch: utilization falls. Anyone holding M1 will read
    that as the intervention failing. Name it in advance to whoever reads
    the dashboard.                                                          [I]
    falsified if: no downward movement in lead time by week 8 with the cap
    demonstrably held                                                       [I]

## OBSERVATIONS
<!-- Nothing observed yet. First check scheduled 2026-10-15. -->

## CHALLENGE
2026-08-21 — four independent adversaries, given the canvas and the delivery
metrics, not the conversation.

rival explanation
  S1  WEAKENED — a competing structure fits P1–P3 equally well: intake grew
      because the roadmap doubled, and WIP is a symptom of accepted scope
      rather than a response to pressure. Distinguishing observation: whether
      the WIP rise leads or lags the commitment count. If commitments moved
      first, the loop starts upstream of where S1 places it.
      → cheap to check before acting

evidence and provenance
  P2  SURVIVES — 2 → 7 is in the tracker export, correctly [S]
  S1  finding — the delay of "1–2 sprints" is tagged [I] but has no support
      in the material; it is inherited from the archetype. Should be [G].
  load-bearing claim: P2. If concurrent initiatives did not actually rise,
      nothing else in the canvas stands.

loop mechanics
  S1  SURVIVES — weakest link is "context switching → throughput falls",
      assumed rather than measured; the observed timing is consistent with
      the stated delay, so the loop is not ruled out on timing grounds.
      falsified-if line is genuinely falsifiable.

intervention realism
  L1  WEAKENED — three directors can each start work, so a cap with no queue
      owner will be honoured for about a quarter and then eroded. Whoever
      breaches it first pays no cost.
      would hold if: one person owns the commitment queue, or breaching the
      cap has a visible cost
  L2  REFUTED as a near-term option — the utilization number is contractual
      in two customer agreements, not merely reported. Removing it is not a
      metric change.
      would hold if: those two contracts are renegotiated, which is a
      2027 question
  best bet: L3. Nothing blocks it and it makes L1's case for it.

actions taken:
  - S1 delay retagged [I] → [G] (evidence lens)
  - S1 falsified-if extended with the lead-lag test (rival lens)
  - L2 marked DROPPED and its tractability corrected (realism lens)
  - ranking rewritten to L3, then L1; L1 now conditional on queue ownership
  - X1 marked PROVISIONAL pending the lead-lag check

## CHECK
<!-- Not yet run. -->
