# Iceberg: <topic>
profile: <corpus|org|technical> | opened: <YYYY-MM-DD> | status: <scoping|descending|choosing|challenged|predicting|observing>

<!--
[ ] is an empty provenance slot. Replace every one with:
  [S] stated in a source or directly observed
  [I] inferred by combining sources
  [G] general knowledge from outside the material
Never leave a slot blank.

IDs: E event, P pattern, S structure, M mental model, L leverage, X prediction, O observation.
Link fields: P/S/M use `explains:`; L uses `targets:`; X uses `for <L-id>`; O uses `against <X-id>`.
-->

## ASSUMPTIONS
<!-- Decisions taken without asking, because no one was there to ask (unattended runs)
     or because the material settled it well enough to proceed. One line each:
     what was decided, what the alternative was, and how to overturn it.
     Empty on a fully interactive run. -->

## FRAME
boundary:                                                   [ ]
searched: <queries run, if the material was retrieved rather than given>   [ ]
upstream:                                                   [ ]
downstream:                                                 [ ]
outside (deliberately):                                     [ ]
re-cut at:                                                  [ ]

## EVENT
E1  "<what was said or seen>"                               [ ]
    observer: <who is complaining or measuring>             [ ]
    metric chosen: <what is being counted> | chosen by: <whom>   [ ]

## PATTERNS
<!-- Gate: two or more variables that CHANGED over the same window, plus at least one that STAYED FLAT. -->
P1  <variable> <from> → <to> over <window>, <shape>         [ ]  chart:
    explains: E1
P2  <second variable that changed over the same window>     [ ]  chart:
    explains: E1
P3  <what stayed flat over the same window>                 [ ]  ← held constant
    explains: E1

## STRUCTURE
<!-- Gate: every P-id appears in some `explains:`, every loop has a falsifier. -->
S1  <Reinforcing|Balancing>: <a> → <b> → <c> → back to <a>  [ ]
    archetype:                                              [ ]
    delay: <how long between cause and visible effect>      [ ]
    explains: P1, P2, P3
    falsified if: <what would have to be true for this loop to be wrong>   [ ]

## MENTAL MODELS
<!-- Gate: each model would predict the structure being rebuilt if dismantled.
     At least one observer-model: entry. -->
M1  actor: "<belief held inside the system>"                [ ]
    explains: S1 — predicts the loop rebuilds itself after <intervention> is removed
M2  observer-model: <how my own framing, boundary, or metric shaped this>  [ ]
    explains: E1, P1 — someone framing it as <alternative> would have charted <other data>

## LEVERAGE
<!-- Gate: three candidates, each scored on leverage x tractability x reversibility, each with a blocker. -->
L1  <intervention>
    layer: <event|structure|rules|goals|paradigm>
    leverage: <low|med|high|very high> | tractability: <low|med|high> | reversible: <yes|hard|no>
    blocked by: <what stops this>                           [ ]
    targets: <S-id or M-id>
    doubles as: <the demonstration that damages M-id, if it does>

L2  <intervention at a different layer>
    layer:
    leverage: | tractability: | reversible:
    blocked by:                                             [ ]
    targets:
    doubles as:

L3  <intervention at a different layer>
    layer:
    leverage: | tractability: | reversible:
    blocked by:                                             [ ]
    targets:
    doubles as:

ranking: <order and why — leverage combined with tractability, not depth alone>

## PREDICTIONS
<!-- Gate: expected curve, delay, worse-before-better, dated falsifier. -->
X1  for <L-id>, from <date>:
    <window 1>  <expected behaviour, including any worse-before-better>   [ ]
    <window 2>  <expected behaviour>                                      [ ]
    expected delay before any effect: <from the structure layer>          [ ]
    side effect to watch: <what else moves, and how it may be misread>    [ ]
    falsified if: <observable> by <date>                                  [ ]

## OBSERVATIONS
O1  <date> — <what actually happened>                       [ ]
    against X1: <confirmed|falsified|partial>
    layer that was wrong: <FRAME|PATTERNS|STRUCTURE|MENTAL MODELS|none — prediction held>
    revision: <the rewrite of that layer, or "none needed">   [ ]

## CHALLENGE
<!-- Appended by the challenge stage. Dated. One block per independent adversary.
     Each finding: canvas ID attacked | SURVIVES | WEAKENED | REFUTED | why |
     "would hold if:" — what would have to be true for the claim to stand after all.
     Each lens also gives one summary line (load-bearing claim; best bet).
     Every REFUTED verdict, WEAKENED verdict and provenance correction must be
     acted on in the canvas body above, not absorbed. -->

actions taken:
  - <edit made to the canvas body, and which finding forced it>

## CHECK
<!-- Appended by the check stage. Dated. Four audits: gates, orphans, provenance mix,
     and "whose iceberg is this". -->
