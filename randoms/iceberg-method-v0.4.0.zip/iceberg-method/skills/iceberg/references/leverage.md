# Leverage and prediction

## The correction to make first

Deeper is higher leverage **and** harder to move. Depth of diagnosis and viability of
intervention are independent axes. The characteristic failure of this method is diagnosing a
paradigm, telling people their beliefs are wrong, and achieving nothing.

Do not write "a small change with a massive effect". Meadows' actual claim is that leverage
points are counterintuitive and that people routinely push them in the wrong direction.

## Meadows' twelve, mapped to the canvas

Listed from least to most effective. The map to iceberg layers is the useful part.

| # | Leverage point | Iceberg layer |
|---|---|---|
| 12 | Constants, parameters, numbers | patterns / surface structure |
| 11 | Size of buffers and stabilising stocks, relative to their flows | structure |
| 10 | Structure of material stocks and flows | structure |
| 9 | Length of delays relative to rate of change | structure |
| 8 | Strength of balancing loops relative to what they correct | structure |
| 7 | Gain around reinforcing loops | structure |
| 6 | Structure of information flows - who knows what, when | structure / rules |
| 5 | Rules: incentives, punishments, constraints | rules |
| 4 | Power to add, change, evolve, or self-organise system structure | rules / goals |
| 3 | Goals of the system | mental models |
| 2 | Mindset or paradigm the system arises from | mental models |
| 1 | Power to transcend paradigms | mental models |

Numbers 12-9 are where most proposals land and where most disappointment comes from. Numbers 6
and 5 are the underused middle: changing who sees what, and when, is usually more tractable than
changing what anyone believes.

## Scoring rubric

Score every candidate on three axes and record all three:

- **leverage** - which layer it acts on, using the table above
- **tractability** - does the user, or someone they can reach, have the authority to do it? What
  blocks it? A blocker must be named; "none" is almost never true
- **reversibility** - can it be undone cheaply if the prediction fails? Prefer reversible
  interventions when confidence in the structure is low

Rank by the combination, not by depth. A high-tractability structural change usually beats a
very-high-leverage paradigm change that nobody can authorise.

## Structural changes as arguments

Record it explicitly when a structural intervention is the delivery vehicle for a mental-model
change. A WIP cap that makes cycle time fall *while utilization also falls* damages
"utilization equals productivity" in a way no memo can, because the organisation experiences it.

Use the canvas field `doubles as: the demonstration that damages <M-id>`. Interventions that do
double duty should rank above their raw leverage score.

## Three candidates, not one

Produce three, at different layers where possible, so the user is choosing rather than accepting.
Order them and say why the order is what it is.

## Prediction

An intervention without a written prediction degrades observation into confirmation bias. Before
acting, record for the chosen candidate:

- **the expected curve** - what the pattern-layer variables do, by window (weeks, sprints,
  quarters), not a single endpoint
- **the expected delay** - from the structure layer. Nothing should be judged before it
- **worse-before-better** - name it in advance if the archetype predicts it. Draining in-flight
  work, capacity dips during a transition, morale during a rule change. Unnamed, this is what
  gets interventions cancelled at week two
- **the side effect that will be misread** - what else moves, and how someone holding the old
  mental model will interpret it. This is often the real test of the model
- **a dated falsifier** - a specific observable by a specific date. "No movement in lead time by
  week 8" is a falsifier; "it does not seem to be working" is not

## Observing

When `result` runs, do not simply record what happened. Require:

- the outcome against the prediction: confirmed, falsified, or partial
- **which layer was wrong** - frame, patterns, structure, or mental models - **or** an explicit
  statement that no layer needed revising. A confirmed prediction that carried a real falsifier
  is a pass, not a gate failure
- the revision to that layer, or "none needed"

A falsified prediction is a successful use of the method. Say so. The failure mode is a canvas
whose predictions are always confirmed, which means they were never falsifiable.
