# Stage guidance: frame, event, patterns, structure, mental models

## FRAME

The boundary is a lens, not a layer. Where it is cut determines what counts as an event at all.
Scope to the delivery pipeline and the event is "releases are slow"; scope to the product
organisation and the event is "we commit to too much, and it is slow".

Derive from the material and record:

- **boundary** - what is being treated as the system
- **upstream** - what feeds it (suppliers, requesters, prior stages)
- **downstream** - what consumes its output, and what happens because of it
- **outside, deliberately** - what is being excluded. **This is the gate.** A frame with nothing
  outside it is not a frame.

Re-cut whenever a lower layer forces it. When structure work shows the cause originates outside
the current boundary, widen it and record `re-cut at: <id>`. That re-cut is itself a finding -
say so out loud rather than silently editing.

## EVENT

The entry point, and the most contaminated layer, because it arrives pre-framed.

Record the statement, but also:

- **observer** - who is complaining, measuring, or reporting
- **metric chosen** - and by whom

Different observers produce different icebergs from the same world. A support lead and a CFO
looking at the same slowdown will pick different metrics and reach different structures. Naming
the observer now is what makes the `observer-model:` entry possible later.

Do not solve anything here. Do not accept a cause dressed as an event ("releases are slow
*because the team is understaffed*") - split it: the second half is a hypothesis for structure.

## PATTERNS

Stop looking at the instance. The question changes from "why was this one slow" to "why is this
getting slower".

Use real numbers over time wherever the material has them. Where it does not, use the closest
proxy it does contain, say so plainly, and mark it `[I]` or `[G]`. Do not manufacture a trend
from anecdote and then build structure on it - and do not stop the run to ask for figures;
surface the gap at the checkpoint instead.

Look for more than a trend:

- **trend** - monotone rise or fall
- **oscillation** - overshoot and correction, usually a balancing loop with a delay
- **plateau or S-curve** - something started limiting
- **distribution, not average** - a stable mean hiding a growing tail
- **co-movement** - two variables moving together, or one leading the other
- **what stayed flat** - the gate. Constants are as diagnostic as changes. Headcount flat while
  work-in-progress tripled tells you more than either number alone.

Chart at least two variables that changed over the same window, plus at least one that stayed
flat - that is the gate. Use the `dataviz` skill for styling. Charts
are what let structure be matched against a signature shape rather than guessed.

## STRUCTURE

Where the system's machinery gets drawn. Two moves, in order:

**1. Map flow and boundary.** Elements, sequence, inputs and outputs, dependencies. Upstream and
downstream from FRAME belong here as the spine of the map.

**2. Find the loop that generates the charted pattern.** This is the actual work. Match against
`archetypes.md` first - eleven known shapes are cheaper and more reliable than building from
scratch - then verify against the data rather than accepting the match.

The vocabulary below is a prompt list to raid when stuck. It is **not** a checklist to complete:

- what accumulates - **stocks**
- what changes stocks - **flows**
- how long between cause and visible effect - **delays**
- what limits it - **constraints**
- what it needs from elsewhere - **dependencies**
- what is written down or enforced - **rules**
- who knows what, and when - **information flows**
- what is rewarded - **incentives**
- what returns to its own cause - **feedback**

**Gate:** every pattern ID must appear in some `explains:` line, and every loop must carry a
`falsified if:` - the observation that would show the loop wrong. A loop with no falsifier is a
story.

Delays deserve their own line. Most misdiagnosis of structure is a delay mistaken for an absence
of effect.

## MENTAL MODELS

Why the structure exists, and why it comes back.

**Actor models** - the beliefs, goals, and assumptions inside the system that make the structure
sensible to the people in it. The test is not whether the belief is stated; it is whether the
belief would **rebuild the structure** after it was dismantled. "Utilization equals productivity"
passes: remove a WIP cap and the parallel work returns. "People are careless" does not - it
predicts nothing structural.

Useful elicitation questions:

- What would have to be true for this structure to be the rational choice?
- What is measured, and therefore what is believed to matter?
- What happened historically that this structure was a reasonable answer to?
- What is never questioned in the sources or the room?

**Observer models** - the user's own framing. Required, at least one entry:

- What did I treat as the system, and what did that exclude?
- Which metric did I choose, and what does it make invisible?
- Who would have charted something different, and what?

This is the most commonly skipped line in the method and the one that catches the most errors.

## Working style for all stages

Derive what the gate needs from the material rather than inventing it. When the material does not
contain it, use the closest thing it does, say which gate is unmet, tag the entry `[I]` or `[G]`,
and continue - with the weakness recorded in the canvas rather than hidden, and named at the
checkpoint as something the user can replace. Do not stop to request it.
