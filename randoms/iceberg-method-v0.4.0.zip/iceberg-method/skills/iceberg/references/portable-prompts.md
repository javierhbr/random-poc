# Portable prompt pack

Emitted by `export`. Pre-fill each prompt with the current canvas before handing it over, so
the chain survives outside this session - NotebookLM, another assistant, a colleague.

Every prompt ends with the same provenance instruction. Keep it verbatim; it is what makes the
output checkable.

> **Provenance clause (append to every prompt):**
> Mark every claim with one of: [S] directly stated in the sources, [I] inferred by combining
> sources, [G] your general knowledge from outside the sources. Do not merge [I] and [G].

---

## 0. Frame

> I am analysing: **<topic>**. My material is: **<what the sources are>**.
> Before analysing anything, state the system boundary you are assuming: what is inside, what
> feeds it from upstream, what consumes its output downstream, and - most importantly - what you
> are treating as outside the system. Name at least one thing you are excluding and why.
> *(provenance clause)*

## 1. Event

> Here is the boundary: **<paste FRAME>**.
> Identify the central observable claim or complaint. State it as it was said. Then record who
> the observer is, what metric they chose, and what that metric makes invisible. Do not explain
> it yet and do not accept a cause dressed up as an observation.
> *(provenance clause)*

## 2. Patterns

> Here is the canvas so far: **<paste FRAME + EVENT>**.
> Move from the single instance to behavior over time. Identify at least two variables that
> changed over the same window, and at least one thing that stayed constant. Give shape, not just
> direction - trend, oscillation, plateau, widening distribution. Where the sources contain dates
> or figures, use them; where they do not, say so rather than estimating.
> *(provenance clause)*

## 3. Structure

> Here is the canvas so far: **<paste through PATTERNS>**.
> Propose the smallest feedback structure that would produce **the specific pattern above** -
> not a general model of the domain. Name the reinforcing and balancing loops, walk each
> mechanism step by step, and state the delay between cause and visible effect. If it matches a
> known systems archetype, name it. Then state what the pattern would look like if this
> structure were wrong, so I can check it.
> *(provenance clause)*

## 4. Mental models

> Here is the canvas so far: **<paste through STRUCTURE>**.
> What beliefs, goals or assumptions make that structure sensible to the people inside it? Test
> each one: would this belief cause the structure to be **rebuilt** if it were dismantled? Discard
> any that would not.
> Then separately: examine my own framing. Given my stated boundary and chosen metric, what am I
> unable to see, and what would someone with a different frame have charted instead?
> *(provenance clause)*

## 5. Leverage

> Here is the full canvas: **<paste all layers>**. My context and constraints: **<describe role,
> authority, resources, current state>**.
> Propose three interventions at different layers. For each, give the causal chain step by step,
> which structure or mental model it targets, what would block it, whether it can be reversed
> cheaply, and whether it also functions as a demonstration that undermines one of the beliefs
> above. Rank them by leverage combined with tractability - not by depth alone. Note explicitly
> where a proposal might be pushed in the wrong direction.
> *(provenance clause)*

## 5b. Challenge (run in a FRESH conversation)

Start a new chat for this one. Paste only the canvas and the source material - not the
conversation that produced them. Independence is the whole point.

> Here is a systems analysis and the material it was built from. Your job is to break it, not to
> improve it. Do four things.
> One: ignore the structure it proposes and build the best **different** structure that explains
> the same trends equally well; say which the evidence favours and what observation would
> distinguish them.
> Two: audit the provenance tags against the material - flag anything marked [S] the source does
> not state, and name the single claim the whole analysis most depends on.
> Three: walk each feedback loop and find the weakest link; check whether the trend moved faster
> than the stated delay allows.
> Four: for each proposed intervention, argue the case that it fails or backfires - the missed
> blocker, the second-order effect, who has an incentive to reverse it.
> Mark every finding SURVIVES, WEAKENED or REFUTED against the ID it attacks. Do not manufacture
> objections: a claim that holds should be marked SURVIVES with a reason.
> *(provenance clause)*

## 6. Prediction

> For intervention **<L-id>**, write the prediction before I act. Give the expected behavior of
> the pattern-layer variables by time window, the delay before any effect should appear, any
> worse-before-better period, the side effect most likely to be misread as failure, and a
> specific observable by a specific date that would falsify the model.
> *(provenance clause)*

## 7. Observation

> Here is the prediction: **<paste X-entry>**. Here is what actually happened: **<describe>**.
> State whether the prediction was confirmed, falsified, or partial. Then either identify which
> layer was wrong - boundary, pattern, structure, or mental model - and rewrite that layer, or
> state explicitly that no layer needed revising. Do not rescue the model by adding conditions
> to it.
> *(provenance clause)*

---

## Note to include when handing the pack over

The prompts are chained: each one takes the previous output as input. Run them in order and paste
the accumulated canvas forward. Running them independently produces a set of unrelated analyses,
which is the failure this method exists to prevent.
