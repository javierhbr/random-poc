# Retrieval with `local-search`

When the user has the `local-search` CLI, corpus work stops being "walk a folder and hope" and
becomes real retrieval against an index. Use it whenever it is available and the material is a
knowledge base rather than a specific path the user handed over.

## Is it available

```bash
local-search repo list
```

Non-zero exit or an empty list means no index - fall back to reading the given path directly.
Never assume it is installed.

**Scope caveat, from its own docs:** `search` does not read the config file. `--repos` defaults
to `all`, so a project scope set elsewhere has no effect on `search` - only on `find` and `code`.
If the analysis should be scoped, pass `--repos` explicitly on every call.

## Query syntax worth using

FTS5, so these all work and combine:

| Form | Effect |
|---|---|
| `refunding` | stems - matches refund, refunds, refunded |
| `"refund OR signup"` | either term |
| `"payments NOT chargeback"` | excludes |
| `"auth*"` | prefix |
| `"\"refund request\""` | exact phrase |

Useful flags: `--repos a,b` (scope), `--source fts\|graph\|both`, `--rank bm25\|graph-aware`,
`--semantic` for similarity re-ranking, `--exclude-location <path>`.

Beyond `search`: `related <term>` finds cross-repo connections, `recent [N]` lists recently
modified specs, `tags [name]` browses annotations, `list <repo>` enumerates, and
`graph explain "capability://..."` walks relationships.

## One search angle is not enough

A single query returns what one phrasing happens to match. Run a **sweep** - several
formulations that are blind to each other - and merge. At minimum: the user's own words, the
domain's formal term, and the failure phrasing (what people write when it goes wrong).

## What to search, by layer

Each layer wants a different query, and different commands.

**`see` - the event.** Search the claim in the user's own words, then in the vocabulary the
corpus actually uses. `recent` is useful here: what changed lately is often what prompted the
question.

**`trends` - behavior over time.** The hardest layer to retrieve and the most valuable.
- `recent N` to get the time axis
- the same concept searched with and without a prefix wildcard, to catch renamed things
- `list <repo>` to see whether a topic's spec count is growing
- compare how a concept is described in older versus newer specs - a definition that drifted is
  a pattern, not a detail

**`why` - structure.** This is where `--source graph`, `--rank graph-aware`, `related` and
`graph explain` earn their place: dependencies and connectedness are structure. A spec that
everything links to is a stock or a constraint. Search for the mechanism words directly -
"depends", "blocked", "waits for", "retry", "queue", "limit", "quota".

**`beliefs` - mental models.** Search for what is asserted without justification. Useful probes:
"we assume", "by design", "for historical reasons", "should always", "never". Also search the
*absence*: a term that is central to the domain but returns nothing is a paradigm nobody wrote
down.

**`options` and `challenge`.** Search for prior attempts - "deprecated", "migration",
"postmortem", "rollback". Something that was tried and abandoned is the strongest available
evidence about tractability, and the intervention-realism adversary should get it.

## Read the files, do not trust the snippet

Search results rank and excerpt; they do not explain. Open the actual files behind the results
that matter before writing anything into the canvas. A claim built from a snippet is `[I]` at
best, and usually `[G]`.

## Record the sweep - it is the boundary

Write the queries into the canvas FRAME block:

```
searched: "refund*", "chargeback OR dispute", "settlement delay"   [S]
repos: platform-docs, product-specs
outside (deliberately): billing-legacy — not indexed; unsearched, so
anything living only there is invisible to this analysis    [I]
```

This is not bookkeeping. **What you did not search is the system boundary**, and it belongs in
`outside` with everything else you excluded. A reader can then see the shape of the hole.

Cite results as repo plus spec path, and tag them `[S]` - they are stated in a source. The
inference that connects two specs is `[I]`, and it is yours, not the corpus's.
