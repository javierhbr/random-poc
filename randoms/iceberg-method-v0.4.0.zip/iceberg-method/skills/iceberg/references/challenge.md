# The adversary: independent challenge

`check` audits the canvas for **completeness** - what is missing, unlinked, or unsourced. It is
a self-audit and it cannot catch a well-formed analysis that is simply wrong.

`challenge` is different. It spawns **independent subagents whose job is to break the analysis.**
They run in their own context, so they do not inherit the conversation's accumulated commitment
to the story. That independence is the entire point: the model that built the iceberg is the
worst possible judge of whether it is true.

## How to run it

Use this session's subagent tool (`Agent`, or `Task` where that is its name). Spawn the lenses
**in parallel, in one message**, each as a separate independent agent.

**What each adversary receives:**

- the canvas file
- the underlying material - the sources, the data, the file paths, whatever the trends were
  built from
- its own brief, below

**What it must NOT receive:** the conversation. No reasoning traces, no explanation of why the
loop seemed right, no reassurance about what was already considered. If it is going to be
independent, it has to be able to reach a different conclusion.

## The four lenses

Run all four for a full challenge. For `challenge <ID>` targeting one entry, run only the lenses
that apply to that entry's layer - the gate asks for every lens **that applies**, not all four.

### 1. Rival explanation

> Here is a canvas describing a system, and the underlying material. Ignore the structure it
> proposes. Build the best **different** structure you can that explains the same trends equally
> well. Then say which of the two the evidence actually favours, and what observation would
> distinguish them. If you cannot construct a credible rival, say so plainly - that is a real
> result.

The highest-value lens. A structure with no credible rival is established; a structure with
three equally good rivals was a story. Whatever it returns, record the distinguishing
observation - that is a cheap experiment the user can run before committing.

### 2. Evidence and provenance

> Audit every claim against the material. For each: is the provenance tag honest? Flag anything
> marked [S] that the source does not actually state, anything marked [I] that is really outside
> knowledge and should be [G], and any number that does not appear in the material. Then say
> which single claim the whole analysis most depends on, and how well supported it is.

Catches the failure mode the tags exist for. The "load-bearing claim" question is the useful
part: it tells the user where to spend verification effort.

### 3. Loop mechanics

> Take each feedback loop in this canvas. Walk the mechanism step by step and find the weakest
> link - the step most likely to be assumed rather than demonstrated. Check the stated delay
> against the observed timing: if the trend moved faster than the loop's delay allows, the loop
> cannot be the cause. Then check the loop's own `falsified if:` line - is it actually
> falsifiable, or is it written so it can never fail?

Delay-versus-timing is the check that most often kills a plausible loop, and it is nearly
impossible to see from inside the analysis.

### 4. Intervention realism

> Here are three proposed interventions with their scores. For each, argue the case that it
> fails or backfires. Name the blocker that was missed, the second-order effect that undoes it,
> and who in the described system has an incentive to reverse it. Then say which of the three
> you would actually bet on, and why.

Tractability scores are where optimism hides. This lens exists to find the blocker the analyst
did not want to see.

## Verdicts

Each adversary returns findings, each carrying:

- the **canvas ID** it attacks
- a verdict: **SURVIVES**, **WEAKENED**, or **REFUTED**
- one sentence of why
- for REFUTED and WEAKENED: what would have to be true for the claim to hold after all

Instruct every adversary explicitly: **do not manufacture objections.** A claim that holds
should be marked SURVIVES with a reason. A challenge round that refutes everything is as useless
as one that refutes nothing, and reads as theatre.

## Recording the result

Append a dated `## CHALLENGE` section to the canvas. Then act on the verdicts:

| Verdict on | Consequence |
|---|---|
| a structure entry REFUTED | run `why` again for the trends it claimed to explain |
| a structure entry WEAKENED | keep it, append the objection to its `falsified if:` line |
| a belief entry REFUTED | run `beliefs` again - and re-check the options that targeted it |
| an option REFUTED | drop it from the ranking and say what replaced it |
| a provenance tag corrected | fix it in place, and re-run the thin-corpus check |

Do not quietly absorb a REFUTED verdict by editing the claim until it survives. Record what was
attacked, what fell, and what replaced it. The history is the value.

## When to run it

- **Before `predict`** - the natural place. Challenging after you have committed to an
  intervention is expensive; challenging before it costs one round.
- **After `why`**, when the loop matters more than usual, or when it landed suspiciously neatly
  on a known archetype.
- **Before sharing the canvas with anyone** whose decision depends on it.

Never treat a passed challenge as proof. It means the analysis survived four specific attacks by
adversaries who had the same material - not that it is true.
