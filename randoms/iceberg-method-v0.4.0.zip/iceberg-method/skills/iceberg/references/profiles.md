# Content profiles

The profile changes four things: what counts as an event, where pattern data comes from, what the
mental-model layer means, and the sourcing rule.

**Detection**, in this order - never ask, state the choice at the checkpoint and let the user
override with `--mode`:

1. A path that is inside a git work tree (`git rev-parse --show-toplevel` succeeds) or contains
   source files → **technical**. Test this first: misfiling a repo as corpus throws away the
   computed trends that are the whole advantage of the mode.
2. Any other path, glob, pasted block of text, set of URLs, or a question answerable from an
   available `local-search` index → **corpus**.
3. A described problem with no material attached → **org**.

Mixed input takes the profile of its heaviest component; a repo path with a sentence of context
is technical, not org.

| | corpus | org | technical |
|---|---|---|---|
| Event is | a central claim in the sources | a recurring complaint | a recurring incident or metric |
| Pattern data from | publication dates, shifts in position across sources | metrics, retros, calendars, ticket ages | git log, incident history, build and CI durations |
| Mental models are | the authors' paradigm; what the corpus never questions | management beliefs, incentives, what gets rewarded | team conventions, design assumptions, "we have always" |
| Sourcing rule | strict three-way tagging, per-source attribution | attribute to an interview, a metric, or a document | cite file, commit hash, or incident ID |

---

## org - recurring workplace and process problems

The native home of the method. Delivery slowdowns, escalating rework, attrition, meeting load,
repeated incidents, plans that always slip.

**Framing.** Establish who owns the boundary. If nothing inside the stated boundary is within the
user's reach, the frame is wrong - widen it to include someone they can influence, or narrow it
to what they control and accept lower leverage. State which you did at the checkpoint.

**Patterns.** Push hard for numbers, because this profile is where anecdote is most tempting.
Usable sources: cycle and lead time, ticket age distribution, WIP counts, meeting hours,
incident counts, headcount, attrition, sprint commitment versus completion. Always chart at
least one thing that stayed flat - headcount and team count are the usual candidates and are
usually the most diagnostic.

**Structure.** Start with the archetype library. Organisational dynamics match known shapes more
often than not - firefighting, shifting the burden, drifting goals, and growth-and-underinvestment
cover a large share of real cases.

**Mental models.** Look at what is measured and what is rewarded before what is said. Stated
values are weak evidence; the metric on the dashboard is strong evidence. Useful probe: what
would someone have to believe for the current incentive scheme to be sensible?

**Leverage.** Tractability dominates here. Ask explicitly who can authorise each candidate. Rules
and information flows (Meadows 6 and 5) are usually the tractable middle: changing what a
dashboard shows, or who attends a decision, is far more achievable than changing what leadership
believes - and often does the belief work anyway.

**Sensitivity.** Mental-model entries name what people believe, which reads as blame if handled
badly. Write beliefs as rational responses to the structure people sit in, not as failings. If
the canvas will be shared, offer to generate a version with the mental-model layer stated
institutionally rather than personally.

---

## corpus - documents, papers, research source sets

Reading a body of material to find the system it describes or assumes.

**Framing.** The corpus silently sets the boundary. Work out what is *not* in the source set and
record it as `outside` - a corpus assembled by one party has a boundary with an author. When
retrieval was used, the queries you ran are part of that boundary; see
`references/local-search.md`.

**Retrieval.** When the `local-search` CLI is available, use it rather than walking a directory
blind - it turns corpus mode into real retrieval with a per-layer query strategy. See
`references/local-search.md`. Fall back to reading the given path when it is not installed.

**Patterns.** Not themes. Look for change over time across the material: how positions shift
between earlier and later sources, what stops being argued because it became assumed, which
claims recur unchanged, what quietly disappears from the discussion. Publication dates are the
time axis.

**Structure and mental models.** Expect these layers to be thin in the sources. Most documents
state events and sometimes patterns; the structure that produces them is usually unstated, and
paradigm is usually invisible to the author. This is normal and it is the point.

**The provenance diagnostic.** This profile is where the three-way tag earns its keep. After
writing structure and mental models, compute the mix. If those sections are more than roughly
80% `[G]`, report it directly: the corpus describes the surface of this system and the depth is
the model reasoning, not the material. Suggest what kind of source would fix it - internal
documents rather than public ones, dissenting authors, older material predating the current
consensus, or operational data rather than commentary.

---

## technical - codebases, pipelines, incident histories

**Framing.** The repository boundary is not the system boundary. Deploy targets, upstream
services, the on-call rota and the team's process are usually inside the real system.

**Patterns.** The one profile where pattern data can be *computed* rather than asserted. Useful
and cheap:

- commit frequency and file churn over time (`git log --format=%ad --date=short | sort | uniq -c`)
- files with the highest change counts, and whether that concentration is growing
- test suite duration and CI wall-clock over time
- incident frequency by component, and mean time between recurrences of the same one
- open PR age distribution, and review latency

Chart at least two of these. Computed patterns make the structure layer far more disciplined
than in the other profiles - use that advantage.

**Structure.** Stocks and flows map cleanly: unmerged work, untriaged issues, unpaid technical
debt are stocks; merge rate, triage rate and refactoring are flows. Delays are usually the
diagnostic element - slow CI is a delay in a balancing loop, and its effect is nonlinear.

**Mental models.** Look for conventions nobody can justify, the design assumption that stopped
being true, and what the team believes is expensive versus what actually is. The paradigm layer
often shows up as an architectural choice that made sense at a scale the system has since left.

**Sourcing.** Cite file paths, commit hashes, incident IDs. A structure claim in this profile
should be traceable to something checkable.
