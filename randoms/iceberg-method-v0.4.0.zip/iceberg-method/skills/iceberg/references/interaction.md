# Checkpoints and menus

Read this when composing a checkpoint. The rules are in SKILL.md; this is the lookup table, the
special cases, and the menu wording.

## The menu, when there is nothing to go on

Bare `/iceberg`, or a first token that means nothing. This **is** an AskUserQuestion - there is
no work to continue, so there is nothing to interrupt.

**No canvas exists** - ask what to run the method on:

- a recurring problem that resists fixing
- documents or sources
- a technical system or codebase
- explain the method first, no analysis

**A canvas exists** - if more than one, first ask which (three most recent, plus "start a new
one"). Then read it and offer:

- continue at the next open gate, **named exactly**: "the loop behind trend 2 is missing" -
  recommended
- jump to a stage
- `check` it
- `export` the portable prompts

An unrecognised token gets this same menu, prefixed with one line naming what was not
understood. Never error out, and never guess what they meant.

## The forward move, by stage

The first option at every checkpoint. Show it with the canvas's real content filled in, never a
placeholder.

| Just completed | Forward move (recommended) | Sideways moves worth offering |
|---|---|---|
| `scope` | `/iceberg next` - name what you are seeing | re-cut the boundary wider or narrower |
| `see` | `/iceberg next` - find what repeats over time | `/iceberg back` with a different observer or metric |
| `trends` | `/iceberg why <strongest trend>` - build the loop behind it | supply better numbers for a weak trend; add another variable |
| `why` | `/iceberg next` - why does this structure exist | `/iceberg challenge <the loop>` if it landed suspiciously neatly; `/iceberg why <unexplained trend>` |
| `beliefs` | `/iceberg options` - three ranked places to push | add an `observer-model:` entry; `/iceberg check` |
| `options` | `/iceberg challenge` - let independent adversaries attack it before committing | `/iceberg predict 1`; rescore under different constraints |
| `challenge` | act on the strongest surviving objection, as a concrete command | `/iceberg predict <the option that survived>` |
| `predict` | offer to schedule the check-in, below | `/iceberg check`; `/iceberg export` |
| `result` | re-run whichever layer was wrong, named explicitly | `/iceberg options` again if the structure changed |
| `check` | the highest-priority hole it found, as a concrete command | continue from where you were |

| `document` | deliver both files and stop | `/iceberg challenge` if it was skipped; `/iceberg export` |

`document` is the last stage of the forward chain, not an optional extra. The canvas is never
the finished deliverable. See `references/document.md`.

## Special case: after `predict`, schedule the check-in

A prediction with a falsifier date is worthless if nobody returns to it. When `predict`
completes, offer to create a scheduled task for a few days after the falsifier date, whose
prompt reopens the canvas and runs `result`. Use the remote scheduled-task tools, not local
cron - a local scheduler dies with the session and the task silently never fires.

If the user declines, tell them the date and the exact command:
`/iceberg result "<what happened>"`.

## The four forks that justify a real question

Only these. Everything else is decided from the material and stated at the checkpoint.

1. **The boundary is genuinely ambiguous** and the two cuts describe different systems. Offer
   both cuts, say which you recommend and what each would make invisible.
2. **Two archetypes fit the trends equally well** and only the user holds what would discriminate.
   Offer both, and name the observation that would separate them.
3. **A gate needs data the material does not contain** - almost always numbers over time - and
   the user plausibly has it. Offer: supply it, use the named proxy, or continue with the gap
   recorded.
4. **The observer is ambiguous** - two plausible people are complaining, with different metrics
   and therefore different icebergs. Offer each, and say how the analysis diverges.

Always one option marked as the recommendation, with one line of why. Never an open question,
and never more than four options.

## Special case: a gate that could not be satisfied

The gap becomes the **first sideways option**, phrased as something the user can fix rather than
as a complaint:

> - Trend 3 has no real data — I used the ticket export. Replace it if you have the figures.

Never phrase it as a request for permission to continue. The analysis already continued; the
option is there to improve it.

## Writing the checkpoint itself

Two to four lines of finding, then the next step as a statement, then the options. What the
finding *is*, never what you did to get it.

Good:

> **Lead time 3d → 17d over 20 weeks. Concurrent initiatives 2 → 7. Headcount never moved.**
> Next: building the loop behind those two.

Bad:

> I have completed the patterns stage and identified three patterns. I analysed the data you
> provided and looked for variables that changed over time. Would you like me to continue?

The bad version narrates process, asks permission, and says nothing a person could act on.
