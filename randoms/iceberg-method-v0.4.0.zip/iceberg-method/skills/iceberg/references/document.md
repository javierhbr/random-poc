# Writing the document

The last stage of the chain. The canvas is the working artifact; **this** is what the user asked
for. Write it from the canvas, never from memory.

File: `how-<slug>-works.md`, or the natural equivalent phrasing in the user's language, beside
the canvas.

## Shape

Roughly 800-1500 words. Longer than that and nobody reads it; shorter and it is a summary, which
is the thing this method exists to beat.

1. **What this is** - two or three sentences. What was analysed, from what material, and the
   single most important finding. A reader who stops here should still have learned the main
   thing.

2. **What you can see** - the observable behavior, with the numbers. Include the thing that
   *stayed constant*; it is usually the most persuasive line in the document.

3. **How it actually works** - the mechanism. The loop, walked step by step in prose, with the
   delay stated plainly ("the effect shows up about two sprints later, which is why it looks
   like nothing is happening"). This is the core of the document; give it the most room.

4. **Why it stays that way** - the beliefs and incentives that rebuild the structure. Write
   these as rational responses to the situation people are in, never as failings.

5. **Where you could push** - the ranked options, with the blocker named for each. Say plainly
   which one you would start with and why.

6. **What would prove this wrong** - the prediction and its falsifier date, and whatever the
   challenge round left standing as a live doubt. Never omit this section to make the document
   look stronger.

## Rules

- **No scaffolding.** No IDs, no `[S]`/`[I]`/`[G]` tags, no gate talk, no mention of stages or
  commands. Those live in the canvas, and the document points to it once, at the end.
- **Uncertainty stays in.** Where the canvas is thin, the document says so in plain words:
  "there is no data on how long review actually takes; this part is inference." Strip the
  machinery, not the honesty.
- **The challenge round gets a paragraph**, not a footnote. If an adversary found a rival
  explanation that survives, that is one of the most useful things in the document - it tells
  the reader what to check before acting.
- **Prose, not bullets**, for the mechanism. A loop rendered as a bullet list stops being a loop.
- **No hedging language as decoration.** "May potentially contribute to" says nothing. Either
  the evidence supports the claim, in which case state it, or it does not, in which case say
  what is missing.
- **Match the user's language**, and keep the diagrams - a small ASCII loop diagram in the
  mechanism section is worth a paragraph of description.

## Close with provenance

End with two or three lines: what material this was built from, what was deliberately outside
the boundary, and a pointer to the canvas for anyone who wants the claim-by-claim sourcing. A
reader deciding whether to act on this needs to know what it could not see.
