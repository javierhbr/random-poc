# /xray-lens

Single entry point for system analysis. Use `action` to select the depth or purpose of the analysis.

## Syntax

```text
/xray-lens <topic-or-question> [action=<action>] [depth=<depth>] [focus=<focus>] [format=<format>]
```

## Parameters

- `action` — `understand` (default), `map`, `iceberg`, `trace`, `loops`, `leverage`, `challenge`, `compare`
- `depth` — `quick`, `standard` (default), `deep`
- `focus` — optional lens such as `risk`, `delivery`, `finance`, `learning`, `architecture`, `organization`
- `format` — `markdown` (default), `compact`, `json`
- `context` — optional additional situation, constraints, or current state
- `goal` — optional desired outcome or decision to support
- `evidence` — optional source material or facts that should be treated as observed evidence

## Routing

Use the smallest skill set required:

- `understand`, `map`, `iceberg`, `trace` → `xray-lens-analysis`
- `loops` → `xray-lens-analysis` + `xray-lens-dynamics`
- `leverage` → all three skills
- `challenge` → `xray-lens-analysis` + evidence rules from `references/evidence.md`
- `compare` → `xray-lens-leverage`, using an existing model when supplied

Never invent causal certainty. Mark observed, inferred, and assumed relationships.

## Examples

```text
/xray-lens Why are our releases getting slower?
```

```text
/xray-lens customer eligibility service action=map depth=quick
```

```text
/xray-lens technical debt action=loops focus=delivery depth=deep
```

```text
/xray-lens our team has high WIP and missed deadlines action=leverage context="12 engineers, 4 parallel initiatives" goal="reduce cycle time"
```

```text
/xray-lens "automate investments vs pay high-interest debt" action=compare focus=finance
```

Read `references/analysis-modes.md` for action-specific behavior and `references/output-contract.md` for the response contract.
