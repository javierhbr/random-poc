# Leverage Analysis Reference

A leverage point is not merely popular advice or a convenient action. It is a place where changing a system mechanism can produce disproportionate changes in system behavior.

## Candidate derivation
Look for interventions affecting:
- parameters and thresholds
- buffers / stock sizes
- delays
- balancing-loop strength
- reinforcing-loop strength
- information flows
- rules and incentives
- self-organization
- system goals
- paradigms / mental models

Prefer deeper leverage only when feasible and causally supported.

## Chain of implications
For each candidate:

```text
Intervention → immediate mechanism → loop/stock effect → behavioral change → outcome → impact
```

Then test:
- What can block the chain?
- What balancing loop may resist it?
- What reinforcing loop may amplify it?
- What delay hides the effect?
- What side effect or second-order consequence appears?

## Ranking dimensions
- systemic impact
- leverage depth
- evidence confidence
- feasibility
- reversibility
- time to feedback
- side-effect risk

Do not collapse these into fake mathematical precision unless data supports it.
