# Output Contract

Adapt sections to the selected mode rather than emitting every section mechanically.

For a full `understand` analysis prefer:

1. System in one sentence
2. Purpose and boundary
3. Context map
4. Iceberg
   - Events
   - Patterns
   - Structure
   - Mental models
5. Dynamics
   - important stocks / flows
   - reinforcing loops
   - balancing loops
   - delays / constraints
6. Why it matters
7. Unknowns and evidence gaps
8. Optional next analysis

For leverage analysis add:

9. Leverage candidates
10. Chain of implications for each
11. Blockers / counter-loops / side effects
12. Ranked recommendation
13. Validation experiment or observable signal

For `compact`, give only the most decision-relevant findings.
For `json`, conform to `../schemas/xray-lens.schema.json` where applicable.
