# Core Framework

Use the Iceberg Model as the backbone of the analysis.

## Context map

```text
UPSTREAM → INPUT → [ SYSTEM ] → OUTPUT → DOWNSTREAM → OUTCOME → IMPACT
                        ↑
             dependencies / constraints
```

The context map provides horizontal understanding: where the system sits, what enters it, what leaves it, who depends on it, and why it matters.

## Iceberg

### Events
What is visible now? What happened?

### Patterns
What repeats, trends, oscillates, grows, declines, or persists over time?

### Structure
What generates those patterns?

Consider:
- system boundary and purpose
- inputs and outputs
- upstream and downstream actors
- stocks and flows
- rules and incentives
- information flows
- dependencies
- constraints
- delays
- feedback loops

### Mental models
What assumptions, goals, beliefs, values, or paradigms make the structure seem reasonable or keep it in place?

## Core distinction

- Input/output explains position and relevance.
- Iceberg explains depth.
- System dynamics explains behavior over time.
- Leverage analysis explains where intervention may change future behavior.
