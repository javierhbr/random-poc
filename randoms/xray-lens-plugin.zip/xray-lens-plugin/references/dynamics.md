# System Dynamics Reference

## Stocks
Things that accumulate or deplete over time: money, backlog, trust, knowledge, inventory, technical debt, customers.

## Flows
Rates that increase or decrease stocks: arrivals/completions, hiring/attrition, learning/forgetting, borrowing/repayment.

## Reinforcing loops
Self-amplifying loops. Label R1, R2, etc.

Example:
```text
Pressure ↑ → Shortcuts ↑ → Technical debt ↑ → Delivery speed ↓ → Missed deadlines ↑ → Pressure ↑
```

## Balancing loops
Goal-seeking or stabilizing loops. Label B1, B2, etc.

## Delays
Explicitly identify delays between cause and visible effect. Delays often create overshoot, oscillation, or mistaken conclusions.

## Constraints
Identify limiting factors and bottlenecks. Growth frequently shifts the active constraint elsewhere.

## Loop quality rule
A loop must:
1. close back on the starting variable;
2. describe directional influence;
3. distinguish evidence from hypothesis;
4. identify material delays;
5. explain what behavior the loop could generate.
