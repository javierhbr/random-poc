# Evidence and Causal Discipline

Tag important claims as:

- **Observed** — directly supported by supplied evidence or measurements.
- **Inferred** — plausible conclusion supported by multiple observations or known mechanism.
- **Assumed** — working hypothesis that requires validation.
- **Unknown** — information needed to distinguish explanations.

For important causal links use:

```text
A → B
Status: Observed | Inferred | Assumed
Evidence: ...
Alternative explanation: ...
Validation: what would confirm or falsify this link?
```

Do not let fluent causal narratives substitute for evidence.
