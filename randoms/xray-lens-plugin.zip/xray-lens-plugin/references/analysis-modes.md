# Analysis Modes

## understand
Build the complete model: context map + Iceberg + relevant dynamics + open questions. Do not force leverage analysis.

## map
Prioritize orientation:
- purpose
- boundary
- upstream sources
- inputs
- transformation / decisions
- outputs
- downstream consumers
- outcomes and impact
- dependencies
- failure consequences

## iceberg
Prioritize Events → Patterns → Structure → Mental Models. Use the context map inside Structure where useful.

## trace
Trace one flow end-to-end:

```text
Source → Input → Transformation → Output → Consumer → Outcome → Impact
```

For each transition capture owner, information/value transferred, dependency, delay, loss/distortion risk, and evidence confidence.

## loops
Requires dynamics analysis. Build closed causal loops, not linear lists.

## leverage
Requires a sufficiently developed model and dynamics. Derive candidates from mechanisms in the model.

## challenge
Stress-test the model. Ask:
- Which arrows are observed vs inferred?
- What alternative explanation fits the same pattern?
- Where could correlation be mistaken for causality?
- Which system boundary choice changes the conclusion?
- Which missing actor, delay, stock, or incentive could invalidate the model?

## compare
Compare explicit intervention candidates against the same system model and goal. Do not compare generic advice in the abstract.

## Depth

### quick
Orientation only. Prefer 5–10 key findings.

### standard
Full useful analysis without exhaustive enumeration.

### deep
Explore competing hypotheses, loop interactions, delays, leverage depth, and validation experiments.
