# System Analysis: <Topic>

## 1. Question
<What are we trying to understand, explain, predict, or change?>

## 2. Purpose and Boundary
**Purpose:**

**Inside the system:**

**Outside the system:**

## 3. Context Map

```text
Upstream -> Input -> [ System ] -> Output -> Downstream -> Outcome -> Impact
```

### Upstream / Sources

### Inputs

### Transformation / Decisions

### Outputs

### Downstream Consumers

### Outcomes

### Impact

### Dependencies

### Failure Consequences

## 4. Iceberg

### Events

### Patterns

### Structure

#### Rules / Incentives

#### Information Flows

#### Stocks / Flows

#### Delays

#### Constraints

#### Dependencies

#### Feedback Loops

### Mental Models

## 5. Stocks and Flows

| Stock | Inflows | Outflows | Why it matters |
|---|---|---|---|

## 6. Feedback Loops

### R1 — <Name>
Type: Reinforcing

```text
A -> B -> C -> A
```

### B1 — <Name>
Type: Balancing

```text
A -> B -> C -> A
```

## 7. Leverage Candidates

### Candidate 1
**Intervention:**

**Mechanism changed:**

**Chain of implications:**

**Blockers / counter-effects:**

**Leverage depth:**

**Evidence confidence:**

## 8. Evidence and Assumptions

### Observed

### Evidence-supported

### Inferred

### Assumed

### Unknown

## 9. Validation
What evidence, experiment, measurement, or observation would update this model?
