# Example: Software Delivery

## Request

```text
/xray-lens "releases are getting slower" action=understand depth=deep focus=delivery
```

## Expected analysis path

1. `xray-lens-analysis` frames the delivery system and builds the Iceberg.
2. `xray-lens-dynamics` tests plausible stocks, flows, delays, and loops.
3. Leverage is not automatically prescribed unless the user requests `action=leverage`.

## Follow-up

```text
/xray-lens "use the previous delivery model" action=leverage goal="reduce median cycle time without adding headcount"
```

Expected leverage candidates should reference mechanisms already identified in the model, such as WIP intake rules, review queue information, or feedback delays.
