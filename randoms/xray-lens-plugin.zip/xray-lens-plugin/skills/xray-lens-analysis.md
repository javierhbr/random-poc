# Skill: xray-lens-analysis

Purpose: frame and explain a system without overloading the skill with detailed method text.

## Parameters

- `topic` — required
- `mode` — `understand`, `map`, `iceberg`, `trace`
- `depth` — `quick`, `standard`, `deep`
- `focus` — optional analysis lens
- `context` — optional current state and constraints
- `goal` — optional decision or desired outcome
- `evidence` — optional observed facts or supplied sources
- `format` — `markdown`, `compact`, `json`

## Required references

1. `../references/framework.md`
2. `../references/analysis-modes.md`
3. `../references/evidence.md`
4. `../references/output-contract.md`

## Behavior

1. Establish system boundary, purpose, and point of view.
2. Map upstream → inputs → transformation → outputs → downstream → outcomes → impact.
3. Apply the Iceberg Model at the requested depth.
4. Identify dependencies, constraints, information flows, and relevant stocks/flows when supported.
5. Separate evidence from inference and assumption.
6. Do not search for leverage points unless explicitly requested or routed by the command.
