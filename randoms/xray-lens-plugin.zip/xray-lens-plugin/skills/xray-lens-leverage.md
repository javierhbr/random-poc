# Skill: xray-lens-leverage

Purpose: derive and compare interventions from an existing system model.

## Parameters

- `system_model` — required
- `mode` — `leverage`, `compare`
- `candidates` — optional user-supplied interventions
- `goal` — desired system outcome
- `constraints` — optional limits on acceptable interventions
- `depth` — `quick`, `standard`, `deep`
- `evidence` — optional observations or sources
- `format` — `markdown`, `compact`, `json`

## Required references

1. `../references/leverage.md`
2. `../references/dynamics.md`
3. `../references/evidence.md`
4. `../references/output-contract.md`

## Behavior

1. Never produce leverage advice from topic popularity alone.
2. Tie every candidate to a mechanism in the system model.
3. Trace the chain of implications.
4. Identify blockers, counter-loops, delays, and side effects.
5. Rank candidates by leverage depth, expected systemic effect, feasibility, reversibility, and evidence confidence.
6. State what observation would falsify each hypothesis.
