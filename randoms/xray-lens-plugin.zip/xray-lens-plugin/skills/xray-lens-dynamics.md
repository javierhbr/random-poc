# Skill: xray-lens-dynamics

Purpose: explain how a system changes over time.

## Parameters

- `system_model` — required; output or findings from `xray-lens-analysis`
- `mode` — `loops`, `dynamics`
- `depth` — `quick`, `standard`, `deep`
- `focus` — optional lens
- `evidence` — optional observations or sources
- `format` — `markdown`, `compact`, `json`

## Required references

1. `../references/dynamics.md`
2. `../references/evidence.md`
3. `../references/output-contract.md`

## Behavior

Identify only dynamics that can be causally explained:

- stocks and flows
- reinforcing loops
- balancing loops
- delays
- constraints / limiting factors
- loop interaction and dominant behavior

Represent every loop as a causal chain that closes back on itself. Mark uncertain links.
