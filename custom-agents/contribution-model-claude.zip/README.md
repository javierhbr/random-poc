# contrib-lint

Run one command, paste the output into your PR.

```bash
python3 contrib-lint.py --base origin/main --copy
```

---

## ⚠️ Read this first: `.contrib/` is a hidden folder

The two config files live in `.contrib/`. The leading dot means **macOS Finder,
Windows Explorer, and plain `ls` all hide it by default.** It is in this zip; it
just may not be visible.

| Where | How to see it |
|---|---|
| macOS Finder | `Cmd + Shift + .` |
| Windows Explorer | View → Show → Hidden items |
| Terminal | `ls -la` |

If you copy this bundle by dragging in a file browser without unhiding first,
you will silently copy everything *except* the configuration, and the script
will exit with `No .contrib/rules.yml`. Use the terminal commands under
**Install** to avoid this entirely.

---

## Every file in this bundle

```
contrib/
├── contrib-lint.py                    the only executable
├── README.md                          this file
├── .contrib/                          ← HIDDEN — the config lives here
│   ├── principles.yml                 your principles; you edit this
│   └── rules.yml                      tiers, caps, fields; you edit this
├── skills/
│   └── contribution-check/SKILL.md    agent skill
└── templates/
    └── capability.yaml                contract template contributors copy
```

### `contrib-lint.py`

The whole tool. ~420 lines of Python, one dependency (PyYAML). It diffs your
branch against a base, classifies the change, derives each capability's risk
tier from its declared permissions, runs whichever checks your config enables,
and prints a markdown block.

You should not need to edit it. Everything tunable was deliberately pushed out
into the two config files — if you find yourself editing the script to change a
threshold, that threshold belongs in `rules.yml` instead.

Goes at your repo root, alongside `.contrib/`.

```bash
python3 contrib-lint.py                    # diff against origin/main
python3 contrib-lint.py --base develop     # different base branch
python3 contrib-lint.py --files a.yaml     # specific files, no git needed
python3 contrib-lint.py --copy             # straight to clipboard
python3 contrib-lint.py --strict           # exit 1 on any ❌ (for CI later)
```

### `.contrib/principles.yml`

**This file is your constitution** — not a copy of one that lives somewhere
else. It is where principles are defined, and the only place they need to be.

Ten starter principles, each with:

| Key | Purpose |
|---|---|
| `id`, `title`, `rule` | always required |
| `check` | optional; names an automated detector in the script |
| `ask` | optional; the question shown to the author when there's no detector |

Four principles have working detectors and tick themselves: **P-01** external
reach, **P-04** capability name overlap, **P-05** compound `purpose`, **P-07**
permission diff. The other six render with their `ask` question for a human to
answer.

Add a principle by appending to the list. Give it an `ask` — a principle with
neither `check` nor `ask` renders as a bare checkbox, and bare checkboxes get
ticked without being read, which is worse than having no checklist because it
looks like review happened.

### `.contrib/rules.yml`

Everything the script needs to know about your repo:

| Section | Controls |
|---|---|
| `paths` | which directories hold behavior vs docs vs governance |
| `workspace_prefixes` | what counts as "inside the workspace" for tier 2 |
| `tiers` | the permission → risk tier mapping and its labels |
| `caps` | maturity permission caps; `enforce: false` makes them advisory |
| `contract_fields` | which contract fields become required at which tier |
| `checks` | turn individual checks on or off |
| `severity` | whether each check renders as ❌ `block`, ⚠️ `warn`, or ℹ️ `note` |

Two knobs worth knowing while adopting: set `caps.enforce: false` to make
maturity caps advisory, and move any `severity` entry from `block` to `warn`.
Loosening a check you aren't ready for is better than having people learn to
ignore red output.

### `templates/capability.yaml`

The annotated contract a contributor copies to
`capabilities/<name>/capability.yaml`.

The top block is always required. The T2 and T3 blocks sit commented out and
only get uncommented if declared permissions push the tier up — so a small
capability stays eight lines, and only something reaching CI needs a rollback
plan. The comments explain the reasoning inline: why explicit paths beat globs,
why `never:` entries have to be checkable, why `halt_and_report` is usually the
right failure mode.

### `skills/contribution-check/SKILL.md`

The agent skill. Copy to `.claude/skills/contribution-check/`.

It tells an agent to run the lint before declaring a change ready, and how to
read each finding. The substantive part is what it forbids: don't edit
`maturity` upward to clear a cap, don't delete a warning from the output before
pasting. Both of those work — there is no registry in this version — which is
exactly why the skill names them explicitly rather than trusting they won't
occur to anyone.

---

## Install

Use the terminal. Dragging in Finder is where the hidden `.contrib/` folder gets
lost.

```bash
cd /path/to/your/repo

cp ~/Downloads/contrib/contrib-lint.py .
cp -r ~/Downloads/contrib/.contrib .
cp -r ~/Downloads/contrib/templates .          # optional
cp -r ~/Downloads/contrib/skills/* .claude/skills/   # optional

pip install pyyaml

ls -la | grep contrib          # confirm .contrib/ is actually there
python3 contrib-lint.py --base origin/main
```

## What it checks

| Check | Config |
|---|---|
| Risk tier derived from declared permissions | `rules.yml → tiers`, `workspace_prefixes` |
| Contract fields required at that tier | `rules.yml → contract_fields` |
| Maturity permission caps | `rules.yml → caps` |
| Permission expansion vs the base branch | `checks.permission_diff` |
| Behavior changed without a scenario | `checks.scenario_required` |
| Governance edits bundled with code | `checks.governance_bundling` |
| Duplicate capability names | `checks.duplicate_names` |
| Principle checklist, some auto-checked | `principles.yml` |

## Troubleshooting

**`No .contrib/rules.yml`** — the hidden folder didn't copy. `ls -la` in your
repo root to confirm, then re-run the `cp -r` above.

**`Needs PyYAML`** — `pip install pyyaml`.

**`No changes detected`** — nothing differs from the base. Check `--base` names a
branch you actually diverged from, or pass `--files` directly.

**Everything shows as tier 0** — no `capability.yaml` files in the diff. Tier is
derived from declared permissions, so a change touching only code and no
contract has nothing to derive from.

## What this does not do

This is a review aid. It exits 0 even with ❌ findings unless you pass
`--strict`, nothing runs it automatically, and nothing stops a merge.

Concretely, it can be defeated by editing `maturity: experimental` → `core`,
which clears the cap check. There is no registry here to check that against —
that is the deliberate cost of the simple version. The "never edit the output to
look cleaner" line in the skill is a norm, not a mechanism.

That's a reasonable trade for a small team where the binding constraint is
attention rather than trust. If you later find people routing around it, the
smallest next step is `--strict` in CI as a required status check — well before
rebuilding a registry.

## Verified

Tested end-to-end against a scratch repo: an Experimental capability declaring
`system: [ci]` is flagged T4-over-cap with its missing T4 fields listed; a
`purpose` containing "and" trips P-05; adding `write: [workspace/cache]` to an
existing contract is caught as both a tier climb (T1→T2) and a permission
expansion; the narrowed version with a scenario comes back clean.
