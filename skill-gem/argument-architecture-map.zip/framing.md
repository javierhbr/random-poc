# Framing

Runs before Discover. A map built on a vague brief is precise about the wrong
thing — and the cost lands after extraction, when it is expensive to redo.

<rule>
Do not start extraction on a vague brief. "Map my docs" is not a brief. Ask
until you can state the output's purpose in one sentence, then read it back for
confirmation.
</rule>

## What must be pinned down

| Slot | Question | Why it changes the output |
|---|---|---|
| **Decision** | What will someone do differently after reading this? | Determines which lens is primary and what can be cut |
| **Reader** | Who opens it — new hire, exec, engineer, investor? | Sets abstraction level and vocabulary |
| **Question** | What single question must it answer? | Becomes the lens `question` field |
| **Scope** | Which docs are in, which are stale or aspirational? | Stale sources poison salience scoring |
| **Stance** | Describe what the docs say, or assess whether it holds up? | Descriptive vs. evaluative changes the whole pipeline |

Missing **Decision** or **Question** blocks the run. The other three can be
inferred and confirmed.

## How to ask

Ask 2–4 targeted questions in one turn, with concrete options drawn from what
you can see. Never send a generic questionnaire.

Bad: *"What are your goals for this project?"*

Good: *"Two readings of 'map my docs' — (a) onboarding: a new engineer
understands the product in ten minutes, or (b) audit: you find the gaps and
contradictions before a review. (a) hides Risks and OpenQuestions; (b) leads
with them. Which?"*

Ambiguity in the corpus is also a framing question. If `roadmap.md` and
`notes.md` disagree on what ships in Q3, ask which is authoritative — don't
average them.

## Stance changes the pipeline

| Stance | Effect |
|---|---|
| **Descriptive** | Report what the docs say. Contradictions become `OpenQuestion` nodes. Challenge stage runs on inferences only |
| **Evaluative** | Test whether claims hold up. Challenge stage runs on everything high-salience. Unsupported claims are demoted, not just flagged |

Default to descriptive. Evaluative is more work and only worth it when the user
is about to defend the material to someone.

## Recording the frame

Write it into the model. It is the contract the rest of the run answers to, and
the thing to re-read when a later output looks off-target.

```yaml
frame:
  decision: "Whether to fund the settlement rewrite in Q3"
  reader: "Engineering leads, not new to payments"
  question: "What breaks today, and what would the rewrite fix?"
  scope_in: [architecture.md, notes.md, adr/]
  scope_out: [business-plan.md]
  stance: evaluative
  confirmed: true
```

`confirmed: true` only after the user has read it back. Then proceed.
