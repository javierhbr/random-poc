---
name: knowledge-map
description: Turn a folder of arbitrary documentation (Markdown, text, YAML, JSON, HTML, PDF) into a versioned semantic knowledge model, then project that model into focused mind maps — product overview, feature detail, business model, architecture, roadmap — ready for a React Flow renderer. Use this skill whenever the user wants to map, visualize, diagram, or make navigable a body of docs, specs, notes, a business plan, or a product description; whenever they mention mind maps, concept maps, knowledge graphs, or "understanding how all these documents fit together"; and whenever they ask to extract the main ideas, concepts, or relationships from a document set — even if they don't say the words "mind map" or "knowledge model".
---

# Knowledge Map

<rule>
Build one knowledge model, many maps. Never build a map straight from documents
— it inherits the table of contents, which is a writing artifact, not a model of
the domain.
</rule>

<non_goals>
- No rendering. An existing React Flow app owns that; the skill stops at JSON.
- No single giant graph. A 700-node cloud is complete and useless.
- No unsourced structure. Every concept and relation carries evidence, and the
  load-bearing ones get challenged by a reviewer who cannot see the reasoning.
</non_goals>

<architecture>
```
SOURCES     .md .txt .yaml .json .html .pdf
   ↓
KNOWLEDGE   knowledge-model.yaml — versioned, hand-editable, the deliverable
   ↓
PROJECTION  lens (declarative) + deterministic graph→tree algorithm
   ↓
MAP JSON    neutral {nodes, edges}
   ↓
ADAPTER     the only file that knows React Flow
```
The model is committed next to the docs. Extraction lands ~80% right; fixing the
rest by editing YAML beats re-prompting and survives regeneration.
</architecture>

<workflow>
<stage n="0" name="Frame">
Do not start on a vague brief. "Map my docs" is not a brief.

Pin down two things before anything else: what **decision** the output serves,
and the single **question** it must answer. Reader, scope and stance can be
inferred and confirmed. Ask 2-4 targeted questions in one turn, with concrete
options drawn from what you can see — never a generic questionnaire.

Write the frame into the model and read it back. Proceed only on
`confirmed: true`. Full protocol: `references/framing.md`.
</stage>

<stage n="1" name="Discover">
Inventory before reading closely. Per file: path, hash, doc type, title, heading
outline. Classify by content, not filename — `notes.md` may hold the only
description of the revenue model.

Show the inventory to the user before extracting. A misread doc type propagates
everywhere.
</stage>

<stage n="2" name="Extract">
Pull typed concepts per `references/ontology.md`. Ignore visualization. Ignore
duplicates for now.

Capture: type, label as written, one-sentence summary, evidence (source + line
span + quote under 15 words).

Score salience, or every run returns a different set of "main ideas":
```
salience = 0.4 × cross_document_frequency   # distinct sources ÷ total sources
         + 0.3 × relation_degree            # its relations ÷ max relations
         + 0.3 × structural_emphasis        # heading, goals list, bold, abstract
```
Keep everything and store the score. Lenses filter; deleting here is unrecoverable.
</stage>

<stage n="3" name="Organize">
**Resolve duplicates** per `references/entity-resolution.md`. Same-name concepts
of incompatible types are not duplicates — "merchants need real-time settlement"
(Problem), "Instant Settlement capability" (Capability) and "Settlement Service"
(Component) are three rungs of one ladder. Collapsing them loses the only thing
the map offers that the documents don't.

**Connect** using ontology relation types only. Each relation carries evidence.
Mark `inferred: true` with lower confidence where you reasoned rather than read.

**Validate:**
```bash
python scripts/validate_model.py knowledge-model.yaml
```
Fix every error before projecting. Read the warnings to the user — most point at
gaps in the docs, not bugs in the model.
</stage>

<stage n="3.5" name="Challenge">
An independent reviewer tests the model's claims against raw source text, with
no access to the extraction's reasoning. Extraction and self-review share a
context, so they share the same mistakes; a reviewer who can see why a claim was
made tends to ratify it.

```bash
python scripts/build_challenges.py knowledge-model.yaml -o challenges/
# dispatch each packet to a fresh sub-agent, collect into verdicts.yaml
python scripts/apply_verdicts.py knowledge-model.yaml verdicts.yaml -o knowledge-model.yaml
python scripts/validate_model.py knowledge-model.yaml
```

Packets carry the claim and verbatim source spans. Nothing else — no confidence,
salience, summaries, or other claims. `build_challenges.py` enforces this and
aborts on a leak.

Verdicts: `supported` → verified; `overstated` → confidence dropped;
`unsupported` → relation removed or concept demoted, plus an OpenQuestion;
`contradicted` → claim removed, conflict recorded. Everything lands in
`challenge_log`.

Report what was overturned **before** projecting. A run where everything passes
usually means selection was too timid, not that the corpus was clean. Full
protocol: `references/challenge.md`.

No sub-agents available: run the packets yourself, one per fresh turn, reading
only the packet. Weaker — you wrote the claims — but the format still withholds
the reasoning. Tell the user which mode ran.
</stage>

<stage n="4" name="Project">
```bash
python scripts/project.py knowledge-model.yaml \
  --lens assets/lenses/product-overview.yaml -o maps/product-overview.json
```
Lenses are YAML in `assets/lenses/` (`references/lenses.md`). The graph→tree
algorithm is in code, not judgment (`references/projection.md`): same model +
same lens ⇒ identical output, so the renderer can persist node positions.
</stage>
</workflow>

<map_catalog>
| Lens | Answers |
|---|---|
| `product-overview` | Who has what problem, and what do we do about it? |
| `feature-detail` | What does this feature involve, need and risk? |
| `business-model` | How does this make money, and from whom? |
| `architecture` | What is built, and what depends on what? |
| `master` | The whole shape, at depth 3, with drill-down on every branch |

Run `product-overview` first — it turns a pile of Markdown into something
navigable. `feature-detail` second.

`master` is the "monumental map", kept safe by depth limits plus drill-down.
Navigation is map → submap → submap.
</map_catalog>

<output_contract>
```json
{
  "map_id": "product-overview", "lens": "product-overview",
  "root": "syn.root", "model_version": 3,
  "stats": {"nodes": 24, "hierarchy_edges": 23, "cross_edges": 3},
  "nodes": [{
    "id": "prb.slow-payouts", "label": "Slow merchant payouts",
    "type": "Problem", "parent": "act.merchant", "depth": 2,
    "summary": "Merchants wait three days for funds.", "salience": 0.71,
    "status": "active", "tags": ["core"], "inferred": false,
    "confidence": 0.9, "evidence_count": 3, "has_more": false,
    "overflow_count": 0, "drilldown_lens": null, "synthetic": false
  }],
  "edges": [
    {"id": "e-0001", "source": "act.merchant", "target": "prb.slow-payouts",
     "kind": "hierarchy", "relation": "experiences", "confidence": 0.9,
     "inferred": false}
  ]
}
```
`kind: hierarchy` forms the tree. `kind: cross` are surviving non-hierarchy
relations; the renderer decides whether to draw them.

When the user supplies the real React Flow schema, map it in
`references/renderer-adapter.md`. React Flow field names never go upstream of
that file.
</output_contract>

<reference_files>
Read as needed, not upfront.

| File | When |
|---|---|
| `references/framing.md` | Frame — before anything else |
| `references/ontology.md` | Extract, Organize |
| `references/entity-resolution.md` | Organize |
| `references/knowledge-model-schema.md` | Before writing the model |
| `references/challenge.md` | Challenge |
| `references/lenses.md` | New view requested |
| `references/projection.md` | Map shape looks wrong |
| `references/renderer-adapter.md` | Integration |
</reference_files>

<working_with_the_user>
- Grill before extracting. A map built on a vague brief is precise about the
  wrong thing, and the cost lands after extraction.
- Show the inventory after Discover, the concept list after Extract, the
  overturned claims after Challenge. All cheap to fix then, expensive later.
- Uncertain merge → `status: pending` in `merge_log`, then ask. Never guess
  silently.
- Large corpus → offer one lens end to end first, before full extraction.
</working_with_the_user>
