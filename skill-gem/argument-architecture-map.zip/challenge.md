# Challenge

Runs between Organize and Project. An independent reviewer, with no access to
the extraction's reasoning, tests each claim against the raw source text.

<why>
Extraction and self-review share a context, so they share the same mistakes. A
reviewer who can see the reasoning that produced a claim tends to ratify it. The
only reliable check is a reader who sees the claim and the source text and
nothing else.
</why>

## What counts as a claim

Two kinds, both testable:

- **Concept claim** — "the corpus describes a Capability called Instant Settlement"
- **Relation claim** — "Instant Settlement solves the three-day settlement problem"

Merges are relation claims too: "these two labels name one thing."

## Selection

Challenging everything is wasteful. `scripts/build_challenges.py` scores each
claim and takes the top N (default 12):

| Signal | Weight |
|---|---|
| Relation marked `inferred` | +3 |
| Confidence below 0.7 | +2 |
| Salience ≥ 0.7 | +2 |
| Part of an applied merge | +2 |
| Only one evidence entry | +1 |

High salience earns weight because a wrong node at the centre of the map poisons
every branch under it. Inference earns the most because it is the one place the
corpus is not speaking.

## The contamination rule

<rule>
A challenge packet contains the claim and verbatim source spans. Nothing else.
</rule>

Excluded, deliberately: `confidence`, `salience`, `inferred`, `summary`,
`aliases`, `merge_log`, every other concept, and any word about why extraction
believed it. `build_challenges.py` asserts these keys are absent before writing
— the guard is in code because this is the kind of rule that erodes quietly.

## Two modes

**verify** (default) — the packet states the claim; the reviewer rules on it.

**reextract** — the packet contains spans and a surface term only, no claim. The
reviewer says what the text actually supports; you diff that against what
extraction produced. Stronger and slower. Applied to the top 3 by salience,
where being wrong is most expensive.

## Packet

```yaml
packet_id: chg.0001
mode: verify
claim_type: relation
claim: "The capability 'Instant Settlement' addresses the problem 'Funds take three days to arrive'."
sources:
  - file: docs/product.md
    lines: [10, 12]
    text: |
      ### Instant Settlement

      Funds reach the merchant account within seconds of capture.
```

## Reviewer instructions

Give the sub-agent this, and only this, alongside the packet:

> You are reviewing one claim against source text. You have not seen the
> analysis that produced it and should not infer it.
>
> Rule only on the text in `sources`. If the text does not settle the question,
> the verdict is `unsupported` — not a guess at what the author probably meant.
>
> Return:
> ```yaml
> packet_id: <id>
> verdict: supported | overstated | unsupported | contradicted
> quote: "<the span that decides it, under 15 words>"
> note: "<one line>"
> suggested_confidence: <0.0-1.0>
> ```
>
> - `supported` — the text states this
> - `overstated` — directionally right, claims more than the text does
> - `unsupported` — the text neither states nor implies it
> - `contradicted` — the text says otherwise

## Verdicts and consequences

`scripts/apply_verdicts.py` merges the results:

| Verdict | Action |
|---|---|
| `supported` | `verified: true`, confidence unchanged |
| `overstated` | Confidence dropped to `suggested_confidence`, `inferred: true` |
| `unsupported` | Relation removed, or concept demoted to `status: proposed`; an `OpenQuestion` is added |
| `contradicted` | Claim removed; an `OpenQuestion` records the conflict |

Every change is written to `challenge_log` in the model, so a reviewer can see
what was overturned and on what evidence.

## Running it

```bash
python scripts/build_challenges.py knowledge-model.yaml -o challenges/
# dispatch each packet to a fresh sub-agent, collect verdicts into verdicts.yaml
python scripts/apply_verdicts.py knowledge-model.yaml verdicts.yaml -o knowledge-model.yaml
python scripts/validate_model.py knowledge-model.yaml
```

No sub-agents available (Claude.ai): run the packets yourself one at a time in
a fresh turn, reading only the packet. Weaker — you wrote the claims — but the
packet format still withholds the reasoning, which removes most of the anchor.
Tell the user which mode ran; the difference matters when they act on a verdict.

## Reporting

Report challenge results before projecting, not after. Lead with what was
overturned:

> Challenged 12 claims. 8 supported. 3 overstated — confidence lowered on the
> Instant Settlement → revenue link, which the business plan asserts without
> support. 1 contradicted: `notes.md` says the dashboard slips to Q1, while
> `roadmap.md` says Q4. Added as an open question.

Overturned claims are the output's most useful product. A run where everything
passes usually means selection was too timid, not that the corpus was clean.
