#!/usr/bin/env python3
"""Build contamination-free challenge packets from a knowledge model.

    python scripts/build_challenges.py knowledge-model.yaml -o challenges/

Each packet carries one claim and the verbatim source spans behind it. Nothing
else -- no confidence, no salience, no summaries, no other claims, no trace of
why extraction believed it. A reviewer who can see the reasoning ratifies it;
the whole point is a reader who cannot.
"""
import argparse
import os
import sys

import yaml

# Keys that must never reach a reviewer. Enforced, not just documented.
BANNED = {"confidence", "salience", "inferred", "summary", "aliases",
          "canonical_label", "merge_log", "evidence_count", "status",
          "suggested_confidence", "verified", "challenge_log"}

REEXTRACT_TOP_N = 3


def score(item, kind, merged_ids, single_ev):
    s = 0
    if kind == "relation" and item.get("inferred"):
        s += 3
    if float(item.get("confidence") or 1.0) < 0.7:
        s += 2
    if float(item.get("salience") or 0.0) >= 0.7:
        s += 2
    if item.get("id") in merged_ids or item.get("from") in merged_ids:
        s += 2
    if item.get("id") in single_ev:
        s += 1
    return s


def read_span(root, path, lines):
    full = os.path.join(root, path)
    if not os.path.exists(full):
        return None
    with open(full) as fh:
        content = fh.readlines()
    if not lines:
        return "".join(content[:20]).rstrip()
    start, end = int(lines[0]), int(lines[-1])
    # a little context on each side; the reviewer needs to see the sentence live
    lo, hi = max(0, start - 2), min(len(content), end + 1)
    return "".join(content[lo:hi]).rstrip()


def spans_for(evidence, sources, root):
    out = []
    for e in evidence or []:
        src = sources.get(e.get("source"))
        if not src:
            continue
        text = read_span(root, src["path"], e.get("lines"))
        if text is None:
            continue
        out.append({"file": src["path"], "lines": e.get("lines"),
                    "text": text})
    return out


def concept_claim(c):
    return (f"The documentation describes a {c['type']} called "
            f"\"{c['label']}\".")


def relation_claim(rel, by_id):
    f, t = by_id[rel["from"]], by_id[rel["to"]]
    verb = rel["type"].replace("_", " ")
    return (f"The {f['type']} \"{f['label']}\" {verb} the {t['type']} "
            f"\"{t['label']}\".")


def assert_clean(packet):
    def walk(node, path="packet"):
        if isinstance(node, dict):
            for k, v in node.items():
                if k in BANNED:
                    raise SystemExit(
                        f"contamination guard: '{k}' at {path} would leak "
                        f"extraction's reasoning into the packet")
                walk(v, f"{path}.{k}")
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
    walk(packet)


def build(model, root, limit):
    sources = {s["id"]: s for s in model.get("sources") or []}
    concepts = model.get("concepts") or []
    relations = model.get("relations") or []
    by_id = {c["id"]: c for c in concepts}

    merged = {m.get("canonical_id") for m in (model.get("merge_log") or [])
              if m.get("status") == "applied"}
    single_ev = {c["id"] for c in concepts if len(c.get("evidence") or []) == 1}

    scored = []
    for c in concepts:
        scored.append((score(c, "concept", merged, single_ev), "concept", c))
    for r in relations:
        scored.append((score(r, "relation", merged, single_ev), "relation", r))

    scored.sort(key=lambda x: (-x[0], x[2].get("id", "")))
    chosen = [x for x in scored if x[0] > 0][:limit]

    # highest-salience concepts get the stronger blind re-extraction
    reextract = {c["id"] for c in sorted(
        concepts, key=lambda c: (-float(c.get("salience") or 0), c["id"])
    )[:REEXTRACT_TOP_N]}

    packets = []
    for i, (_s, kind, item) in enumerate(chosen, 1):
        if kind == "concept":
            ev, cid = item.get("evidence"), item["id"]
            claim = concept_claim(item)
            term = item["label"]
        else:
            ev, cid = item.get("evidence"), item.get("id")
            claim = relation_claim(item, by_id)
            term = by_id[item["from"]]["label"]

        mode = "reextract" if (kind == "concept" and cid in reextract) \
            else "verify"

        packet = {
            "packet_id": f"chg.{i:04d}",
            "mode": mode,
            "claim_type": kind,
            "sources": spans_for(ev, sources, root),
        }
        if mode == "verify":
            packet["claim"] = claim
        else:
            packet["term"] = term
            packet["task"] = ("State what this text asserts about the term "
                              "above, and nothing more.")
        assert_clean(packet)
        packets.append((packet, cid))
    return packets


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("model")
    ap.add_argument("-o", "--out", default="challenges")
    ap.add_argument("--limit", type=int, default=12)
    args = ap.parse_args()

    with open(args.model) as fh:
        model = yaml.safe_load(fh)
    root = os.path.dirname(os.path.abspath(args.model))

    packets = build(model, root, args.limit)
    os.makedirs(args.out, exist_ok=True)

    index = []
    for packet, target in packets:
        path = os.path.join(args.out, f"{packet['packet_id']}.yaml")
        with open(path, "w") as fh:
            yaml.safe_dump(packet, fh, sort_keys=False,
                           default_flow_style=False, allow_unicode=True)
        index.append({"packet_id": packet["packet_id"], "mode": packet["mode"],
                      "target": target, "file": os.path.basename(path)})

    with open(os.path.join(args.out, "index.yaml"), "w") as fh:
        yaml.safe_dump({"packets": index}, fh, sort_keys=False)

    modes = {}
    for p, _ in packets:
        modes[p["mode"]] = modes.get(p["mode"], 0) + 1
    print(f"{len(packets)} packets in {args.out}/ "
          f"({', '.join(f'{v} {k}' for k, v in sorted(modes.items()))})")
    print("dispatch each to a fresh sub-agent; collect verdicts into "
          "verdicts.yaml")
    return 0


if __name__ == "__main__":
    sys.exit(main())
