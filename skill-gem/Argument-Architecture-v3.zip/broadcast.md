# Placement: Broadcast Decks

All-hands, town halls, conference talks, internal keynotes. Nobody approves anything. The goal is that people remember one thing and act on it later.

This is the one artifact where the H.S.T.S.S. arc mostly applies in order — because it's spoken, personal, and the audience gave you the time. It is also the one where the discipline of the skill matters most, because "just tell a story" is how these talks end up forgettable.

## Structure

- **Hook (30 sec).** Idea collision, or a scene. Earn the room. Claim-first is wrong here — nobody's deciding.
- **Stakes.** Business consequence, priced and dated. *Not* personal shame — see storytelling.md on register. "We lost three enterprise renewals in Q2 to the same objection" is stakes. "I felt like a failure" is a keynote.
- **Turn / why now.** What changed. What you or the team found. This is where the claim lands — the thing you want them to remember and do.
- **Scene.** One. Place, Action, Speech. The moment it became real. Told over a blank or single-image slide.
- **Close.** The portable sentence, rehearsed. Then stop.

## Notes

**One claim, still.** The temptation is to cover four things. Broadcast talks that carry one idea get repeated in the hallway; four ideas get "that was good" and nothing else. Run step 1 anyway — even here, "what do I want them to remember?" needs a one-sentence answer.

**Grounds are lighter, not absent.** One chain, or one clean chart, at the Turn. Enough to prove the claim isn't vibes. Not the five-link version — save that for the appendix or the follow-up doc.

**Rebuttals still exist.** People will think objections even if they can't voice them. Name the obvious one aloud and answer it — it reads as confidence and stops the murmur.

**Slides carry images and single sentences.** Bullet slides in a broadcast talk are the fastest way to lose the room. If the slide has a paragraph, it belongs in a doc.

**Length discipline.** Twelve minutes of talk fits in eight. Cut to eight.

**Q&A is a decision deck.** The moment someone asks "so what do you want us to do?" you've switched genres. Have the decision-deck version in your head: claim, chain, qualifier. See deck.md.
