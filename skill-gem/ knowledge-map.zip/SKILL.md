---
name: knowledge-map
description: Turn a pile of arbitrary documentation (Markdown, specs, notes, business plans, research, PRDs, architecture docs) into a single semantic knowledge model, then project it into focused mind maps — product, feature, business, architecture, roadmap — and export React Flow JSON for rendering. Use this skill whenever the user wants to visualize, map, diagram, or "make sense of" a body of documents; whenever they mention mind maps, knowledge graphs, concept maps, product maps, feature maps, architecture maps, or React Flow; and whenever they ask to extract concepts, entities, or relationships from docs — even if they don't use the words "knowledge map". Also use it when a previously generated knowledge model needs a new view, a sub-map, or a re-export.
---

# Knowledge Map

Documentation describes a system. The map is not the documentation — it is the *knowledge inside* the documentation, re-organized around a question someone is actually asking.

This skill separates two jobs that are usually (and wrongly) fused:

1. **Generating the knowledge model** — semantic, hard, done once.
2. **Visualizing it** — mechanical, cheap, done many times.

```
SOURCE      Markdown / text / specs / notes / JSON / YAML
                            │
                            ▼
KNOWLEDGE   Concepts + relationships + hierarchy + evidence   (knowledge.json)
                            │
                            ▼
VIEW        Product / Feature / Business / Architecture / Roadmap   (view.json)
                            │
                            ▼
RENDERER    React Flow JSON                                   (flow.json)
```

Analyze the corpus **once**. Everything after that is projection. If the user asks for a second map, do not re-read the documents — re-project the existing `knowledge.json`.

## The one mistake to avoid

Do not build a monumental map straight from the documents. A single graph containing everything is technically complete and practically useless — 700 nodes, no entry point, nobody reads it.

Build **one knowledge model with many lenses over it**. A lens decides what to include, what to hide, and which hierarchy to impose. The same concept can sit at a different place in different lenses, and that is correct, not a bug.

```
                   Knowledge Model
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼
      Product Lens   Business Lens   Tech Lens
          │              │              │
          ▼              ▼              ▼
       Mind Map       Mind Map       Mind Map
```

## Workflow

Four stages. Do them in order; each one has a concrete artifact.

```
1. Discover  →  what kind of content is here?
2. Extract   →  what concepts exist, regardless of display?
3. Organize  →  how do they connect, and which are the same thing?
4. Project   →  what subset answers this question?
```

### 1. Discover

Inventory before reading everything. For a corpus of more than a handful of files:

```bash
python scripts/scan_docs.py <docs-dir> --out workspace/inventory.json
```

This lists files, heading trees, sizes, and repeated capitalized phrases (candidate concepts). Use it to decide reading order and to spot which documents are the "spine" (usually a product brief, a business plan, or a README) versus supporting detail.

Then read. Prioritize documents that define things over documents that reference them. Note what genres are present — product idea, spec, decision record, business plan, research notes, meeting notes — because genre predicts which entity types will be dense.

Tell the user what the corpus actually contains before mapping it. If the docs are mostly meeting notes with no product definition, a Product Overview lens will be thin, and it's better to say so than to invent structure.

### 2. Extract

Identify concepts without thinking about layout yet. Read `references/ontology.md` for the entity types and what distinguishes them.

Rules that matter:

- **Document structure is not knowledge structure.** A file with `# Introduction / ## Problem / ## Architecture` does not imply the map has those three branches. Headings are hints, not hierarchy.
- **Every node needs evidence.** Record which file (and heading or line) supports it. Evidence is what makes the map auditable and what lets someone jump from a node back to the prose.
- **Mark confidence.** `stated` (the document says it), `implied` (a close reading gives it), `inferred` (you concluded it). Inferred nodes are allowed and often valuable, but they must be labeled so the user can challenge them.
- **Don't extract prose.** A node label is a name — `Instant Settlement`, not `The system should support instant settlement for merchants`. The sentence goes in `summary`.

### 3. Organize

Connect concepts semantically, using the relations in `references/ontology.md`. Two things happen here, and the second one is where most of the value of this skill lives.

**Entity resolution.** The same concept appears under different names in different documents. Merge them into one node with `aliases`, keeping evidence from every source. This is the whole point — it is what a table of contents cannot do.

```
business-plan.md    "Merchants need real-time settlement."
product.md          "Instant Settlement capability."
architecture.md     "Settlement Service."
```

becomes one connected chain rather than three disconnected mentions:

```
Actor: Merchant
   │ has_problem
   ▼
Problem: Settlement takes days
   │ solves (reversed)
   ▼
Capability: Instant Settlement          aliases: real-time settlement
   │ implemented_by
   ▼
Component: Settlement Service
```

Merge when two mentions refer to the same thing in the world. Keep separate when one is a need and the other is the answer to it — `Real-time settlement` (problem) and `Instant Settlement` (capability) are two nodes joined by an edge, not one node. When genuinely unsure, keep them separate and add a `depends_on` or `part_of` edge; a false merge destroys information, a missing merge is visible and fixable.

**Contradictions.** When documents disagree, don't silently pick one. Model both and record the conflict in `meta.conflicts`. Surface these to the user — a map that reveals two documents disagreeing about the revenue model has already paid for itself.

Write `workspace/knowledge.json` (schema in `references/ontology.md`, worked example in `assets/example/knowledge.json`), then validate:

```bash
python scripts/validate_model.py workspace/knowledge.json
```

The validator catches unknown types, dangling edges, `part_of` cycles, backwards relations, and — importantly — near-duplicate labels that suggest a merge you missed. Fix errors before projecting; read the warnings and decide deliberately.

### 4. Project

Pick a lens and generate the view, then the renderer JSON:

```bash
python scripts/project_lens.py workspace/knowledge.json --lens product --out workspace/view-product.json
python scripts/to_react_flow.py workspace/view-product.json --layout radial --out output/flow-product.json
```

Available lenses (details in `references/lenses.md`): `product`, `feature`, `business`, `architecture`, `roadmap`, `master`.

Start with **Product Overview**, then **Feature/Capability**. Those two convert a mountain of Markdown into something navigable without immediately producing an unreadable mega-graph. Offer the others once the user has seen a map they trust.

For a sub-map, re-project from a specific root:

```bash
python scripts/project_lens.py workspace/knowledge.json --lens feature --root cap.instant-settlement --out workspace/view-settlement.json
```

Nodes whose children were pruned are marked `drilldown: true` with a child count, so the renderer can offer `map → submap → submap` navigation instead of rendering everything on one surface. Mention this to the user when a map has drilldown nodes — it's the answer to "where did the rest of the detail go?"

## Matching the user's existing renderer

The user very likely already has a React Flow component with its own JSON shape. `view.json` is the stable contract; the React Flow step is a thin adapter meant to be swapped.

Before exporting, ask for (or inspect) an example of the JSON their visualizer consumes. Then either pass a profile:

```bash
python scripts/to_react_flow.py workspace/view-product.json --profile my-renderer.json --out output/flow.json
```

or, if their shape differs structurally, write a small adapter from `view.json` — that is cheaper and clearer than bending the exporter. See `references/adapter.md` for the default output shape and the profile options.

Never invent a node type name for their renderer. If you don't know what custom node types their component registers, use the default and say so.

## Working files

Keep artifacts in a `workspace/` directory next to the docs, and deliverables in `output/`:

```
workspace/inventory.json     — Discover output
workspace/knowledge.json     — the model (the valuable artifact)
workspace/view-*.json        — one per lens/root
output/flow-*.json           — React Flow payloads
```

`knowledge.json` is the thing worth keeping. Say this to the user explicitly: adding a lens later costs seconds, and re-running extraction on the same docs is waste.

When the docs change, prefer updating the model incrementally — add and revise the affected nodes, keep stable ids — so previously exported views stay comparable.

## Quality bar

Before presenting a map, check it against these. They are the failure modes that make generated maps feel worthless:

- **Is it navigable?** A lens view above roughly 60 nodes should push detail into drilldowns instead.
- **Did it merge across documents?** If every node traces to exactly one file, extraction only reformatted the table of contents.
- **Are the edges meaningful?** `part_of` everywhere means the relations weren't really analyzed.
- **Are labels names, not sentences?**
- **Would a reader disagree productively?** Inferred nodes and surfaced conflicts are the map earning its keep.

Report gaps honestly at the end: concepts mentioned once with no connections, sections of the corpus that produced nothing, questions the documents leave open (model these as `OpenQuestion` nodes — they're often the most useful thing on the map).

## Reference files

- `references/ontology.md` — entity types, relation types with direction conventions, and the `knowledge.json` schema. Read before extracting.
- `references/lenses.md` — what each lens includes, hides, and how it builds hierarchy; how to define a custom lens. Read before projecting.
- `references/adapter.md` — React Flow output shape, profile options, layout choices. Read before exporting.
- `assets/example/` — a small worked corpus and its resulting model, view, and flow JSON. Skim when unsure what "good" looks like.
