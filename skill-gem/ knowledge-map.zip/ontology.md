# Ontology and model schema

Contents:
- [Design intent](#design-intent)
- [Entity types](#entity-types)
- [Relation types](#relation-types)
- [knowledge.json schema](#knowledgejson-schema)
- [Id conventions](#id-conventions)
- [Extraction heuristics by document genre](#extraction-heuristics-by-document-genre)

## Design intent

The ontology is deliberately small. A large ontology makes extraction slow and inconsistent — two runs over the same corpus classify the same sentence differently. Roughly two dozen types cover product, business, and technical documentation well enough that lenses can do the rest of the work.

The type set is closed by default: `validate_model.py` rejects unknown types so that lenses stay predictable. Extending it is fine when a domain genuinely needs it (a research corpus might want `Hypothesis` and `Finding`), but extend deliberately — add the type to `scripts/validate_model.py`, and add it to whichever lens should show it in `assets/lenses.json`, otherwise it will be extracted and then silently hidden from every view.

## Entity types

**Strategy and context**

| Type | Use for | Not for |
|---|---|---|
| `Product` | The system or offering being described. Usually one per corpus; several when the docs cover a portfolio. | A component or module — that's `Component`. |
| `Vision` | The intended future state, in one line. | A list of features. |
| `Goal` | A specific outcome someone wants, ideally measurable. | A feature request phrased as a goal. |
| `Market` | A segment, industry, or geography being served. | A named competitor. |
| `Competitor` | A named alternative, including "do nothing" when the docs treat it as one. | |
| `Actor` | Any person or role that uses, operates, pays for, or is affected by the product. Customers, admins, internal ops, regulators. | An external system — that's `Dependency`. |

**Problem and value**

| Type | Use for | Not for |
|---|---|---|
| `Problem` | A pain, need, or unmet job in the world. Exists independently of the solution. | The absence of a feature ("no dark mode") — find the real pain or skip it. |
| `ValueProposition` | The claim about why this is worth choosing. | A capability — that's `Capability`. |
| `Capability` | Something the product can do, at business granularity. "Instant Settlement", "Fraud Screening". | Implementation. Capabilities survive rewrites. |
| `Feature` | A concrete unit of delivered functionality, at shipping granularity. | A whole product area — that's `Capability`. |
| `Workflow` | An ordered path through the product: user journey, process, lifecycle. | A single interaction. |
| `Requirement` | A specific must-hold statement: functional, business rule, or non-functional target. | A vague aspiration. |

**Execution and technical**

| Type | Use for | Not for |
|---|---|---|
| `Component` | An implementation unit: service, module, library, database, job. | A capability. |
| `Interface` | A contract between components or with the outside: API, event, schema, integration point. | |
| `Dependency` | An external thing depended on that isn't otherwise modeled: vendor, third-party API, regulation, another team. Internal dependencies are better expressed as `depends_on` edges between existing nodes. | |
| `Decision` | A choice that was made, ideally with rationale. Architecture decision records map here. | An open choice — that's `OpenQuestion`. |
| `Constraint` | A fixed limit that bounds the solution space: budget, deadline, compliance, platform, technical ceiling. | A risk. A constraint is true now; a risk might become true. |
| `Risk` | Something that could go wrong, with an effect on something else. | A known current problem — that's `Problem`. |
| `Milestone` | A named point in time or scope: release, phase, quarter, launch. | |
| `Metric` | A measure used to judge success. | A target value alone — put the number in `summary`. |

**Business model**

| Type | Use for |
|---|---|
| `RevenueStream` | A way money comes in: subscription, transaction fee, licence. |
| `CostDriver` | A significant cost: infrastructure, headcount, acquisition, support. |
| `Channel` | How the product reaches users: sales motion, marketplace, partner, self-serve. |

**Uncertainty**

| Type | Use for |
|---|---|
| `OpenQuestion` | Something the corpus raises but does not answer, or a contradiction that needs a human decision. These are frequently the most useful nodes on a map — extract them eagerly. |

### Choosing between close types

- `Capability` vs `Feature`: could you sell it, or roadmap around it, without naming a screen? Capability. Does it correspond to something a team ships in a sprint or two? Feature. When a document uses one word for both, model the general one as `Capability` and hang the specific ones under it with `part_of`.
- `Problem` vs `Goal`: a problem is a bad state that exists; a goal is a good state that's wanted. "Merchants wait three days for funds" is a Problem. "Cut settlement time to under an hour" is a Goal.
- `Requirement` vs `Constraint`: a requirement is about what to build; a constraint is a limit imposed from outside on how you can build it.
- `Decision` vs `Constraint`: a decision was chosen and could be revisited; a constraint wasn't chosen.

## Relation types

Direction matters. `from` and `to` are not interchangeable, and `validate_model.py` warns when an edge looks reversed.

| Relation | From → To | Meaning |
|---|---|---|
| `part_of` | child → parent | Composition or containment. The backbone of most hierarchies. |
| `has_problem` | Actor → Problem | This actor experiences this pain. |
| `solves` | Capability / Feature / ValueProposition → Problem | This addresses that pain. |
| `enables` | Capability / Feature → Goal / Capability | Makes possible or advances. |
| `requires` | Feature / Capability → Requirement / Capability | Needs this to be true or present. |
| `implemented_by` | Capability / Feature → Component / Interface | Realized in code by. |
| `used_by` | Feature / Interface / Component → Actor / Component | Consumed by. |
| `depends_on` | any → any | Would break or block without it. Prefer over a `Dependency` node when both ends already exist. |
| `affects` | Risk / Decision / Constraint → any | Has consequences for. |
| `constrained_by` | any → Constraint | Bounded by. |
| `decided_by` | any → Decision | Shaped by this recorded choice. |
| `measured_by` | Goal / Capability / Product → Metric | Judged by. |
| `monetized_by` | Capability / Feature / Product → RevenueStream | Earns via. |
| `incurs` | Capability / Component / Product → CostDriver | Costs via. |
| `distributed_via` | Product / Capability → Channel | Reaches users through. |
| `competes_with` | Product / Capability → Competitor | |
| `scheduled_in` | Feature / Capability / Milestone → Milestone | Planned for. |
| `targets` | Product / Capability / ValueProposition → Market / Actor | Aimed at. |
| `raises` | any → OpenQuestion | This thing leaves this unanswered. |

There is no `same_as`. Two mentions of one thing become one node with `aliases` — that merge is the work, and leaving both nodes with a link between them defeats it.

Prefer the specific relation over `part_of` when one applies. A map where most edges are `part_of` is a table of contents wearing a costume.

## knowledge.json schema

```json
{
  "version": "1.0",
  "meta": {
    "title": "Acme Payments",
    "generated_at": "2026-08-11",
    "sources": ["docs/product.md", "docs/business-plan.md"],
    "genres": ["product brief", "business plan", "architecture notes"],
    "conflicts": [
      {
        "about": "Revenue model",
        "positions": ["business-plan.md: per-transaction fee", "pricing-notes.md: flat monthly SaaS fee"],
        "note": "Unresolved; both modelled as RevenueStream nodes."
      }
    ],
    "gaps": ["No document describes onboarding for enterprise merchants."]
  },
  "nodes": [
    {
      "id": "cap.instant-settlement",
      "type": "Capability",
      "label": "Instant Settlement",
      "summary": "Funds reach the merchant account within seconds of capture.",
      "aliases": ["real-time settlement", "immediate payout"],
      "tags": ["payments", "core"],
      "status": "planned",
      "confidence": "stated",
      "evidence": [
        { "source": "docs/product.md", "locator": "## Capabilities", "quote": "Instant Settlement capability" },
        { "source": "docs/business-plan.md", "locator": "## Why now", "quote": "Merchants need real-time settlement" }
      ]
    }
  ],
  "edges": [
    {
      "from": "cap.instant-settlement",
      "to": "prob.slow-settlement",
      "type": "solves",
      "confidence": "stated",
      "note": "Optional; explains a non-obvious link.",
      "evidence": [{ "source": "docs/product.md", "locator": "## Capabilities" }]
    }
  ]
}
```

**Node fields**

| Field | Required | Notes |
|---|---|---|
| `id` | yes | Stable, lowercase, `prefix.slug` (see below). Ids are how views stay comparable across regenerations — don't renumber them casually. |
| `type` | yes | One of the entity types above. |
| `label` | yes | A name, 1–5 words. Not a sentence. |
| `summary` | strongly preferred | One line of prose. Renderers show it on hover or in a side panel. |
| `aliases` | when merged | Every other surface form found in the corpus. Makes the merge auditable. |
| `tags` | optional | Free-form; lenses can filter on them. |
| `status` | optional | `idea` / `proposed` / `planned` / `in-progress` / `shipped` / `deprecated`. Drives roadmap colouring. |
| `confidence` | yes | `stated` / `implied` / `inferred`. |
| `evidence` | yes (≥1) | `source` is required; `locator` (heading, line, section) and a short `quote` are strongly preferred. Keep quotes to a handful of words — evidence is a pointer back to the document, not a copy of it. |

**Edge fields**: `from`, `to`, `type` required; `confidence` required; `note` and `evidence` optional.

## Id conventions

`prefix.kebab-slug`, where the prefix marks the type. Consistency lets a human read an edge list without a lookup table.

```
prod.  product          act.   actor          prob.  problem
vis.   vision           goal.  goal           mkt.   market
comp.  competitor       vp.    valueprop      cap.   capability
feat.  feature          flow.  workflow       req.   requirement
cmp.   component        api.   interface      dep.   dependency
dec.   decision         con.   constraint     risk.  risk
ms.    milestone        met.   metric         rev.   revenuestream
cost.  costdriver       chan.  channel        q.     openquestion
```

## Extraction heuristics by document genre

Genre predicts which types are dense, which saves time and prevents forcing a shape onto a document that doesn't have it.

- **Product brief / PRD** — rich in `Capability`, `Feature`, `Actor`, `Problem`, `Requirement`. Usually the spine of the model; extract it first so later documents attach to existing nodes.
- **Business plan** — `Problem`, `Market`, `ValueProposition`, `RevenueStream`, `CostDriver`, `Channel`, `Competitor`. Business plans state capabilities in customer language; expect heavy aliasing against the product brief.
- **Architecture doc / ADR** — `Component`, `Interface`, `Decision`, `Constraint`, `Dependency`. Link every component up to a `Capability` or `Feature` with `implemented_by`, otherwise the architecture lens floats free of the product lens.
- **Spec** — `Requirement`, `Workflow`, `Feature`. Requirements are often buried in prose as "must", "should", "cannot".
- **Meeting or research notes** — `Decision`, `OpenQuestion`, `Risk`, `Problem`. Low signal per word, high signal for uncertainty. Notes are where conflicts with the official documents surface; treat a contradiction found here as a finding, not an error to smooth over.
- **README / docs site** — `Feature`, `Workflow`, `Interface`. Beware: reference docs mirror code structure, which is exactly the structure the map should not inherit.
