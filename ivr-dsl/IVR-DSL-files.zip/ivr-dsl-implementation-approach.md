# Implementation Approach for the IVR DSL

### A practical companion to *Designing a Vendor-Agnostic IVR DSL in TypeScript*

---

## 1. What "using the DSL" looks like, end to end

The design paper establishes *what* the DSL models and *why* the architecture
holds up. This document is about *how a developer actually uses it* — the
repository layout, the CLI, the everyday dev loop, and the concrete patterns
that map each requested capability (multiple flows, routing, loops, retries,
sub-flows, reusable components, reusable API calls, events, vendor mappings)
onto the typed model of §4 of the paper.

The pitch to a developer joining the project is intentionally short:

> Write your IVR application as TypeScript modules in this repo. Run
> `ivr validate` to check it. Run `ivr simulate` to step through it
> interactively, or `ivr test` to run every scenario in CI. When it's green,
> run `ivr compile --target=<vendor>` to produce the vendor artifact and
> `ivr deploy --target=<vendor>` to ship it. You never edit a Connect JSON
> file, an Omilia flow, or a Lex bot model by hand.

Everything below is the substance behind that pitch.

The architecture is a classic compiler pipeline — DSL source → IR →
vendor backend — and the implementation approach in this document is the
practical surface that sits *on top of* that pipeline so a working developer
never has to think about it.

```
   author edits ──► ivr validate ──► ivr simulate ──► ivr test ──► ivr compile ──► ivr deploy
       │                │                 │              │              │             │
       │                │                 │              │              │             │
   DSL source        front end +       simulator     simulator +    front end +   provider
   files in repo     validator         backend       all scenarios  vendor        SDK / IaC
                     (§7.1, §7.2)      (§7.4)        (§8)           backend
                                                                    (§7.4)
```

---

## 2. Repository layout — the shape of an IVR-as-code project

The single most important implementation decision is the *file layout*, because
it determines whether reuse (the paper's primary requirement) is natural or
fights against the developer. The recommended structure separates each kind of
reusable definition into its own module, keeps flows independent, and puts
vendor-specific configuration in one obvious place:

```
ivr-app/
├── ivr.config.ts                # project-level config (vendors, defaults, env)
├── package.json
├── tsconfig.json
│
├── src/
│   ├── context/
│   │   ├── flow-vars.ts         # FlowVars: conversation-driven values
│   │   └── runtime-context.ts   # RuntimeContext: platform-driven values (§4.9)
│   │
│   ├── registry/                # single sources of truth — all `as const`
│   │   ├── prompts.ts           # PromptId derived from `keyof typeof prompts`
│   │   ├── intents.ts           # IntentName + entity schemas
│   │   ├── queues.ts            # transfer destinations
│   │   ├── observability.ts     # named event schemas
│   │   └── runtime-context.ts   # source declarations: callMetadata,
│   │                            # sipHeader, environment, configApi
│   │
│   ├── apis/                    # one module per backend dependency
│   │   ├── account.ts           # ApiDependency: getBalance, getProfile, ...
│   │   ├── dispute.ts
│   │   ├── auth.ts
│   │   └── config.ts            # backs configApi-sourced runtime entries
│   │
│   ├── policies/                # reusable retry / timeout policies
│   │   ├── retries.ts
│   │   └── timeouts.ts
│   │
│   ├── rules/                   # reusable eligibility predicates
│   │   ├── auth.ts              # isAuthenticated, hasActiveSession
│   │   └── account.ts           # isPremium, hasActiveDispute
│   │
│   ├── components/              # reusable flow fragments (subflows)
│   │   ├── authentication.ts    # exports an `authFlow` definition
│   │   ├── survey.ts
│   │   └── language-select.ts
│   │
│   ├── flows/                   # the actual IVR applications
│   │   ├── main.ts              # the root entry flow
│   │   ├── card-services.ts
│   │   ├── billing.ts
│   │   └── lost-card.ts
│   │
│   └── scenarios/               # standalone test scenarios (optional —
│       └── card-services.test.ts  # most live inline on flows)
│
├── generated/                   # checked-in or gitignored, per team policy
│   ├── connect/                 # contact-flow JSON, Lex bot model
│   ├── omilia/                  # Omilia flow artifacts or interpreter config
│   └── golden/                  # golden-file snapshots for SDK tests
│
└── docs/
    └── flow-diagrams/           # auto-generated visualisations (§5.5 below)
```

Three properties of this layout earn their keep:

**Registries are flat and `as const`.** `src/registry/prompts.ts` is one object
literal, frozen with `as const`, exporting both the data and the literal-union
id type derived from it (paper §4.7). This is what gives every reference in
every flow its compile-time check; it only works if the registry is in one
place.

**Flows do not import other flows directly.** Composition between flows happens
through the `subflow` state kind (paper §3.1, §6.2), not through ad-hoc imports.
This keeps each flow independently comprehensible and makes the dependency graph
between flows explicit in the IR rather than implicit in import order.

**`ivr.config.ts` is the only vendor knob.** Anything project-wide — which
vendors are enabled, where to deploy, which environment is which, what the
default retry policy is — lives in one file. No vendor configuration is
scattered across flows.

---

## 3. The developer workflow, mapped to concrete commands

The workflow you sketched maps one-to-one onto a CLI surface. Each step is a
single command, each command is independently runnable, and CI just runs them
in order.

| Step | Command | What happens |
|------|---------|--------------|
| 1. Define behaviour | *(edit `.ts` files)* | `tsc` catches reference-class bugs at the call site (paper §4.7). |
| 2. Validate structure | `ivr validate` | Runs the front end + validator (paper §7.1–§7.2). Reports unreachable states, missing fallbacks, dependency without mocks, log-code duplicates, etc. Exits non-zero on failure. |
| 3. Local simulation | `ivr simulate <flow>` | Interactive REPL or scripted run through the simulator backend (paper §7.4). Step-by-step state walk, with all logs and KVPs surfaced. |
| 4. Run all scenarios | `ivr test` | Runs every declared `testScenario` through the simulator. Asserts state sequence, outcome, and log narrative. CI gate. |
| 5. Generate artifact | `ivr compile --target=<vendor>` | Runs the front end + chosen vendor backend, writes the artifact into `generated/<vendor>/`. |
| 6. Deploy | `ivr deploy --target=<vendor> --env=<env>` | Pushes the artifact to the vendor (Connect contact-flow import, Lex bot publish, Omilia upload or interpreter-service deploy). |

Two additional commands matter in practice even though you didn't list them:

- **`ivr diff --target=<vendor>`** — diffs the about-to-be-emitted artifact
  against the last deployed one. This is what makes a code review of a flow
  change *meaningful*: reviewers see "this PR changes one decision branch" not
  "this PR rewrites 800 lines of Connect JSON."
- **`ivr graph <flow>`** — emits a Mermaid or DOT diagram of the flow's state
  graph. Auto-generated docs, kept in sync with the code, no separate Visio
  file to maintain.

Both commands are pure functions over the IR, so they cost nothing to add.

---

## 4. Modeling each requested capability

Eight capabilities were named. Each maps onto a specific authoring pattern in
the DSL. The mapping is direct and consistent — there is one way to do each
thing, which is the point of a DSL over a freeform programming model.

### 4.1 Multiple IVR flows

Each flow is its own TypeScript module under `src/flows/`, each calling
`defineFlow(id)` and `.build()`ing a `Flow` object. The project's root flow —
the one the carrier dials into — lives in `src/flows/main.ts` and routes to the
others by `subflow`. There is no "main file" or registration step: flows are
discovered by the CLI scanning `src/flows/**/*.ts`.

```typescript
// src/flows/main.ts
export const mainFlow = defineFlow("main")
  .collect("greet_and_route", {
    prompts: ["mainMenuWelcome"],
    acceptedIntents: [
      { intent: "cardServices", to: "into_card_services" },
      { intent: "billing",      to: "into_billing" },
      { intent: "lostCard",     to: "into_lost_card" },
    ],
    dtmf: { "1": "into_card_services", "2": "into_billing", "3": "into_lost_card" },
    retries: standardRetries("to_agent"),
    timeouts: standardTimeouts,
  })
  .subflow("into_card_services", { flow: "card_services", next: "ended" })
  .subflow("into_billing",       { flow: "billing",       next: "ended" })
  .subflow("into_lost_card",     { flow: "lost_card",     next: "ended" })
  .terminal("ended", { reason: "main flow returned" })
  .transfer("to_agent", { destination: queues.generalSupport })
  .fallback("to_agent")
  .build();
```

The `FlowId` literal-union type is derived from the set of declared flows
across the repo, so `flow: "billling"` is a `tsc` error at the call site. Each
flow is independently validated, simulated, tested, and compiled.

### 4.2 Routing logic

Routing — choosing where the call goes based on context — is the `decision`
state kind. Conditions are **reusable named `EligibilityRule`s**, not inline
boolean expressions, so the same predicate (`isPremium`, `isAuthenticated`,
`isAfterHours`) is defined once in `src/rules/` and referenced everywhere.

```typescript
// src/rules/business-hours.ts
export const isAfterHours: EligibilityRule = {
  name: "isAfterHours" as RuleName,
  describe: "Outside Monday–Friday 8am–6pm Eastern",
  evaluate: (ctx) => /* ... */,
};

// In any flow:
.decision("route_by_hours", {
  branches: [
    { when: isAfterHours,    transition: { to: "after_hours_message" } },
    { when: isPremium,       transition: { to: "premium_queue" } },
  ],
  otherwise: { to: "standard_queue" },
})
```

Each branch is a typed pair (rule, transition). Order matters: the first
matching branch wins, `otherwise` is required, and unreachable branches (one
that follows an always-true predicate) are surfaced by the validator's metadata
lint as a warning.

### 4.3 Loops and retries

There are two distinct concepts the DSL deliberately keeps separate:

**Retries on the same turn** (no-input / no-match) are configured via the
state's `retries: RetryPolicy` (paper §3.5). The escalating-prompt strategy and
`onExhausted` transition are declared once and reused as `standardRetries`:

```typescript
// src/policies/retries.ts
export const standardRetries = (escalateTo: StateId): RetryPolicy => ({
  maxNoInput: 2,
  maxNoMatch: 2,
  escalatingPrompts: ["reprompt1", "reprompt2"],
  onExhausted: { to: escalateTo },
});

// Then in any collect state:
retries: standardRetries("to_agent"),
```

**Loops across states** (e.g. "play balance, return to menu, accept another
request") are expressed by transitioning back to an earlier state — the
canonical "back to main menu" pattern. The validator's reachability check
treats cycles as legal as long as every cycle has an exit edge (otherwise = a
caller stuck forever); a cycle with no exit is rejected. The worked example in
§9 of the paper does exactly this: `play_balance.next = "ask_intent"`.

### 4.4 Sub-flows within the same application

Sub-flows use the `subflow` state kind. The parent flow names the child by
`FlowId`, declares the `next` state to return to, and the IR resolves the
reference at compile time. From the parent's perspective, the child is a single
node; from the child's perspective, it doesn't know it's a child. This is what
makes flows independently testable.

A practical pattern is the **shared `authenticationFlow` subflow**:

```typescript
// src/components/authentication.ts — exported once, used everywhere
export const authenticationFlow = defineFlow("authentication")
  .apiCall("verify_caller_id", { /* ... */ })
  .collect("ask_pin",          { /* ... */ })
  .apiCall("verify_pin",       { /* ... */ })
  .decision("authenticated?",  { /* sets authStatus and returns */ })
  // ...
  .build();

// In a card-services flow:
.subflow("authenticate", { flow: "authentication", next: "main_menu" })
```

Sub-flow results flow back through `FlowContext` (paper §6.3): the child writes
to declared `FlowVars` keys, the parent reads them. The closed `FlowVars`
interface keeps this typed end-to-end.

### 4.5 Reusable flow components

The paper's design makes "everything is a TypeScript value" the reuse model
(§6.1), and the project layout in §2 above is what operationalises it. The
practical pattern is **definition once, import everywhere**:

| Component | Lives in | Imported as |
|-----------|----------|-------------|
| Prompts | `src/registry/prompts.ts` | named exports off the `prompts` object |
| Retry / timeout policies | `src/policies/` | named functions / constants |
| Eligibility rules | `src/rules/` | named `EligibilityRule` exports |
| Transfer destinations | `src/registry/queues.ts` | members of the `queues` object |
| Runtime-context entries | `src/registry/runtime-context.ts` | members of the `runtimeContext` object, typed by the `RuntimeContext` interface in `src/context/` (§4.9) |
| Sub-flows | `src/components/` and `src/flows/` | by `FlowId` reference |
| Test scenario fragments | inline on flows or `src/scenarios/` | called from a flow's `.testScenario()` |

Every one of these is type-checked at the import site. Find-all-references and
rename-symbol work because everything is real TypeScript.

### 4.6 Reusable API calls

API dependencies — backends the IVR calls into — are their own modules in
`src/apis/`. Each module exports one `ApiDependency` declaring its operations,
schemas, timeouts, **and mock responses** (paper §3.9, §3.13):

```typescript
// src/apis/account.ts
export const accountApi: ApiDependency = {
  name: "accountApi" as ApiName,
  operations: [
    {
      name: "getBalance" as OpName,
      requestSchema: getBalanceRequestSchema,
      responseSchema: getBalanceResponseSchema,
      timeoutMs: 2000,
      mocks: [
        { label: "success",   kind: "success", body: { balance: 1234.56 } },
        { label: "not_found", kind: "error",   body: { code: "ACCOUNT_NOT_FOUND" } },
        { label: "timeout",   kind: "timeout", body: null },
      ],
    },
    { name: "getProfile" as OpName, /* ... */ },
  ],
};
```

A flow then registers its dependencies once and references operations by name:

```typescript
defineFlow("card_services")
  .withDependencies([accountApi, disputeApi])
  .apiCall("lookup_balance", {
    dependency: "accountApi",   // ApiName — checked
    operation: "getBalance",    // OpName  — checked against accountApi
    saveAs: "balance",          // VarName — checked against FlowVars
    onSuccess: "decide_route",
    onError:   "to_agent",
    onTimeout: "to_agent",
  })
```

Mocks aren't a test-time afterthought — they live on the dependency itself, and
the validator rejects any dependency that doesn't declare at least one success
and one failure mock. This is what makes the simulator (`ivr simulate`, `ivr
test`) work without a network: every API call has a canned answer the team has
already designed.

### 4.7 Events and telemetry

Two distinct surfaces, both portable, both first-class in the DSL (paper §3.12,
§3.14):

**Observability events** for *measurement* — low-cardinality, structured,
consumed by dashboards. Declared on a state's `emits` field:

```typescript
.collect("ask_intent", {
  /* ... */
  emits: [
    { name: "intent.recognized", payloadSchema: intentEventSchema },
  ],
})
```

**Log statements** for *narrative debugging* — per-call, human-readable,
consumed by on-call engineers. Declared on a state's `logs` field, with
categories for state-entry/exit, decisions, API request/response, fallbacks,
and custom messages:

```typescript
.apiCall("lookup_balance", {
  /* ... */
  logs: [
    { category: "stateEntry", level: "info",
      code: "balance.lookup.start",
      message: "Looking up balance for {accountId}",
      includeVars: ["accountId"],
      redact:      ["fullSsn"] },
    { category: "fallback", level: "warn",
      code: "balance.timeout",
      message: "Balance lookup timed out — routing to agent" },
  ],
})
```

Both surfaces are vendor-projected by adapters: observability events become
CloudWatch metrics + Connect attributes on AWS, Omilia events on Omilia,
in-memory buffers in the simulator. Log statements become CloudWatch log lines
with `code` as a queryable field, Omilia console logs with `code` as a KVP, and
assertable buffers in the simulator. Redaction is enforced unconditionally by
every adapter — a redacted variable never appears in any sink.

The validator enforces two rules here: every log `code` must be unique within a
flow (so searches are unambiguous), and every `{var}` placeholder in a `message`
must resolve to a declared `VarName`.

### 4.8 Provider-specific mappings

Three escape hatches, in order of how much they deviate from the portable
model:

**`vendorHints`** in `Metadata` — namespaced per vendor, for tuning knobs the
portable model doesn't expose:

```typescript
metadata: {
  vendorHints: {
    omilia:  { bargeInSensitivity: 0.7 },
    connect: { loggingBehavior: "Enabled" },
  },
}
```

A backend reads only its own namespace; an unknown namespace or unrecognised key
becomes a validator lint warning so typos surface.

**`InlineCode`** — vanilla-JS snippets attached at a defined lifecycle hook,
vendor-tagged, with declared `reads`/`writes` so data-flow checks still work
even though the body is opaque (paper §4.6). Use this when a vendor offers a
capability — like Omilia's custom JS — that the portable model intentionally
doesn't replicate.

**The project's mismatch policy** — declared once in `ivr.config.ts`, governing
what happens when a flow uses an `InlineCode` block for a vendor and is then
compiled to a different vendor:

```typescript
// ivr.config.ts
export default {
  vendors: ["omilia", "connect", "lex", "simulator"],
  inlineCodeMismatchPolicy: "downLevelToLambda", // or "failCompile"
  defaultPolicies: {
    retries: standardRetries,
    timeouts: standardTimeouts,
  },
};
```

The policy is set at the project level so a flow author never has to decide it
per state — the decision is made once, deliberately, by whoever sets up the
project.

### 4.9 Runtime context and platform values

Some values the IVR needs are not earned from the conversation — they're
given by the platform. The caller's phone number (ANI), the dialed number
(DNIS), SIP headers, tenant identifier, customer market, feature flags,
preferences fetched from a config API before the first prompt plays.
Vendors expose these differently — Connect contact attributes, Lex session
attributes, Omilia KVPs and trigger context, raw SIP variables — and the
DSL needs to model them in a way that is portable, typed, and explicitly
separate from conversation data.

This is what `RuntimeContext` is for. It is a *parallel typed surface* to
`FlowVars`: both closed interfaces, both projecting `keyof` literal-union
name types, both visible from any flow's `FlowContext`. The difference is
intent and lifecycle — `FlowVars` is mutable and conversation-driven,
`RuntimeContext` is read-mostly and platform-driven.

```typescript
// src/context/runtime-context.ts — the closed interface
export interface RuntimeContext {
  ani:        string;
  dnis:       string;
  channel:    "voice" | "chat" | "messaging";
  sipCallId:  string;
  tenantId:   string;
  market:     "US" | "MX" | "CA";
  preferredLanguage?: Locale;          // genuinely optional — handled explicitly
  featurePremiumQueue: boolean;
}

// src/registry/runtime-context.ts — declares HOW each entry resolves
export const runtimeContext = {
  ani:        { source: "callMetadata", field: "ani",  required: true },
  dnis:       { source: "callMetadata", field: "dnis", required: true },
  sipCallId:  { source: "sipHeader",    header: "Call-ID" },
  tenantId:   { source: "environment",  envVar: "TENANT_ID", required: true },
  market:     { source: "configApi",    dependency: "configApi",
                operation: "getMarketForDnis", cacheTtl: "1h",
                fallback: { value: "US" as const } },
  preferredLanguage: { source: "configApi", dependency: "configApi",
                       operation: "getCustomerPreferences", cacheTtl: "5m" },
  featurePremiumQueue: { source: "environment",
                         envVar: "FEATURE_PREMIUM_QUEUE",
                         default: false as const },
  // ...
} as const satisfies RuntimeContextRegistry<RuntimeContext>;
```

The `satisfies` constraint is the keystone: every interface key must have
a registry entry, and every registry entry's source must produce a value
the interface accepts. A drift between the two — a misspelt key, a
default whose type doesn't match — is a `tsc` error at this one file.

**Five sources** cover every vendor cleanly: `callMetadata` (built-ins
every platform exposes — ANI, DNIS, channel, entry point), `sipHeader`
(a named SIP header), `environment` (env var or platform binding),
`incoming` (passed into the IVR at invocation), and `configApi` (fetched
from a declared dependency, with caching and explicit fallbacks).

**References from flows** use the typed `ctx.runtime.X` accessor in
TypeScript and the `runtime.X` prefix in strings:

```typescript
// Eligibility rule:
export const isUsMarket: EligibilityRule = {
  name: "isUsMarket" as RuleName,
  describe: "Caller's market is US",
  evaluate: (ctx) => ctx.runtime.market === "US",      // typed
};

// Transfer payload — mix freely, prefixed names are runtime:
.transfer("to_agent", {
  destination: queues.generalBanking,
  contextPayload: [
    "customerId", "authenticated",                     // FlowVars
    "runtime.ani", "runtime.tenantId",                 // RuntimeContext
    "runtime.sipCallId", "runtime.market",
  ],
})

// Log message — `{name}` is FlowVars, `{runtime.name}` is runtime context:
logs: [
  { category: "stateEntry", level: "info",
    code: "main.welcome",
    message: "Call from {runtime.ani} dialing {runtime.dnis} (call={runtime.sipCallId})",
    includeVars: ["runtime.ani", "runtime.dnis", "runtime.sipCallId"] },
]
```

**API calls can inject runtime context into outbound requests** via a
`headers` field (and a `requestEnrichment` field for request-body
injection):

```typescript
.apiCall("balance_lookup", {
  dependency: "accountApi",
  operation:  "getBalance",
  saveAs:     "balance",
  headers: {
    "x-tenant-id": "runtime.tenantId",
    "x-call-id":   "runtime.sipCallId",
    "x-market":    "runtime.market",
  },
  onSuccess: "play_balance",
  onError:   "to_agent",
  onTimeout: "to_agent",
})
```

Every right-hand side is a typed reference — `runtime.X` checked against
`RuntimeContext`, bare `X` checked against `FlowVars` — so a header
referencing an undeclared field fails compilation at this call site, not
when CloudWatch shows blank values.

**Test scenarios provide runtime context explicitly:**

```typescript
.testScenario({
  name: "US-market caller with known preferences",
  startState: "welcome",
  runtimeContext: {
    ani:        "+15551234567",
    dnis:       "+18005550100",
    channel:    "voice",
    sipCallId:  "abc-123-def",
    tenantId:   "firsttrust",
    market:     "US",
    preferredLanguage: "en-US",
    featurePremiumQueue: false,
    // ...
  },
  steps: [ /* ... */ ],
  expectStateSequence: [ /* ... */ ],
})
```

`runtimeContext` is typed against the `RuntimeContext` interface, so
missing a required field is a `tsc` error at the scenario definition.
Validator rule R-RT-4 (see the runtime-context addendum) backs this up at
the IR level for fields the flow actually reads.

**Vendor projection** follows the same portability-contract pattern as
`Metadata` (paper §4.5): each backend implements one mapping per
`RuntimeSource` kind. Connect resolves `callMetadata` from the contact's
customer endpoint, `sipHeader` from Connect's SIP attribute bag, and
`configApi` via a Lambda at flow entry. Lex receives the same values as
session attributes set by the upstream Connect contact-flow. Omilia maps
to its native call-context KVPs and pre-flow REST hooks. The simulator
reads from the scenario's `runtimeContext` field. A flow that uses
`runtime.tenantId` shows up under that name on every platform.

**Honest scope.** The DSL standardises the *declaration* (what context
values exist, what their types are, what their sources are) and the
*reference syntax* (`runtime.X` everywhere). It does not standardise the
per-platform resolution semantics — Connect's SIP attribute bag, Omilia's
trigger context, and Lex's session attributes each have their own quirks
the platform documentation covers. The contract is: the same declared
runtime field gets the same value into the flow's `ctx.runtime.X` on
every platform; the *mechanism* differs and remains a vendor concern.

See `ivr-dsl-runtime-context.md` for the full design (the source
taxonomy, the validator rules R-RT-1 through R-RT-4, the per-vendor
projection table, and the optional-field handling story).

---

## 5. Local validation and testing in detail

Steps 2–4 of the workflow — validate, simulate, test — are where most
day-to-day development time is spent, so the implementation has to make them
fast and friendly.

### 5.1 `ivr validate`

Runs the front end and the validator (paper §7.1, §7.2). Two output modes:

- **Per-file** by default — like `tsc`, reports diagnostics with file/line
  pointers, exits 0 if clean.
- **Project-wide** with `--all`, which additionally checks cross-flow
  properties (every `subflow` target exists; every flow's `FlowVars` is
  consistent with the flows that call it).

Diagnostics carry a stable error code (`IVR/E001` for a dangling transition,
`IVR/E014` for a dependency without mocks, etc.) so a team can grep for
specific failure modes in CI logs and document common ones internally.

### 5.2 `ivr simulate`

The interactive surface, for exploratory development. Runs the simulator
backend against a chosen flow:

```
$ ivr simulate card_services --start ask_intent

→ state: ask_intent  (collect)
  prompt: "Welcome to card services. What can I help you with?"
  accepted intents: checkBalance, disputeTxn
  DTMF: 1 → lookup_balance, 2 → dispute_subflow, 0 → to_agent

  > input intent checkBalance

→ state: lookup_balance  (apiCall)
  dependency: accountApi.getBalance
  available mocks: success, not_found, timeout

  > input apiResponse success

  ✓ saved: balance = 1234.56
  → onSuccess → decide_route

→ state: decide_route  (decision)
  rule: isAuthenticated → ✗ (authStatus = "anonymous")
  → otherwise → to_agent

  ⚠ fallback log emitted: balance.timeout ("Balance lookup timed out — routing to agent")
```

The simulator also accepts a scripted form (`--script scenario.json`) so the
same loop can be driven from a file, and a `--breakpoint` mode that pauses at
states tagged `metadata.debug.breakpoint`. This is where the metadata
debugging affordances of paper §4.5 earn their keep.

### 5.3 `ivr test`

The CI gate. Runs every declared `testScenario` from every flow, in parallel,
through the simulator. Asserts on state sequence, final outcome, expected
prompts played, and — uniquely to the DSL — the **log narrative**:

```typescript
.testScenario({
  name: "authenticated caller checks balance",
  startState: "ask_intent",
  steps: [
    { input: "intent", name: "checkBalance" },
    { input: "apiResponse", dependency: "accountApi", mockLabel: "success" },
  ],
  expectStateSequence: ["ask_intent", "lookup_balance", "decide_route", "play_balance"],
  expectOutcome: { kind: "terminal", id: "play_balance" },
  expectLogs: [
    { code: "balance.lookup.start", level: "info" },
    { code: "balance.response",     level: "info" },
  ],
})
```

Coverage reporting falls out of this for free: the simulator records which
states each scenario visits, so `ivr test --coverage` reports unvisited states
exactly the way a code-coverage tool reports unexecuted lines. An unvisited
state is the IVR equivalent of dead code and almost always a missing scenario.

### 5.4 CI integration

The recommended CI pipeline is short:

```yaml
# .github/workflows/ivr.yml  (illustrative — same shape on any CI)
jobs:
  ivr:
    steps:
      - run: npm ci
      - run: npx tsc --noEmit                          # type layer
      - run: npx ivr validate --all                    # structural validation
      - run: npx ivr test --coverage                   # scenario execution
      - run: npx ivr compile --target=connect          # golden-file diff
      - run: npx ivr compile --target=omilia
      - run: npx ivr diff --target=connect --against=main   # PR check
```

Each step is fast (everything is pure functions over data, paper §8.1) and
deterministic. Only the deploy step (§6 below) requires real vendor credentials
or network access; everything up to that point runs offline in seconds.

### 5.5 Auto-generated documentation

`ivr graph <flow>` emits a Mermaid diagram of the state graph; `ivr docs` walks
every flow and produces a markdown file per flow listing states, prompts,
intents, dependencies, observability events, log codes, and metadata. Both are
pure derivations from the IR and are checked into `docs/` so a stakeholder who
doesn't read TypeScript can still review what the IVR does.

This is also where the `Metadata.description`, `owner`, and `tags` fields earn
their place — they're what gives the generated docs human context. The IVR
ceases to be opaque to non-engineers, which is a quietly significant win.

---

## 6. Vendor artifact generation and deployment

Steps 5 and 6 of the workflow — compile and deploy — are where the DSL meets a
real vendor. Each vendor backend is implemented as an independent module
behind a common contract (`compile(ir: IR) => VendorArtifact`), which is the
Liskov substitution property the paper relies on (§5.3).

### 6.1 Generation

```
$ ivr compile --target=connect
  ✓ card-services      → generated/connect/card-services.json
  ✓ billing            → generated/connect/billing.json
  ✓ lost-card          → generated/connect/lost-card.json
  ✓ lex bot model      → generated/connect/lex-bot.json
  ✓ Lambda manifest    → generated/connect/lambdas.json     (one per apiCall)
  ✓ schema-validated against AWS Connect contact-flow schema

$ ivr compile --target=omilia
  ✓ card-services      → generated/omilia/card-services.json
  ✓ NLU configuration  → generated/omilia/nlu.json
  ⚠ 2 InlineCode blocks placed natively (omilia.afterApiCall hooks)
```

Two output classes:

- **Direct generation** for Connect/Lex (and any future vendor with a JSON
  import surface). The backend emits artifacts that can be imported by the
  vendor's tooling or pushed via their API. This is the simple case.
- **Compile-time generation OR runtime orchestration** for Omilia, depending
  on what Omilia's API surface supports — a decision Step 4 of the build order
  (paper §10.4) is designed to make empirically. The output of the Omilia
  backend is either an Omilia flow artifact (generation path) or a config
  bundle for the interpreter service (orchestration path). The flow author
  doesn't see the difference; the deploy step does.

### 6.2 Deployment

```
$ ivr deploy --target=connect --env=staging
  → uploading 3 contact flows to AWS Connect (us-east-1, staging instance)
  → publishing Lex bot v17 (alias: staging)
  → deploying 4 Lambda functions
  ✓ deployed in 47s

$ ivr deploy --target=omilia --env=prod
  → uploading flow artifact via Omilia API
  → triggering production reload
  ✓ deployed in 12s
```

Deploy is the only step that requires credentials and network access; it's
also the only step that's vendor-specific in terms of *how* it runs. The
recommended pattern is to back deployment with Infrastructure-as-Code
(Terraform / CloudFormation for AWS; whatever Omilia supports for Omilia) so
deployments are reproducible and rollbacks are a `terraform apply` of the
previous artifact.

Per-environment configuration — staging vs production phone numbers, queue
ARNs, Lambda aliases — is resolved at deploy time from `ivr.config.ts`, not
hard-coded into flows. A flow has no idea which environment it's running in,
which is what makes one definition deployable to many environments.

### 6.3 Versioning and rollout

Two patterns work well in practice:

- **Git tag → vendor version.** A tag in the repo (`v1.4.2`) maps to a
  publishable vendor version. `ivr deploy --version=v1.4.2` deploys exactly
  the tagged state, no surprises.
- **A/B and gradual rollout via `vendorHints`.** A flow can carry an A/B flag
  in `metadata.attributes`, and the vendor adapter projects it as a routing
  attribute the vendor's own A/B mechanism understands. The DSL doesn't
  invent its own A/B system; it surfaces what the vendor already has.

---

## 7. A day in the developer's life

To make this concrete, here's the rhythm of a small task — "add a routing
branch so premium callers skip the menu and go straight to the premium queue":

1. **Edit `src/rules/account.ts`** to add the predicate if it doesn't exist:
   ```typescript
   export const isPremium: EligibilityRule = {
     name: "isPremium" as RuleName,
     describe: "Caller account tier is premium",
     evaluate: (ctx) => ctx.vars.accountTier === "premium",
   };
   ```
   If `accountTier` isn't on `FlowVars`, TypeScript catches that immediately.

2. **Edit `src/flows/main.ts`** to add a decision step before the menu:
   ```typescript
   .apiCall("lookup_account", { /* fills accountTier */ })
   .decision("route_premium", {
     branches: [{ when: isPremium, transition: { to: "premium_queue" } }],
     otherwise: { to: "greet_and_route" },
   })
   .transfer("premium_queue", { destination: queues.premium })
   ```

3. **Add a scenario** confirming the new branch:
   ```typescript
   .testScenario({
     name: "premium caller skips menu",
     startState: "lookup_account",
     steps: [{ input: "apiResponse", dependency: "accountApi", mockLabel: "premium_success" }],
     expectStateSequence: ["lookup_account", "route_premium", "premium_queue"],
     expectOutcome: { kind: "transfer", id: "premium_queue" },
   })
   ```

4. **Run locally:**
   ```
   $ npx ivr validate
   $ npx ivr test
   $ npx ivr diff --target=connect       # review the diff before pushing
   ```

5. **Push, CI runs the same commands, PR reviewer reads `ivr diff` output**
   to see exactly what changes in the generated Connect JSON.

6. **Merge → CI deploys to staging → smoke-test → promote to prod.**

No vendor portal was opened. No JSON was hand-edited. The behaviour change is
one diff, one PR, one merge, traceable end-to-end in source control. That is
the point of the whole exercise.

---

## 8. Recommended adoption path

The paper's §10 build order is the right one for the **SDK itself**. For an
**application team adopting the DSL** in a project that already has IVR flows,
a different sequencing applies — the SDK is given, and what's being managed is
the migration risk:

1. **Pick one flow, the simplest in production.** Rewrite it in the DSL.
   Compile and deploy alongside (not replacing) the existing flow. Route a
   small fraction of traffic to it. Compare metrics.

2. **Establish the registries from real data.** Pull existing prompts,
   intents, queues, and API dependencies out of the current vendor
   configuration and into the registry modules. This is the most tedious
   step and the most valuable: at the end of it, the team has a single source
   of truth they never had before.

3. **Migrate flows in order of churn.** The flows that change most often are
   where the DSL pays back fastest, so prioritise them. Stable flows can stay
   on the vendor's native authoring tool indefinitely; nothing forces a full
   migration.

4. **Adopt the simulator before the validator.** Counter-intuitive, but
   teams accept "I can step through my flow locally" faster than "the compiler
   yells at me." Once they've used the simulator a few times, the validator's
   rejections feel helpful rather than obstructive.

5. **Make the diff command the centre of code review.** A reviewer who can
   see `ivr diff` output on every PR — and only that — gets a clear,
   reviewable change. This is the single biggest cultural shift the DSL
   enables, and the one that's easiest to underinvest in.

6. **Resist letting `InlineCode` and `vendorHints` become the primary path.**
   When a developer reaches for the escape hatch a third time for the same
   thing, that's the signal to grow a typed feature in the core model (paper
   §4.6 closes on the same point). The escape hatch is honest; it should also
   be rare.

The honest expectation is that steps 1–2 take a quarter, steps 3–5 take a
year, and step 6 is a discipline maintained forever. The payoff — flows that
can move between vendors as a recompile, not a rewrite — is worth the runway.

---

## 9. Summary

The implementation approach is a thin layer on top of the paper's architecture:
a conventional repository structure, a six-command CLI that maps directly onto
the workflow you described, and one specific pattern per requested capability —
multiple flows as independent modules, routing as decision states with reusable
rules, retries as declarative policies, loops as cycle transitions, sub-flows
as a first-class state kind, reusable components as ordinary TypeScript exports
from registries, reusable API calls as `ApiDependency` modules with mocks
attached, events and telemetry as the dual surfaces of `ObservabilityEvent`s
and `LogStatement`s, **platform-given values as `RuntimeContext` — a typed
parallel surface to `FlowVars` with declarative source declarations
(`callMetadata`, `sipHeader`, `environment`, `incoming`, `configApi`)**, and
provider-specific mappings funnelled through the typed `vendorHints` and
`InlineCode` escape hatches.

The developer experience that falls out of this is the one the goal statement
asks for: define behaviour once, validate it locally, simulate it without a
vendor, test it in CI, generate artifacts mechanically, deploy them through
IaC. Every step is fast because every step is a pure function over data
(paper §8.1); every step is safe because the type system catches reference
errors at the keystroke and the validator catches structural errors at compile
(paper §4.7, §7.2); every step is portable because the only place a vendor
name appears in flow source code is inside a namespaced `vendorHints` block.

The DSL is the canonical definition; the vendor artifacts are generated
outputs. That inversion is what turns vendor lock-in from a rewrite problem
into a recompile problem, and the implementation surface above is what makes
the inversion comfortable to live with day to day.
