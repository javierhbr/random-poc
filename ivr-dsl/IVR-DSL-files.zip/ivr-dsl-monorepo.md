# IVR DSL Monorepo

### Design for the SDK side — packages, tooling, dependencies, and consumer onboarding

---

## 1. What this monorepo is, and what it isn't

This document defines the **SDK-side monorepo**: the repository that produces
the npm packages a flow-author project (the `ivr-app/` of the implementation
approach doc) installs and imports. It is deliberately separate from a consumer
project — the SDK is *published*, the consumer is the *user*.

The split matters because the two repositories optimise for different things.
The consumer repo optimises for *one team's IVR application*: clear domain
modules, fast inner loop, deployable artifacts. The SDK monorepo optimises for
*many consumers and many vendors*: stable public APIs, surgical change
boundaries (so a Connect bug-fix doesn't force every consumer to retest
Omilia), independent versioning of vendor backends, and a plugin contract that
lets a third party add a new vendor without forking.

```
   SDK MONOREPO (this document)                CONSUMER REPO (other document)
   ──────────────────────────                  ─────────────────────────────
   publishes:                                  installs from npm:
     @ivr-dsl/core            ─────────►       npm i @ivr-dsl/preset
     @ivr-dsl/builder
     @ivr-dsl/validator                        authors:
     @ivr-dsl/backend-*                          src/flows/*.ts
     @ivr-dsl/cli                                src/registry/*.ts
     @ivr-dsl/testing                            ivr.config.ts
     @ivr-dsl/preset
                                                runs: ivr validate / test / compile / deploy
```

The SDK is what makes the workflow `validate → simulate → test → compile →
deploy` possible. Everything below is how that SDK is organised so it can be
built, tested, versioned, and shipped by a small core team while remaining
extensible by anyone who wants to add a vendor.

---

## 2. The package graph

The packages are organised in four tiers, each tier depending only on the ones
above it. This is the standard "no cycles, dependencies point one way" rule,
applied deliberately:

```
                              ┌─────────────────────┐
   tier 1                     │   @ivr-dsl/core     │  types + IR + contracts
   foundation                 │  (no deps)          │  the one thing everyone
                              └──────────┬──────────┘  imports from
                                         │
              ┌──────────────────────────┼──────────────────────────┐
              │                          │                          │
   tier 2     ▼                          ▼                          ▼
   SDK    ┌─────────────┐         ┌─────────────┐          ┌─────────────────┐
   layer  │  /builder   │         │ /validator  │          │     /nlu        │
          │  fluent API │         │ semantic    │          │ confidence      │
          │  + lowering │         │ checks      │          │ calibration     │
          └──────┬──────┘         └─────────────┘          └─────────────────┘
                 │
                 └──────────► (consumers import from these directly)
                                         │
                                         │
   tier 3                    ┌───────────┴────────────┐
   backends                  ▼                        ▼
   (substitutable     ┌─────────────────┐    ┌───────────────────┐
   under one          │ /backend-sdk    │    │ /backend-simulator│
   contract,          │ contract+helpers│◄───│ in-process runner │
   §5.3 of paper)     │ for plugins     │    └───────────────────┘
                      └────────┬────────┘
                               │ implements
                       ┌───────┴───────┬─────────────────┐
                       ▼               ▼                 ▼
                ┌─────────────┐ ┌──────────────┐ ┌──────────────┐
                │/backend-    │ │/backend-     │ │ (3rd-party   │
                │ connect     │ │ omilia       │ │  plugins)    │
                │ + Lex       │ │              │ │              │
                └─────────────┘ └──────────────┘ └──────────────┘

   tier 4         ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
   tooling        │   /cli       │   │  /testing    │   │   /preset    │
   & DX           │ the `ivr`    │   │ assertions + │   │ meta-package │
                  │ command      │   │ fixtures     │   │ for quick    │
                  │              │   │ + scenario   │   │ start        │
                  │              │   │ helpers      │   │              │
                  └──────────────┘   └──────────────┘   └──────────────┘
                         │
                         ▼
                  ┌──────────────────┐
                  │ create-ivr-app   │  scaffold a consumer repo
                  │ (separate pkg)   │  with one command
                  └──────────────────┘
```

Three properties this graph buys are worth naming:

**Backends are leaves.** Connect, Omilia, and any future vendor each live in a
package that nothing else in the monorepo imports from. A change to the Omilia
backend cannot affect Connect, the validator, the builder, or the core types
— it can only affect Omilia consumers. This is the paper's Dependency Inversion
property (§5.5) made concrete in package boundaries.

**`@ivr-dsl/core` is the contract.** Every other package depends on it, and
nothing in it depends on anything else. Its IR types are the contract every
backend consumes (paper §7) and its branded-id machinery is the type-safety
foundation (paper §4.7). It is the single highest-stakes package — its API
should change reluctantly.

**`@ivr-dsl/backend-sdk` is the plugin contract.** A third party writing a
new backend imports from `backend-sdk`, not from `core` directly. This lets the
core team evolve `core` while keeping the plugin surface stable through a
deliberate shim.

---

## 3. Each package: purpose, public API, dependencies

The list below walks each package in dependency order. For each one: what it
owns, what it depends on, and what its main exports are. "Owns" is meant in
the §5.1 SRP sense — one reason to change.

### 3.1 `@ivr-dsl/core` — types, IR, and the cross-package contract

**Owns.** Every type that crosses a package boundary. Branded id types
(`PromptId`, `StateId`, `IntentName`, `ApiName`, `OpName`, `RuleName`,
`FlowId`, `VarName`), the `State` discriminated union, the `Flow` object
shape, the `IR` and `IRNode` types (paper §7.1), `Metadata`, `InlineCode`,
`LogStatement`, `EligibilityRule`, `Prompt`, `ApiDependency`, `MockResponse`,
`Transition`, `RetryPolicy`, `TimeoutPolicy`, `ObservabilityEvent`, the
helper types for registry derivation (`Brand<T,B>`, `keyof`-based extractors).

**Depends on.** Nothing. This is by design — `core` must be loadable in any
environment (Node, browser, Deno, edge) and free of ambient assumptions.

**Public API.**

```typescript
// @ivr-dsl/core
export type {
  // Branded ids
  Brand, PromptId, StateId, IntentName, ApiName, OpName,
  RuleName, FlowId, VarName, Locale,

  // Author-facing model
  FlowContext, Prompt, IntentDef, EligibilityRule,
  ApiDependency, ApiOperation, MockResponse,
  Transition, RetryPolicy, TimeoutPolicy,
  ObservabilityEvent, LogStatement, LogLevel, LogCategory,
  Metadata, VendorTarget, InlineCode,

  // Runtime context — the platform-given parallel to FlowVars
  RuntimeContext,                   // the consumer-defined closed interface
                                    //   (declaration-merged from the
                                    //    consumer's project)
  RuntimeContextRegistry,           // the `satisfies` constraint
  RuntimeSource,                    // discriminated union of the 5 sources
  CallMetadataField,                // closed union of built-in fields
  RuntimeVarRef,                    // template literal `runtime.${keyof RuntimeContext}`
  AnyVarRef,                        // VarName | RuntimeVarRef

  // State union
  State, BaseState, CollectState, ApiCallState, DecisionState,
  TransferState, PlaybackState, SubflowState, TerminalState, SetVarState,

  // Flow + test scenarios
  Flow, TestScenario, TestStep,

  // The IR — the contract every backend consumes
  IR, IRNode, IRCollect, IRApiCall, IRDecision,
  IRTransfer, IRPlayback, IRSubflow, IRTerminal, IRSetVar, IRTransition,
  ResolvedRuntimeContext,           // runtime registry after lowering
};
```

No runtime exports — `core` is a `.d.ts`-only package as far as consumers are
concerned. Treating it as types-only is what keeps it tiny and load-anywhere.

### 3.2 `@ivr-dsl/builder` — the fluent authoring API + lowering to IR

**Owns.** The `defineFlow()` builder (paper §4.4), its state-id accumulation
machinery (paper §4.7), and the lowering pass that turns a built `Flow` into
an `IR` (paper §7.1 "front end" — resolving registry references, materialising
defaults, expanding flow-level inheritance).

**Depends on.** `@ivr-dsl/core`.

**Public API.**

```typescript
// @ivr-dsl/builder
import type { Flow, IR, FlowId, /* ... */ } from "@ivr-dsl/core";

export function defineFlow<Id extends FlowId>(id: Id): FlowBuilder<Id, never>;
export function lowerFlowToIR(flow: Flow, ctx: LoweringContext): IR;

// The builder's generic type is exported so consumers can write helpers
// that return partially-built flows (rare but useful).
export type FlowBuilder<Id extends FlowId, States extends StateId>;

// Registry typing helpers — consumers use these to derive id unions
// from their own `as const` registries.
export type PromptRegistry;
export type IntentRegistry;
export type DependencyRegistry;
```

The builder is where the most advanced TypeScript in the project lives — the
generic state-id accumulation is what makes `to: "main_menyu"` a compile error
at the call site (paper §4.7). This is the package most likely to need
TypeScript version bumps and the one whose error messages need the most love.

### 3.3 `@ivr-dsl/validator` — semantic validation of the IR

**Owns.** Every check from paper §7.2: reference integrity, reachability,
completeness, DTMF/intent conflicts, variable typing, inline-code compatibility,
metadata lint, and log-statement integrity — plus the four **runtime-context**
rules from the runtime-context addendum (R-RT-1 registry consistency, R-RT-2
reference resolution, R-RT-3 namespace separation between `FlowVars` and
`RuntimeContext`, R-RT-4 required-source completeness across test scenarios).
Each rule is one named function producing zero or more typed `Diagnostic`s;
the entry point composes them.

**Depends on.** `@ivr-dsl/core`.

**Public API.**

```typescript
// @ivr-dsl/validator
import type { IR } from "@ivr-dsl/core";

export interface Diagnostic {
  code: string;            // e.g. "IVR/E001" — dangling transition
                           //      "IVR/E020" — undeclared runtime.X reference
                           //      "IVR/E021" — FlowVars/RuntimeContext name collision
  severity: "error" | "warning";
  message: string;         // actionable, human-readable
  location: { flowId: string; nodeId?: string; field?: string };
  hint?: string;           // optional suggested fix
}

export function validate(ir: IR | IR[]): Diagnostic[];

// Rule-level exports for IDE integrations / custom pipelines
export const rules: {
  referenceIntegrity:        (ir: IR) => Diagnostic[];
  reachability:              (ir: IR) => Diagnostic[];
  completeness:              (ir: IR) => Diagnostic[];
  dtmfConflicts:             (ir: IR) => Diagnostic[];
  variableTyping:            (ir: IR) => Diagnostic[];
  inlineCodeCompat:          (ir: IR, targets: VendorTarget[]) => Diagnostic[];
  metadataLint:              (ir: IR) => Diagnostic[];
  logStatementIntegrity:     (ir: IR) => Diagnostic[];
  // Runtime context rules:
  runtimeRegistryConsistency:(ir: IR) => Diagnostic[];        // R-RT-1
  runtimeReferenceResolution:(ir: IR) => Diagnostic[];        // R-RT-2
  runtimeNamespaceSeparation:(ir: IR) => Diagnostic[];        // R-RT-3
  runtimeScenarioCompleteness:(ir: IR) => Diagnostic[];       // R-RT-4
};
```

Splitting rules out individually serves the §8.3 testing strategy: one focused
test per rule, in both passing and failing directions.

### 3.4 `@ivr-dsl/nlu` — NLU normalization and confidence calibration

**Owns.** The per-vendor confidence calibration metadata (paper §7.3) and the
canonical `NluResult` contract. Projects intent registries into per-engine
shapes (Lex bot model, Omilia NLU config) and normalises engine-native
confidence into the common contract.

**Depends on.** `@ivr-dsl/core`.

**Public API.**

```typescript
// @ivr-dsl/nlu
export interface NluResult {
  intent: IntentName;
  entities: Record<string, unknown>;
  confidence: number;       // calibrated, comparable across engines
  rawConfidence?: number;   // engine-native, kept for forensics
}

export interface CalibrationProfile {
  vendor: VendorTarget;
  curve: (raw: number) => number;
}

export function projectIntentsForLex(intents: IntentDef[]): LexBotModel;
export function projectIntentsForOmilia(intents: IntentDef[]): OmiliaNluConfig;
export function normaliseResult(
  raw: { intent: string; entities: object; confidence: number },
  profile: CalibrationProfile,
): NluResult;
```

This is the package that's honest about the paper's §1.1 limitation: the DSL
standardises the *contract*, not the engines. The calibration profiles live
here because they're empirical and need their own version history.

### 3.5 `@ivr-dsl/backend-sdk` — the plugin contract

**Owns.** The `Backend` interface every backend implements, plus shared
helpers no backend should reinvent: IR walkers, transition normalisers, KVP /
attribute projection helpers (the paper §4.5 metadata portability contract),
log-statement formatting, redaction enforcement, and the **runtime-context
source projection** (mapping each `RuntimeSource` kind onto the platform's
native attribute / header / config facility — see the runtime-context
addendum §7).

**Depends on.** `@ivr-dsl/core`.

**Public API.**

```typescript
// @ivr-dsl/backend-sdk
import type {
  IR, VendorTarget, Diagnostic, Metadata,
  ResolvedRuntimeContext, RuntimeSource,
} from "@ivr-dsl/core";

export interface Backend<TArtifact> {
  readonly target: VendorTarget;
  readonly version: string;

  /** Optional: declare what this backend doesn't support. */
  capabilities?: BackendCapabilities;

  /** Pre-flight: any backend-specific structural checks beyond the
   *  shared validator. Runs after the shared validator. */
  preflight?(ir: IR): Diagnostic[];

  /** Project the runtime-context registry onto the platform's native
   *  resolution surface (Connect contact attributes / Lambdas,
   *  Lex session attributes, Omilia KVPs, simulator stub values).
   *  Required: every backend declares how each RuntimeSource kind it
   *  receives is wired. Backends that can't host a particular source
   *  emit a diagnostic from `preflight`. */
  resolveRuntimeContext(
    resolved: ResolvedRuntimeContext,
  ): RuntimeWiring;

  /** The single function that produces the artifact. Pure: same IR in,
   *  same artifact out. */
  compile(ir: IR, ctx: BackendContext): Promise<TArtifact>;

  /** Optional: deploy the artifact. Only this method is allowed to do
   *  network/IO. */
  deploy?(artifact: TArtifact, env: DeployEnv): Promise<DeployResult>;
}

export interface BackendContext {
  config: ProjectConfig;        // ivr.config.ts resolved
  logger: BackendLogger;
}

/** Per-platform wiring produced by resolveRuntimeContext. Each entry tells
 *  the compiled artifact HOW to fetch the value at call time. */
export interface RuntimeWiring {
  readonly entries: Array<{
    name:    string;            // matches keyof RuntimeContext
    source:  RuntimeSource;
    nativeBinding: unknown;     // platform-specific (e.g. CloudFormation
                                //   reference, Omilia KVP path, Lex
                                //   session attribute name)
  }>;
}

// Helpers every backend uses
export function walkIR(ir: IR, visitor: IRVisitor): void;
export function projectMetadata(meta: Metadata, target: VendorTarget): KvpMap;
export function projectLogStatement(/* ... */): VendorLogSpec;
export function applyRedaction(value: unknown, redact: VarName[]): unknown;
export function projectRuntimeSource(
  source: RuntimeSource,
  target: VendorTarget,
): NativeBinding;               // shared helper for the per-source mapping
```

The `Backend<TArtifact>` interface is the Liskov-substitutable contract from
paper §5.3. Because every backend honours it, the CLI's compile step is one
generic call against `Backend.compile`, with no per-vendor branching.

### 3.6 `@ivr-dsl/backend-simulator` — in-process runner

**Owns.** The simulator backend of paper §7.4: walks the IR, feeds scenario
inputs, serves mocks, runs `InlineCode` snippets in a sandboxed JS context,
captures logs and metadata into buffers, asserts on expected state sequence
/ outcome / log narrative.

**Depends on.** `@ivr-dsl/core`, `@ivr-dsl/backend-sdk`.

**Public API.**

```typescript
// @ivr-dsl/backend-simulator
export const simulatorBackend: Backend<SimulatorRun>;

export interface SimulatorRun {
  states: StateId[];
  logs: CapturedLog[];
  metadata: CapturedMetadata[];
  vars: Partial<FlowVars>;
  runtime: RuntimeContext;       // values used during this run (from the
                                 //   scenario's runtimeContext field)
  outcome: { kind: "terminal" | "transfer"; id: string };
}

export interface SimulatorOptions {
  breakpoints?: StateId[];       // pause execution at these states
  inputs: SimulatorInput[];      // scripted inputs
  mocks: MockBindings;           // dependency -> mockLabel
  runtimeContext: RuntimeContext;// scenario-supplied platform values
}

export function runScenario(ir: IR, options: SimulatorOptions): Promise<SimulatorRun>;
```

The simulator is special because it's both a `Backend` (for the substitutable
compile interface) and a runtime engine (for `ivr simulate` and `ivr test`).
Both faces are exported. Its `resolveRuntimeContext` reads directly from the
scenario's `runtimeContext` field — every source kind degenerates to a
straight value lookup, so the simulator stays vendor-free.

### 3.7 `@ivr-dsl/backend-connect` — AWS Connect + Lex

**Owns.** Connect contact-flow JSON emission, Lex bot model emission, Lambda
manifest generation for `apiCall` states, the deploy implementation (Connect
import API, Lex publish, Lambda packaging), and the **runtime-context wiring
for Connect**: `callMetadata` resolves to contact-attribute lookups,
`sipHeader` to Connect's SIP attribute bag, `environment` to Lambda env vars,
`configApi` to a Lambda invocation at flow entry with results cached as
contact attributes for the remainder of the call.

**Depends on.** `@ivr-dsl/core`, `@ivr-dsl/backend-sdk`, `@ivr-dsl/nlu`.

**Public API.**

```typescript
// @ivr-dsl/backend-connect
export const connectBackend: Backend<ConnectArtifact>;

export interface ConnectArtifact {
  contactFlows: Record<FlowId, ConnectContactFlowJson>;
  lexBot: LexBotModel;
  lambdas: LambdaManifest;
}

// IaC integration — emit Terraform / CloudFormation
export function toTerraform(artifact: ConnectArtifact): TerraformModule;
export function toCloudFormation(artifact: ConnectArtifact): CloudFormationTemplate;
```

Schema-validation against Amazon's published Connect contact-flow and Lex
import schemas runs in `preflight`. The deploy method is optional and only
imported when the consumer actually wants to deploy — separating it keeps the
package usable in environments without AWS credentials.

### 3.8 `@ivr-dsl/backend-omilia` — Omilia (generation or interpreter)

**Owns.** Both Omilia strategies from paper §7.4: compile-time flow emission
and runtime interpreter config. Which one runs is decided by
`ivr.config.ts`, not at package level — the package supports both because the
strategy decision (paper §10.4) is a project decision. Also owns the
**runtime-context wiring for Omilia**: `callMetadata` resolves to Omilia's
call-context KVPs, `sipHeader` to its SIP context bag, `environment` to
process env or Omilia's secrets binding, `incoming` to the trigger payload,
`configApi` to Omilia's pre-flow REST hook.

**Depends on.** `@ivr-dsl/core`, `@ivr-dsl/backend-sdk`, `@ivr-dsl/nlu`.

**Public API.**

```typescript
// @ivr-dsl/backend-omilia
export const omiliaBackend: Backend<OmiliaArtifact>;

export type OmiliaArtifact =
  | { mode: "generation";   flows: OmiliaFlowJson[]; nluConfig: OmiliaNluConfig }
  | { mode: "interpreter";  config: InterpreterConfig; nluConfig: OmiliaNluConfig };

// If `mode: "interpreter"`, the interpreter is a separate runtime package the
// consumer deploys; this backend just produces its config.
```

The interpreter runtime is published as its own package
(`@ivr-dsl/omilia-interpreter`) because it's a service, not a build artifact.
That separation keeps the build-time backend free of runtime concerns.

### 3.9 `@ivr-dsl/cli` — the `ivr` command

**Owns.** The CLI surface from the implementation-approach doc:
`ivr validate`, `ivr simulate`, `ivr test`, `ivr compile`, `ivr deploy`,
`ivr diff`, `ivr graph`, `ivr docs`. Each subcommand is a thin wrapper that
loads the consumer's flows, invokes the relevant package(s), and formats
output.

**Depends on.** Every other package — it's the conductor.

**Public API.** The `ivr` binary is the primary surface. Programmatic exports
let CI scripts or IDE plugins reuse the same logic:

```typescript
// @ivr-dsl/cli
export async function validateProject(cwd: string): Promise<Diagnostic[]>;
export async function compileProject(cwd: string, opts: CompileOptions): Promise<void>;
export async function testProject(cwd: string, opts: TestOptions): Promise<TestReport>;
// etc.
```

The CLI also defines the consumer's `ivr.config.ts` schema and the project
discovery rules (scan `src/flows/**/*.ts`, look up registries by convention,
resolve env-specific config). That logic lives here because it's a CLI concern,
not a `core` concern.

### 3.10 `@ivr-dsl/testing` — test helpers for flow authors

**Owns.** Assertion helpers, scenario fixtures, mock factories, and test-runner
integrations (Jest matchers, Vitest matchers) flow authors use to extend
beyond the declarative `testScenario`s. Different from `core` because these are
*runtime* helpers, not types.

**Depends on.** `@ivr-dsl/core`, `@ivr-dsl/backend-simulator`.

**Public API.**

```typescript
// @ivr-dsl/testing
export function expectScenario(flow: Flow): ScenarioAssertion;
export function mockDependency(name: ApiName, responses: MockResponse[]): MockHandle;
export function captureLogsDuring(fn: () => Promise<void>): Promise<CapturedLog[]>;

// Custom matchers
export const ivrMatchers: {
  toReachState: (this: MatcherContext, expected: StateId) => MatcherResult;
  toEmitLog:    (this: MatcherContext, code: string, level?: LogLevel) => MatcherResult;
  toTransferTo: (this: MatcherContext, queue: string) => MatcherResult;
};

// Importable directly into a test setup file
import "@ivr-dsl/testing/jest-matchers";
import "@ivr-dsl/testing/vitest-matchers";
```

### 3.11 `@ivr-dsl/preset` — the one-import getting-started bundle

**Owns.** Nothing — it's a meta-package that re-exports the common bundle so a
consumer can write one `import` line and get going.

**Depends on.** `core`, `builder`, `validator`, `backend-simulator`,
`testing`.

**Public API.**

```typescript
// @ivr-dsl/preset
export * from "@ivr-dsl/core";
export { defineFlow, lowerFlowToIR } from "@ivr-dsl/builder";
export { validate, type Diagnostic } from "@ivr-dsl/validator";
export { simulatorBackend, runScenario } from "@ivr-dsl/backend-simulator";
export { expectScenario, mockDependency } from "@ivr-dsl/testing";
```

Vendor backends are *not* in the preset — they're installed on demand because
they pull in heavy SDK dependencies (AWS SDK for Connect, Omilia SDK for
Omilia). A consumer wanting Connect runs `npm i @ivr-dsl/backend-connect`
explicitly. The preset is for the "I just want to write a flow and run it
locally" first day.

### 3.12 `create-ivr-app` — scaffolder

**Owns.** A scaffolding command that drops a consumer repo on disk, fully
configured: `package.json` with the right pinned versions, `tsconfig.json`,
`ivr.config.ts`, the directory structure from the implementation-approach
doc (§2), and a starter flow that validates and tests green out of the box.

**Depends on.** Nothing in this monorepo at runtime — it's published as a
standalone package consumed via `npm create ivr-app@latest my-ivr`.

This package lives in the same monorepo as the SDK because its templates need
to track SDK versions exactly. When `core` ships a breaking change,
`create-ivr-app`'s template moves in the same release.

---

## 4. Tooling stack

A few opinionated choices, each justified briefly:

**Package manager — pnpm.** Workspaces, content-addressable store, strict
peer-dependency resolution (which catches the "your backend silently imports
a wrong `core` version" class of bug). pnpm's strictness is what makes a
many-package monorepo feel like a single project rather than a swamp.

**Task runner — Turborepo.** Caches build/test outputs by content hash, runs
tasks across packages in topological order, parallelises freely. Critical for
CI speed: a change to `backend-omilia` should not rebuild Connect's tests.
The alternative is Nx; either works, but Turborepo is the simpler default and
the published-package ecosystem has slightly less Nx-specific glue to
maintain.

**Versioning — Changesets.** Each PR that changes a published package
includes a markdown changeset describing the change and its semver impact.
A release CI job consumes accumulated changesets, bumps versions, generates a
changelog, and publishes. The discipline is light, the audit trail is clean,
and it works whether packages version in lockstep or independently (see §6).

**Build — tsup (or `tsc --build`).** Each package produces both ESM and CJS
output and emits `.d.ts` files. tsup is faster than raw `tsc` for builds but
both are acceptable; `tsc --build` with TypeScript project references is the
fallback if a package needs more sophisticated emit control.

**Test — Vitest.** Fast, ESM-native, Jest-compatible API. The same matchers
work in the SDK's own tests (paper §8) and in the consumer's tests (via
`@ivr-dsl/testing`). The CLI also bundles a Vitest config preset.

**Linting and formatting — ESLint + Prettier.** Standard. One config at the
root, inherited by every package.

**TypeScript — project references.** Each package has its own `tsconfig.json`
extending a root `tsconfig.base.json`, with `references` pointing at its
dependencies. This is what makes `tsc --build` incremental and what lets each
package import its dependency's types directly from source during development
(no "build the dep, then build me").

---

## 5. Repository layout

The whole monorepo, at the file level:

```
ivr-dsl/                            ← the repo
├── package.json                    ← workspace root, no deps of its own
├── pnpm-workspace.yaml             ← lists packages/*  and  examples/*
├── turbo.json                      ← task pipelines (build, test, lint)
├── tsconfig.base.json              ← strict mode, ESNext, etc.
├── .changeset/                     ← pending version changesets
├── .github/workflows/
│   ├── ci.yml                      ← validate + test + build on PR
│   └── release.yml                 ← changesets → publish on main
│
├── packages/
│   ├── core/
│   │   ├── package.json            ← name: "@ivr-dsl/core"
│   │   ├── tsconfig.json           ← extends base, no `references`
│   │   ├── src/
│   │   │   ├── index.ts
│   │   │   ├── ids.ts              ← branded id types
│   │   │   ├── state.ts            ← State discriminated union
│   │   │   ├── flow.ts             ← Flow shape
│   │   │   ├── ir.ts               ← IR node types
│   │   │   ├── metadata.ts         ← Metadata, InlineCode
│   │   │   └── logging.ts          ← LogStatement, LogLevel
│   │   └── test/
│   │       └── types.test-d.ts     ← type-level tests (tsd / expect-type)
│   │
│   ├── builder/
│   │   ├── package.json            ← deps: { "@ivr-dsl/core": "workspace:*" }
│   │   ├── tsconfig.json           ← references: [{ path: "../core" }]
│   │   ├── src/
│   │   │   ├── index.ts
│   │   │   ├── define-flow.ts      ← the fluent builder
│   │   │   ├── builder-types.ts    ← generic state-id accumulation
│   │   │   └── lowering.ts         ← Flow → IR
│   │   └── test/
│   │       ├── builder.test.ts
│   │       └── lowering.test.ts
│   │
│   ├── validator/                  ← (same shape)
│   ├── nlu/
│   ├── backend-sdk/
│   ├── backend-simulator/
│   ├── backend-connect/
│   ├── backend-omilia/
│   ├── omilia-interpreter/         ← runtime service for Omilia interpreter mode
│   ├── cli/
│   ├── testing/
│   ├── preset/
│   └── create-ivr-app/
│       ├── package.json            ← bin: { "create-ivr-app": "./bin.js" }
│       └── templates/
│           └── default/            ← the consumer repo template
│
├── examples/
│   ├── card-services-app/          ← a full, working consumer repo
│   │                                 used in docs and integration tests
│   └── minimal-app/                ← the smallest viable example
│
├── docs/                           ← docusaurus / next site, or markdown only
│   ├── getting-started.md
│   ├── concepts/
│   ├── api/                        ← auto-generated from .d.ts
│   └── plugin-authoring.md
│
└── e2e/                            ← end-to-end SDK tests (paper §8.6)
    ├── connect.e2e.ts              ← deploys to real Connect, places test calls
    └── omilia.e2e.ts               ← scheduled, not on every PR
```

Two layout choices to call out:

**`examples/` is inside the monorepo, not a separate repo.** Each example is a
real consumer-shape project that imports the workspace packages via
`workspace:*`. It serves three purposes at once — docs that can't go stale,
integration tests that exercise the packages end-to-end, and the source of
truth for `create-ivr-app`'s templates. When the SDK's API changes, the
examples either still compile (good) or they don't (and the breakage shows up
in the same PR).

**`e2e/` is the §8.6 honesty boundary.** End-to-end tests need real vendor
credentials, are slower, and are flakier — so they live in their own
directory with their own CI workflow (scheduled, not per-PR). The pure-function
layers (§8.2–§8.5) all live inside `packages/*/test/`.

---

## 6. Build, test, and release pipelines

### 6.1 Local development

After cloning:

```bash
pnpm install              # one install for the whole workspace
pnpm build                # turbo runs every package's build in topo order
pnpm test                 # turbo runs every test suite in parallel
pnpm lint
```

For day-to-day work on one package:

```bash
pnpm --filter @ivr-dsl/validator test       # only that package's tests
pnpm --filter @ivr-dsl/validator test --watch
```

Editing a package's source is *instantly* visible to dependents because pnpm
workspaces symlink and TypeScript project references resolve to source. No
"rebuild the validator before the CLI sees the change."

### 6.2 CI on pull request

```yaml
# .github/workflows/ci.yml — illustrative
jobs:
  ci:
    steps:
      - uses: pnpm/action-setup@v2
      - run: pnpm install --frozen-lockfile
      - run: pnpm turbo run build test lint type-check
      - run: pnpm changeset status                 # PR must include a changeset
                                                   # if it touches a published pkg
      - uses: examples-integration                 # ensure examples still build
```

Turbo's cache (local + remote, e.g. Vercel's cache or a custom one) means a
PR touching one package only re-runs *its* tasks plus dependents — a Connect
change does not re-test Omilia.

### 6.3 Release

```yaml
# .github/workflows/release.yml — runs on push to main
jobs:
  release:
    steps:
      - run: pnpm install --frozen-lockfile
      - run: pnpm build
      - uses: changesets/action@v1
        with:
          publish: pnpm changeset publish        # bumps versions, tags, npm publish
          createGithubReleases: true
```

Changesets accumulates per-PR markdown files describing changes; the release
job consumes them, applies version bumps according to declared semver impact,
writes a unified `CHANGELOG.md` per package, tags the release, and runs
`npm publish` per changed package. Provenance attestations (`--provenance`)
are on by default for npm supply-chain hygiene.

---

## 7. Versioning strategy

A real decision, with trade-offs in both directions:

**Lockstep versioning** (every package shares one version number) — simpler
mental model, simpler bug reports, but a Connect-only fix bumps everyone and
forces consumers of Omilia to re-deploy for nothing.

**Independent versioning** — packages move at their own pace. More honest, but
"which combination of versions actually works together" becomes a real
question, and consumers feel it.

The recommended middle path:

- **Core stack in lockstep.** `core`, `builder`, `validator`, `backend-sdk`,
  `backend-simulator`, `cli`, `testing`, and `preset` move as one version.
  These packages have tight coupling — `validator`'s diagnostics encode IR
  shape from `core`, `builder` emits IR `validator` consumes — and pretending
  they evolve independently invites version-skew bugs.
- **Vendor backends independent.** `backend-connect`, `backend-omilia`,
  `omilia-interpreter`, and any third-party backend version on their own.
  They each declare a peer-dependency range on the core stack (e.g.
  `"@ivr-dsl/core": "^1.4.0"`), so a consumer's installer can detect a
  mismatch.
- **0.x while the IR is stabilising.** Until at least one consumer has shipped
  to production on two vendors, every package stays on `0.x` so semver
  conventionally permits breaking changes per minor bump. Move to `1.0`
  deliberately, after the IR has had its predicted round of revision (paper
  §10.3 ends with this exact warning).

`create-ivr-app` pins its template to a specific lockstep version, which is
the single most consumer-visible commitment the SDK makes. Bumping that pin is
a release event.

---

## 8. The consumer onboarding experience

What a developer does, from zero to running flow:

```bash
$ npm create ivr-app@latest my-bank-ivr
✔ Project name: my-bank-ivr
✔ Vendors to enable: › Connect, Lex, Simulator
✔ Install dependencies? › Yes
✔ Initialize git? › Yes

  Done in 14s.

  Next steps:
    cd my-bank-ivr
    npx ivr simulate main          # walk the starter flow interactively
    npx ivr test                   # run the included scenario
```

The scaffolded `my-bank-ivr/` is the consumer repo from the implementation-
approach doc — full directory structure, registries pre-populated with a tiny
sample, one working flow (`main.ts`), one test scenario, and an
`ivr.config.ts` configured with the vendors the user picked.

`my-bank-ivr/package.json` looks like:

```json
{
  "name": "my-bank-ivr",
  "private": true,
  "scripts": {
    "validate": "ivr validate",
    "test":     "ivr test",
    "build":    "ivr compile --target=connect && ivr compile --target=lex",
    "deploy":   "ivr deploy --target=connect --env=$ENV"
  },
  "dependencies": {
    "@ivr-dsl/preset": "^1.4.0"
  },
  "devDependencies": {
    "@ivr-dsl/cli": "^1.4.0",
    "@ivr-dsl/backend-connect": "^2.1.0",
    "@ivr-dsl/testing": "^1.4.0",
    "typescript": "^5.4.0",
    "vitest": "^1.0.0"
  }
}
```

One bundle install, no per-package juggling. From here the consumer follows
the day-in-the-life loop of the implementation-approach doc.

---

## 9. Plugin authoring — adding a vendor backend

The Open/Closed property the paper promises (§5.2) only holds if someone
outside the core team can actually add a backend without forking. The plugin
contract lives in `@ivr-dsl/backend-sdk`. A new backend is a separate
package — say `@acme/ivr-backend-genesys` — that:

1. Implements `Backend<TArtifact>` from `@ivr-dsl/backend-sdk`.
2. Declares a peer-dependency range on `@ivr-dsl/core` and `backend-sdk`.
3. Adds its `VendorTarget` literal via TypeScript module augmentation:

```typescript
// @acme/ivr-backend-genesys/src/augment.ts
declare module "@ivr-dsl/core" {
  interface VendorTargetMap {
    genesys: true;
  }
}
```

The core `VendorTarget` type is defined as `keyof VendorTargetMap` so this
augmentation is the one supported extension point — no patching, no fork.

4. Registers in the consumer's `ivr.config.ts`:

```typescript
import { genesysBackend } from "@acme/ivr-backend-genesys";

export default {
  vendors: ["connect", "simulator", "genesys"],
  backends: { genesys: genesysBackend },
  // ...
};
```

5. Inherits, for free, the SDK's shared backend contract test suite (paper
   §8.4): a test harness exported from `@ivr-dsl/backend-sdk/testing` runs the
   standard battery of IRs through any backend, asserting it doesn't crash on
   valid input, doesn't silently drop a state, and handles `InlineCode` per
   the project policy. Plugin authors run it against their backend.

The plugin contract is intentionally narrow — one interface, four methods
(`preflight`, `compile`, optional `deploy`, optional `capabilities`). Adding a
backend is a real engineering project, but it's a *finite* one with a clear
contract to satisfy.

---

## 10. Appendix — key config files

The configs that wire the monorepo together, in case it helps to see them
concretely.

**`package.json` (workspace root):**

```json
{
  "name": "ivr-dsl",
  "private": true,
  "scripts": {
    "build":      "turbo run build",
    "test":       "turbo run test",
    "lint":       "turbo run lint",
    "type-check": "turbo run type-check",
    "changeset":  "changeset",
    "release":    "pnpm build && changeset publish"
  },
  "devDependencies": {
    "@changesets/cli": "^2.27.0",
    "turbo": "^1.13.0",
    "typescript": "^5.4.0",
    "vitest": "^1.0.0",
    "eslint": "^8.0.0",
    "prettier": "^3.0.0"
  },
  "packageManager": "pnpm@9.0.0"
}
```

**`pnpm-workspace.yaml`:**

```yaml
packages:
  - "packages/*"
  - "examples/*"
```

**`turbo.json`:**

```json
{
  "$schema": "https://turbo.build/schema.json",
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**"]
    },
    "test": {
      "dependsOn": ["build"]
    },
    "lint":       {},
    "type-check": { "dependsOn": ["^build"] }
  }
}
```

**`tsconfig.base.json`:**

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "composite": true,
    "incremental": true,
    "skipLibCheck": true,
    "isolatedModules": true
  }
}
```

**A representative package `package.json` (`packages/validator/package.json`):**

```json
{
  "name": "@ivr-dsl/validator",
  "version": "0.1.0",
  "type": "module",
  "main": "./dist/index.cjs",
  "module": "./dist/index.js",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": {
      "types": "./dist/index.d.ts",
      "import": "./dist/index.js",
      "require": "./dist/index.cjs"
    }
  },
  "scripts": {
    "build":      "tsup src/index.ts --format esm,cjs --dts",
    "test":       "vitest run",
    "type-check": "tsc --noEmit"
  },
  "peerDependencies": {
    "@ivr-dsl/core": "workspace:*"
  },
  "devDependencies": {
    "@ivr-dsl/core": "workspace:*",
    "tsup": "^8.0.0"
  }
}
```

`peerDependencies` on `@ivr-dsl/core` (not `dependencies`) is deliberate —
this guarantees one copy of `core` in the consumer's `node_modules`, which is
what prevents the "two `IR` types that look identical but aren't assignable"
class of bug.

---

## 11. Summary

The monorepo is four tiers — foundation (`core`), SDK (`builder`,
`validator`, `nlu`), backends (`backend-sdk` + `backend-simulator` + per-vendor
plugins), and tooling (`cli`, `testing`, `preset`, `create-ivr-app`) — with
dependencies pointing only inward. `core` defines the IR every other package
agrees on — including the `RuntimeContext` parallel surface, its registry
type, and the closed `RuntimeSource` union; `backend-sdk` defines the contract
every backend implements, with `resolveRuntimeContext` as a required method
that wires each source kind onto the platform's native attribute / header /
config facility; `preset` and `create-ivr-app` give a consumer a one-command
on-ramp.

The tooling stack — pnpm + Turborepo + Changesets + tsup + Vitest + TypeScript
project references — is the current best-in-class for a TypeScript monorepo of
this shape, but none of the architecture depends on those specific choices:
each is replaceable with an equivalent without redesigning the package graph.

Versioning is lockstep for the tightly coupled core stack and independent for
vendor backends, which matches how the packages actually evolve: the core
stack moves as a unit because its parts know each other intimately, the vendor
backends move on their own because each one tracks an external vendor's API.
`0.x` until at least one consumer has shipped to production on two vendors —
the IR will get one round of revision (paper §10.3 promises this), and the
monorepo's job is to absorb that revision cleanly when it comes.

A consumer's experience is `npm create ivr-app@latest`, one `pnpm install`,
and the workflow from the implementation-approach doc runs end-to-end on their
machine. A plugin author's experience is one `Backend<TArtifact>` interface
to implement and one shared test suite to satisfy. The DSL stays the DSL;
this monorepo is just the disciplined way to publish it.
