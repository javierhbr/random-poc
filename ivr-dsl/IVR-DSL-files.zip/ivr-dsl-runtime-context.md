# Runtime Context — Design Addendum

### Extends *Designing a Vendor-Agnostic IVR DSL in TypeScript* with the
### execution-context surface

---

## 1. The gap

The paper's `FlowVars` cleanly models the data a flow *earns* from a
conversation — what the caller said, what the APIs returned, what was decided.
What it does not model is the data a flow *starts with* — caller phone
number, dialed number, SIP headers, tenant identifier, market, feature
flags, customer preferences fetched before the first prompt plays. Vendors
expose this differently (Connect contact attributes, Lex session attributes,
Omilia KVPs and trigger context, SIP variables) and authors today either
treat each platform's surface as a special case or smuggle these values into
`FlowVars` as if they were conversation data. Both lose.

Calling these "execution context" — and giving them a parallel, typed surface
to `FlowVars` — gets the model right and keeps the rest of the paper intact.

## 2. The model

`FlowContext` grows from one bag to two:

```typescript
export interface FlowContext {
  vars:    FlowVars;          // conversation-driven, mutable
  runtime: RuntimeContext;    // platform-driven, read-mostly
}
```

Both are closed interfaces with no index signature, both follow the §4.7
"strict by construction" rules, and both project a `keyof` literal-union
name type that flows reference. `VarName = keyof FlowVars` stays as it
was. `RuntimeVarName = keyof RuntimeContext` joins it.

Why a separate interface rather than a tag on `FlowVars`:

- **Lifecycle differs.** `FlowVars` is session-scoped and mutated by the
  conversation. `RuntimeContext` is call-scoped, resolved at call start or
  lazily on first access, and read-mostly.
- **Sources differ.** `FlowVars` get filled by `apiCall.saveAs` and
  `collect`'s entity extraction. `RuntimeContext` gets filled by the
  platform — through declarations, not state transitions.
- **Vendor projection differs.** Each backend wires the two surfaces
  through completely different native facilities (§5 below).
- **Authoring intent differs.** A flow that reads `vars.customerId` is
  consuming earned data; a flow that reads `runtime.tenantId` is consuming
  configured data. Naming the two distinctly preserves the distinction.

## 3. The registry

Like every other DSL registry, the runtime-context registry is frozen `as
const` so its keys derive the id type and its source declarations are
introspectable at compile time:

```typescript
// src/registry/runtime-context.ts
export const runtimeContext = {
  ani:                  { source: "callMetadata", field: "ani", required: true },
  dnis:                 { source: "callMetadata", field: "dnis", required: true },
  channel:              { source: "callMetadata", field: "channel", default: "voice" },
  sipCallId:            { source: "sipHeader", header: "Call-ID" },
  tenantId:             { source: "environment", envVar: "TENANT_ID", required: true },
  entryPoint:           { source: "callMetadata", field: "entryPoint", required: true },
  market:               { source: "configApi", dependency: "configApi",
                          operation: "getMarketForDnis",
                          cacheTtl: "1h",
                          fallback: { value: "US" } },
  preferredLanguage:    { source: "configApi", dependency: "configApi",
                          operation: "getCustomerPreferences",
                          cacheTtl: "5m" },                  // optional, no fallback
  featurePremiumQueue:  { source: "environment", envVar: "FEATURE_PREMIUM_QUEUE",
                          default: false },
} as const satisfies RuntimeContextRegistry<RuntimeContext>;
```

The `satisfies RuntimeContextRegistry<RuntimeContext>` constraint is what
enforces alignment between the interface (§2) and the registry: every key
in `RuntimeContext` must appear in the registry, every registry entry's
source type must produce the declared interface type, and a missing or
mis-typed entry is a `tsc` error before the IR is ever built.

## 4. The source taxonomy

Five sources, chosen because they cover every vendor cleanly and no two
overlap in meaning:

```typescript
type RuntimeSource =
  | { source: "callMetadata"; field: CallMetadataField; default?: unknown }
  | { source: "sipHeader";    header: string;          default?: unknown }
  | { source: "environment";  envVar: string;
                              required?: boolean;       default?: unknown }
  | { source: "incoming";     name: string;
                              required?: boolean;       default?: unknown }
  | { source: "configApi";    dependency: ApiName;
                              operation: OpName;
                              cacheTtl?: string;
                              fallback?: { value: unknown }
                                       | { transition: StateId } };

type CallMetadataField =
  | "ani" | "dnis" | "channel" | "callId" | "direction"
  | "startTime" | "entryPoint";
```

- **`callMetadata`** — built-ins every voice platform exposes. The closed
  `CallMetadataField` union is what makes this portable: the DSL guarantees
  these fields, and every adapter is responsible for resolving them.

- **`sipHeader`** — a named SIP header (e.g. `X-Custom-Routing`, `Call-ID`).
  Adapter is responsible for header capture; the field is the raw string
  value with a `default` if absent.

- **`environment`** — a value from the runtime environment of the IVR
  process (env var, secret store binding). `required: true` is a compile
  error if not provided at deploy time; `default` keeps the build green.

- **`incoming`** — a value passed *into* the IVR when it's invoked (e.g.
  from a parent application, a queued callback record, a chatbot handoff).
  Distinct from `callMetadata` because it's an explicit hand-off contract,
  not platform-provided.

- **`configApi`** — fetched from a declared API dependency. Eager by default,
  cached for `cacheTtl`. `fallback` declares what happens when the call
  fails or times out: either return a static value (degrade gracefully) or
  transition the flow to a recovery state (e.g. "if we can't determine the
  market, transfer to general queue immediately").

The single shared property — `default` or `fallback` — is the contract
that lets the validator require every runtime entry to have a defined
behaviour when its source fails. No runtime entry is ever silently empty.

## 5. References from flow code

Two equivalent ways to reach runtime context, both fully typed:

**In TypeScript (rules, inline code):**

```typescript
export const isUsMarket: EligibilityRule = {
  name: "isUsMarket" as RuleName,
  describe: "Caller's market is US",
  evaluate: (ctx) => ctx.runtime.market === "US",     // typed access
};
```

**In strings (prompts, logs, transfer payloads):** prefix with `runtime.`

```typescript
{ category: "stateEntry", level: "info",
  code: "main.welcome",
  message: "Call from {runtime.ani} dialing {runtime.dnis} for tenant {runtime.tenantId}",
  includeVars: ["runtime.ani", "runtime.dnis", "runtime.tenantId"] }
```

The convention is symmetric: bare `{balance}` is `FlowVars`; prefixed
`{runtime.market}` is `RuntimeContext`. The validator enforces both
namespaces have **no overlapping names** (one identifier, one home), so
references are always unambiguous.

`contextPayload` on transfers accepts the same form:

```typescript
.transfer("to_agent", {
  destination: queues.generalBanking,
  contextPayload: [
    "customerId", "authenticated",          // FlowVars
    "runtime.ani", "runtime.dnis",          // RuntimeContext
    "runtime.tenantId", "runtime.market",
  ],
  // ...
})
```

## 6. `apiCall` enrichment from runtime context

The paper's `apiCall` state gains a `headers` field — explicit, typed
runtime-context injection into outbound requests, with no hidden globals
and no per-call boilerplate:

```typescript
.apiCall("balance_lookup", {
  dependency: "accountApi",
  operation:  "getBalance",
  saveAs:     "balance",
  headers: {
    "x-tenant-id": "runtime.tenantId",
    "x-call-id":   "runtime.sipCallId",
    "x-market":    "runtime.market",
  },
  onSuccess: "play_balance",
  onError:   "to_agent",
  onTimeout: "to_agent",
})
```

The right-hand side of each header value is a typed reference — `runtime.X`
(checked against `RuntimeContext`) or bare `X` (checked against `FlowVars`).
The validator rejects a header value that doesn't resolve.

A complementary `requestEnrichment` field handles request-body injection
for backends that prefer body fields to headers; it accepts the same
reference shape.

## 7. Vendor projection — the portability contract

Each backend implements one mapping per `RuntimeSource` kind, declared up
front (so the consumer knows what each platform actually does):

```
   DSL RuntimeContext registry
              ↓
       Provider adapter
              ↓
   ┌──────────────────────────────────────────────────────────────────┐
   │  Connect:                                                         │
   │    callMetadata     → contact-attribute lookup from the contact   │
   │    sipHeader        → Connect's SIP attribute bag                 │
   │    environment      → Lambda environment variables                │
   │    incoming         → contact attribute set by parent contact-flow│
   │    configApi        → Lambda invocation at flow entry, cached     │
   │                       in contact attributes per call              │
   ├──────────────────────────────────────────────────────────────────┤
   │  Lex:                                                             │
   │    callMetadata     → session attributes set by upstream Connect  │
   │    sipHeader        → session attributes set by upstream Connect  │
   │    environment      → Lambda environment                          │
   │    incoming         → session attributes set by the invoker       │
   │    configApi        → Lambda fulfilment hook at session start     │
   ├──────────────────────────────────────────────────────────────────┤
   │  Omilia:                                                          │
   │    callMetadata     → Omilia's call-context KVPs                  │
   │    sipHeader        → Omilia's SIP context bag                    │
   │    environment      → process env or Omilia secrets binding       │
   │    incoming         → trigger payload                             │
   │    configApi        → Omilia's pre-flow REST hook                 │
   ├──────────────────────────────────────────────────────────────────┤
   │  Simulator:                                                       │
   │    every source     → values from the testScenario's              │
   │                       `runtimeContext` field                      │
   └──────────────────────────────────────────────────────────────────┘
```

Each adapter projects portable values into the platform's native attribute
facility under a fixed `runtime.*` prefix, matching the `Metadata`
portability contract (paper §4.5). A flow that uses `runtime.tenantId`
shows up as `runtime.tenantId` in Connect contact attributes, as a
`runtime.tenantId` KVP in Omilia, and as a `runtime.tenantId` session
attribute in Lex.

## 8. Test scenarios

`testScenario` gains a `runtimeContext` field that supplies values the
platform would normally resolve. The simulator backend (paper §7.4) reads
from it; vendor test artifacts emit it into the platform's test-scenario
format:

```typescript
.testScenario({
  name: "US-market caller with known preferences",
  startState: "welcome",
  runtimeContext: {
    ani:               "+15551234567",
    dnis:              "+18005550100",
    channel:           "voice",
    sipCallId:         "abc-123-def",
    tenantId:          "firsttrust",
    entryPoint:        "main",
    market:            "US",
    preferredLanguage: "en-US",
    featurePremiumQueue: false,
  },
  steps: [/* ... */],
  // ...
})
```

`runtimeContext` is required if the flow's IR reads from any
`RuntimeContext` field that has no default — the validator catches a
scenario missing values whose absence the flow can't survive.

## 9. Validator rules

The validator (paper §7.2) picks up four new rules — all type-system-adjacent
but expressible only at the IR level:

- **R-RT-1 — Registry consistency.** Every key in `RuntimeContext` has a
  registry entry; every registry entry's source produces the declared
  type. (Enforced primarily by the `satisfies` constraint at the type
  layer; the validator backs it up at the IR layer for cross-flow
  consistency.)
- **R-RT-2 — Reference resolution.** Every `runtime.X` reference in a
  prompt slot, log message, log `includeVars`, transfer `contextPayload`,
  or `apiCall.headers` resolves to a declared key.
- **R-RT-3 — Namespace separation.** No name appears in both `FlowVars`
  and `RuntimeContext`. One name, one home.
- **R-RT-4 — Required-source completeness.** Every entry marked
  `required: true` and not sourced from a platform-guaranteed field
  (`ani`, `dnis`, etc.) either has a `default`/`fallback` or is named in
  every test scenario's `runtimeContext`. A `required` entry that the
  platform might fail to provide and the flow has no recovery for is a
  build error.

These complement R-IC-* and R-LS-* (inline code, log statements) from the
paper rather than replacing anything.

## 10. What stays the same

The paper's architecture absorbs this cleanly:

- The IR (paper §7.1) grows two fields — the resolved `RuntimeContext`
  registry and per-state references — but its shape is unchanged.
- The pipeline (front end → validator → backend) is unchanged. Every
  stage gains awareness of `runtime.*` references; none changes structure.
- The substitutable-backend contract (paper §5.3) is unchanged. Each
  backend adds a `resolveRuntimeContext(registry)` method that returns the
  per-source wiring; the rest of the `compile` interface is identical.
- The escape hatches (`InlineCode.reads`/`writes`, `vendorHints`) are
  unchanged. An inline-code block that reads runtime context lists
  `runtime.X` in its `reads`; the type rules of paper §4.7 still hold.

The model in §3 of the paper grows by one field on `FlowContext`. Nothing
in §3 needs to be revised. That's the test of whether an extension is
well-aligned with the core design: it adds without rewriting.
