# Continuous Deployment Mindset Transformation

The goal is not to deploy features faster.
The goal is to reduce risk through small, observable, reversible changes.

Core concepts:
- Spec-Driven Development
- Tracer Bullet Development
- Vertical Slices
- Test-Driven Development
- Trunk-Based Development
- Continuous Deployment
- Feature Flags
- AI-Assisted Development

Key principle:

Deploy != Release

Code can be deployed safely to production while remaining disabled behind feature flags.
