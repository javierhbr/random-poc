# AI-Assisted Development

AI agents work best with:

- Small tasks
- Clear acceptance criteria
- Limited scope
- Strong tests

Recommended rule:

No task should be so large that an AI agent cannot implement,
test, validate and review it in a single iteration.

This naturally promotes:
- Tracer Bullets
- Vertical Slices
- Continuous Deployment
