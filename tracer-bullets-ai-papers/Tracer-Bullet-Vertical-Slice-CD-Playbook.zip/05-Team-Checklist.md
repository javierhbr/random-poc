# Planning Checklist

- What is the business outcome?
- What is the smallest tracer bullet?
- What uncertainty are we reducing?
- What feature flag protects this?
- Can it be deployed independently?
- Can it be disabled independently?
- What tests will be written first?
- What observability is required?
- What is the rollback strategy?
- What is the next vertical slice?
