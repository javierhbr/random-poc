# TDD and Continuous Deployment

Continuous Deployment requires confidence.

Confidence comes from automated tests.

Chain:

TDD
-> Reliable Tests
-> Small Changes
-> Frequent Deployments
-> Continuous Deployment

Without tests:

Uncertainty
-> Fear
-> Large Deployments
-> Difficult Rollbacks
