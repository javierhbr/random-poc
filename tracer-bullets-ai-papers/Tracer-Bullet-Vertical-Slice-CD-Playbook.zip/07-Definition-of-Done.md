# Definition of Done

A work item is Done only if:

- Deployable
- Protected by Feature Flag
- Automated Tests Passing
- Observable
- Rollback Defined
- Documentation Updated
- Independently Releasable
