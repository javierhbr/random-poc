# From Feature-Centric Delivery to Risk-Centric Delivery

Old question:
When will the feature be finished?

New question:
What is the smallest deployable change we can safely ship today?

We are optimizing:
- Risk reduction
- Fast feedback
- Observability
- Reversibility

Not:
- Large feature releases
- Big bang deployments
