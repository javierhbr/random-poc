# Tracer Bullet vs Vertical Slice

## Tracer Bullet

Purpose:
- Prove the end-to-end path
- Reduce technical uncertainty
- Validate architecture
- Validate deployment pipeline
- Validate observability

Characteristics:
- Minimal functionality
- End-to-end
- Deployable
- Often focused on learning

Example:
UI -> API -> Database -> Metrics

Even if functionality is incomplete.

---

## Vertical Slice

Purpose:
- Deliver real business value

Characteristics:
- End-to-end
- User-visible outcome
- Deployable
- Observable
- Testable

Example:
Customer can successfully change their PIN.

---

## When to Use a Tracer Bullet

Use when:
- Architecture is uncertain
- Integrations are unknown
- Technology is new
- Deployment path is unproven

Goal:
Reduce uncertainty.

---

## When to Use a Vertical Slice

Use when:
- The path has already been proven
- You are incrementally delivering value

Goal:
Deliver business outcomes.

---

## How They Work Together

Step 1:
Build a Tracer Bullet.

Step 2:
Prove deployment, architecture, testing and observability.

Step 3:
Deliver multiple Vertical Slices through that proven path.

Formula:

Tracer Bullet -> Reduce Uncertainty

Vertical Slice -> Deliver Value
