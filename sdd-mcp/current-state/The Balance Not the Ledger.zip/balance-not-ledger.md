# The Balance, Not the Ledger

### Treating Current State as the Source of Truth in Long-Lived, Spec-Driven Platforms

*A position paper on the long-term information architecture of specifications, PRDs, and change records.*

---

## Abstract

Spec-driven development and PRD-per-change workflows are valuable when a platform is young. Over years, on a platform worked by many teams, they produce an ever-growing pile of point-in-time documents. The pile becomes the dominant cost: to answer the most common question — *what does the platform do today?* — a reader must locate and mentally merge hundreds of historical artifacts, most of which no longer describe the live system. This paper argues that the root cause is a category error: treating a **historical change log** as if it were a **current-state description**. These are two different kinds of knowledge with different lifecycles and access patterns. Using the everyday example of a bank statement — a transaction ledger versus an account balance — we show why current state should be treated as a *materialized projection* over history, kept as the primary view and bound to an enforcement mechanism, while history is preserved but evicted from the working set and consulted on demand. We focus on the problem and the principle of the solution, not on a rigorous implementation.

---

## 1. Problem Statement

A spec-driven or PRD-driven process creates one or more artifacts per change. Change A produces a spec; changes B, C, D, E, F each produce their own. Each is a faithful record of *one moment*: the intent of a single change at the time it was proposed.

Individually these artifacts are useful. In aggregate, over a multi-year, multi-team platform, three things happen:

1. **Volume dominates.** The number of specs and PRDs grows without bound. After a year or two there are hundreds; after five years, thousands. The collection becomes something you navigate, not something you read.

2. **Accuracy decays.** Each artifact froze at the moment it was written. The platform kept moving. A spec from change B may have been entirely superseded by changes D and F. Nothing in the document itself signals this; the reader must reconstruct it.

3. **The common query becomes the expensive one.** The question asked most often — *"What is the current behavior of capability X?"* — has no single answer to read. It must be **computed** by finding every artifact that ever touched X and folding them together in the reader's head, discarding what was later reversed. This is archaeology, and it is performed on the hot path of everyday work.

The failure is not that history is kept. History has real value. The failure is that the **historical record is being used as the current-state description**, and those are not the same artifact. The default, highest-frequency need — *what is true now* — is served by the most expensive possible operation.

A common organizational response is to keep all PRDs and specs together and cross-reference them. This does not solve the problem (Section 4). The problem is not that the documents are *disconnected*; it is that **no single artifact states the current state**, so every reader must derive it.

---

## 2. Assumptions

This paper's argument rests on the following premises. They are stated explicitly so they can be challenged.

- **A1 — Code is the authoritative source of truth for behavior.** What the system *does* is defined by the running code. Documentation describes intent and rationale; it does not override the code.

- **A2 — History is valuable, but on demand.** Provenance, audit, and the deep "why" matter. They are needed occasionally — during incidents, audits, or re-litigation of an old decision — not on every read.

- **A3 — The most frequent question is "what is true now?"** Far more often than "how did we get here?", people need the current shape of the system, plus a shallow "why."

- **A4 — Documentation without an enforcement mechanism drifts.** If nothing breaks when a document diverges from the system, divergence is silent and inevitable. Organization and discipline slow this; they do not stop it.

- **A5 — The right thing must be the easy thing.** At scale, across rotating teams, you cannot rely on everyone performing high-effort manual reconciliation. The system has to make keeping the truth current cheaper than letting it rot.

- **A6 — Scale changes the calculus.** With one author for one month, a pile of specs is fine. With many teams over many years, *volume* and *contention* become first-order design concerns, not details.

If you reject A1–A3, the rest of the argument weakens. If you accept them, the conclusion is hard to avoid.

---

## 3. Theory: State Is a Projection Over History

### 3.1 Two kinds of knowledge

There are two fundamentally different shapes of recorded knowledge:

- **An event log** is *append-only, immutable, and ordered*. Each entry records that something happened. You never edit a past entry; you only add new ones. The log grows forever.

- **State** is *overwrite-in-place* and answers "what is true now." It is small, current, and has no memory of how it got that way unless you ask the log.

A pile of PRDs and specs is an event log: each one records a change that was made, in order, and is never edited after the fact. The "current behavior of the platform" is *state*. The mistake is storing the second as if it were the first.

### 3.2 The bank statement

![The balance is a fold over the ledger; the bank materializes it and shows it first.](assets/balance-not-ledger.svg)

Everyone already understands this distinction, because everyone has a bank account.

Your account has a **transaction history**: every deposit and withdrawal, in order, since the account was opened. It is append-only and immutable — the bank never edits a past transaction; a correction is a *new* transaction. Over years it becomes thousands of lines. This is the **ledger** — the event log.

Your account also has a **balance**: one number that tells you what you have *right now*. This is the **state**.

The crucial fact: **the balance is a projection over the history.** It is, literally, the sum (a *fold*, or *reduction*) of every transaction. You could always recompute it by replaying the entire ledger from account opening. But you never do — and neither does the bank, on every read. The bank **materializes** the balance: it keeps it computed and up to date, shows it to you first, and lets you drill down into the transactions only when you have a reason to.

Imagine the alternative. You log in and the bank shows you ten thousand transactions and says, "your balance is in here somewhere — add it up." That is precisely what a five-year pile of specs asks of every engineer who wants to know what the platform does today.

### 3.3 The mapping

| Banking | Platform |
|---|---|
| Transaction history (ledger) | The full set of PRDs / specs, in order |
| A single transaction | One PRD / spec for one change |
| Account balance | The current-state specification |
| "Recompute the balance from the ledger" | Reading every spec to infer current behavior (archaeology) |
| The bank materializing your balance | Maintaining one living current-state document |
| Drilling into transactions for a dispute | Consulting history for provenance / audit / "why" |
| A correcting transaction (not an edit) | A later change that supersedes an earlier one |

### 3.4 Why "cross-reference everything" cannot substitute

A natural instinct is: keep all the transactions and link them together so you can trace anything. But **a balance is not a set of links between transactions.** No amount of cross-referencing the ledger produces the balance; the balance only exists once you *fold* the ledger into a single value and store it. Reference is not aggregation. Linking PRD-204 to PRD-87 still leaves the reader to traverse and sum the chain. The work of computing current state has not been done; it has merely been made *navigable*.

### 3.5 The economic core

Reads of "current state" vastly outnumber reads of "how we got here." The right design optimizes the frequent operation. Materializing the balance moves the cost of folding the ledger from **every read** (paid constantly, by everyone) to **every write** (paid once, by the person making the change, who already has the context). That is the whole trade, and it is a good one.

---

## 4. Why Common Approaches Fall Short

**4.1 Keep everything in one place and cross-reference it.**
This is the most common proposal and the one this paper is most directly arguing against. It preserves provenance — every "why" is reachable — but it never produces a current-state view. It optimizes the rare query (trace the history of a decision) at the expense of the common one (what is true now). And by placing deprecated and live material side by side, it *lowers* signal-to-noise: more documents, no clearer picture. It solves a problem the team doesn't have (disconnected history) and leaves the real one untouched (no materialized state).

**4.2 Status tags and requirement syntax (lifecycle markers, EARS).**
Marking each spec as `draft / ready / done / deprecated / superseded`, and writing requirements in a constrained form such as EARS (the *Easy Approach to Requirements Syntax* — five sentence patterns, originally from Rolls-Royce), both improve quality **per file**: less ambiguity in any single requirement, clearer state of any single document. Neither reduces **volume**, and neither performs **aggregation**. A hundred well-tagged, well-written EARS specs are still a hundred files you must open and merge to see the system. Per-sentence discipline is valuable and complementary — but it operates at the wrong altitude for this problem. EARS is a way to write a requirement; it is not a way to know the current state of a thousand of them.

**4.3 Spec-first tooling that creates a folder or branch per change.**
Several modern tools scaffold a new spec set (and sometimes a branch) for every change request. This is excellent for executing *one* change with rigor. But left unmanaged, it is exactly the machine that produces the sprawl: it optimizes the lifetime of a *change*, not the lifetime of a *capability*, so the per-change artifacts accumulate and are never folded back into a single current picture.

**4.4 "Just read the code."**
Code is authoritative (A1), but it is not *glanceable* for intent. It tells you what happens, not why, and rarely shows cross-cutting behavior at the altitude a human needs to reason about a capability. Code answers "what," poorly answers "why," and does not, by itself, give you a navigable map of the platform's behavior. The current-state spec is the human-readable projection of intent that the code cannot conveniently provide on its own.

---

## 5. Theory of the Solution

The principle is one sentence: **separate artifacts by lifecycle and access pattern, materialize the current-state projection, and bind it to an enforcement mechanism; preserve history but evict it from the working set.**

Concretely, this means three buckets, not one pile.

### 5.1 Three buckets

1. **Current state — *the balance*.**
   One living specification, organized by **capability/domain** (not by change). Lives in the repository, beside the code. Overwrite-in-place: when behavior changes, this document is *edited*, not appended to. It answers, at a glance, *what the platform does now* and a *shallow why*. This is the primary, default view.

2. **Decisions — *the why*.**
   Architecture Decision Records (ADRs) or equivalent. Durable, append-only, **superseded-not-deleted**. They capture the context, the options considered, the choice, and its consequences. This is where the *deep* why lives. Reached by a link from the current-state spec; not required for the common read.

3. **History — *the ledger*.**
   The full archive of PRDs and per-change specs. Append-only, immutable, **evicted from the working set** — moved out of the day-to-day path (a separate store, archive area, or repository) with a stable index and references. Consulted only when provenance is needed.

### 5.2 Materialize the projection (don't recompute it)

Keep the balance current. Updating the current-state spec is part of the **definition of done** for a change — the same way the bank updates your balance the instant a transaction clears, not on demand later. The person making the change folds their delta into the current picture *once*, while they hold the context, instead of leaving every future reader to fold it repeatedly.

### 5.3 Derive what you can from code (the cheapest truth)

The cheapest current-state document is the one you don't hand-maintain. Anything derivable from the code or tests — API surface, data contracts, observable behavior — should be **generated**, not narrated, because generated artifacts cannot drift from their source. Hand-written prose is reserved for what code cannot express: intent, rationale, cross-cutting behavior, and constraints. This directly honors assumption A1: code stays authoritative, and the document is, as much as possible, a *view* of it.

### 5.4 Bind the truth to an enforcement mechanism

This is the non-negotiable part. A current-state document with nothing to keep it honest becomes just another stale file (A4). Bind it to something that **breaks when it diverges**: contract tests that fail CI when the implementation and the spec disagree; *fitness functions* that assert architectural properties on every build; generated sections that are regenerated and diffed. The difference between a living artifact and a dead one is not how it is written — it is whether divergence produces a signal. Without a signal, divergence is invisible until someone reads outdated information and acts on it.

### 5.5 Evict, don't delete

Nothing is thrown away. The ledger is preserved in full, for audit and provenance — but it is moved *off the hot path*. The working set contains the balance (current state) and the index into history; the bulk of historical detail lives in cold storage you can always reach. This is the reframing that matters organizationally (Section 9): the debate is not *keep vs. delete history* — nobody is deleting anything — it is *what is the default view*.

### 5.6 Make history queryable on demand

Replaying the ledger should be rare and easy, not common and hard. An indexed archive — increasingly, one you can query conversationally with an AI assistant rather than read linearly — turns "be an archaeologist" into "ask a question." History becomes cheap to keep precisely because it no longer has to be read in full to be useful.

---

## 6. A Concrete (Illustrative) Shape

This is one simple instantiation, offered to make the principle tangible — not a prescription. Simpler is better; adapt to your tools.

**A possible repository layout**

```
/spec/                      # the balance — current state, in-repo, enforced
   accounts.md              #   capability: accounts & balances (current behavior)
   payments.md              #   capability: payments
   statements.md            #   capability: statements & history
/decisions/                 # the why — ADRs, append-only, superseded-not-deleted
   0007-overdraft-policy.md
   0012-ledger-immutability.md
/archive/                   # (or a separate store) the ledger — evicted history
   index.md                 #   stable index + references into the change log
   2023/PRD-087-...
   2024/PRD-204-...
   ...
```

**The banking domain, used on itself**

Suppose the platform is a banking app, and we want to describe the *Account Balance* capability.

- **Current-state spec** (`/spec/accounts.md`) states, in plain, testable language, what is true *now*: how a balance is computed, that it is derived from an immutable transaction ledger, that overdraft protection applies below zero, and a one-line rationale with a link to the relevant decision. A reader knows the current behavior in thirty seconds, without touching history.

- **Decision record** (`/decisions/0007-overdraft-policy.md`) explains *why* overdraft protection works the way it does: what was considered, what was chosen, the consequences. Reached only if you need the deep why.

- **Archive** (`/archive/2024/PRD-204-add-overdraft.md`) is the original change proposal that introduced overdraft protection. It is preserved verbatim for provenance, indexed, and otherwise out of the way. If a later change reverses part of it, the *current-state spec is edited* and a *new* archive entry is added — the old PRD is never altered, exactly like a correcting bank transaction.

The mental model the team shares is one sentence everyone already understands: **read the balance; drill into transactions only when you have a reason.**

**A "definition of done" that keeps the balance current**

A change is not done until: (1) the code is merged; (2) the relevant `/spec` capability file is edited to reflect the new current behavior; (3) any significant decision is captured as an ADR; (4) the change proposal is filed in the archive; and (5) the enforcement check (contract test / fitness function) passes. Five steps, four of them cheap, performed once by the person with the most context.

---

## 7. Alternatives and Variations That May Help

- **Event sourcing as literal architecture, not just metaphor.** If the *system itself* stores events and derives state (as ledgers and many financial systems do), the documentation pattern simply mirrors the system's own design — which makes it natural for teams to reason about.

- **Generated, code-anchored documentation.** API specs from code (e.g., generated contract definitions), documentation tests, and behavior-driven "living documentation" all push the current-state truth toward being *derived* rather than maintained — the strongest defense against drift.

- **Periodic snapshots ("month-end statements").** A compromise that satisfies an audit instinct: in addition to the always-current balance, materialize a dated snapshot of the full current-state spec at intervals (per release, per quarter). You get a clean current view *and* a series of point-in-time states without keeping every delta on the hot path.

- **Demote, don't discard, the cross-reference idea.** The organization's instinct to link everything is not worthless — it is just placed in the wrong tier. Rich cross-references belong in the **archive's index**, where tracing provenance is the job, not in the working set, where the job is to state the present.

- **AI-queryable history.** Treat the archive as something you interrogate, not read. This lowers the cost of provenance enough that there is no longer any temptation to keep history in the working set "just in case."

---

## 8. Trade-offs, Risks, and Open Questions

- **Maintaining the balance is itself work.** Mitigated by deriving as much as possible from code (5.3) and by making the update part of *done* (6) so the cost is paid once, in context — but it is not free, and a team that skips it will rot the current-state spec like any other doc.

- **The current-state spec becomes a contended, shared artifact.** Many teams editing one capability map introduces cross-team coupling. This needs clear ownership per capability, the same way code modules have owners.

- **Enforcement is mandatory, not optional.** A materialized view with no enforcement mechanism is the worst of both worlds: it *looks* authoritative while silently drifting. If you cannot bind it to a signal (5.4), be honest that it is a convenience, not a source of truth.

- **Where to draw the state / decision / log boundary is judgment.** What counts as "current state" versus "a decision" versus "just history" is a matter of taste and will need a light convention, not a formula.

- **Audit and compliance.** Some environments require complete, immutable provenance. This model *supports* that — the archive is the immutable ledger — but the compliance team must agree that "preserved and indexed, off the hot path" satisfies their requirement. It usually does; confirm it.

---

## 9. Recommendation

Adopt the **balance-not-ledger** model:

1. Make **current state the primary, materialized view** — one living, capability-organized specification, in the repository, beside the code.
2. **Derive from code where possible** and **bind the rest to CI enforcement**, so the current-state truth cannot drift silently.
3. Keep the **deep "why" in decision records** (append-only, superseded-not-deleted).
4. **Evict — do not delete — history** to an indexed, on-demand archive.

And to move the internal conversation forward, **reframe the disagreement.** It is not "keep history versus throw it away" — under this model nothing is thrown away. It is a narrower, more answerable question: *what is the default view of the platform?* One answer makes it the entire ledger, and forces every reader to compute the balance by hand. The other shows the balance first and keeps the ledger one click away. Framed that way, the choice is not really in doubt — it is how every bank in the world has already chosen to show you your money.

---

## Appendix A — Glossary

- **State** — Overwrite-in-place knowledge of "what is true now." Small, current, no built-in memory of its own history.
- **Event log / ledger** — Append-only, immutable, ordered record of things that happened. Grows forever; never edited in place.
- **Projection / fold / reduction** — Computing a single current value (state) by combining every entry in a log in order. A balance is a projection over a transaction ledger.
- **Materialized view** — A projection that is computed once and kept up to date, so readers don't recompute it. A maintained current-state spec is a materialized view over the history of changes.
- **Drift** — Silent divergence between a document and the system it describes, occurring whenever nothing breaks on divergence.
- **ADR (Architecture Decision Record)** — A short, durable record of one significant decision: context, options, choice, consequences. Append-only; reversed decisions are marked superseded, not deleted.
- **EARS (Easy Approach to Requirements Syntax)** — A small set of sentence patterns for writing unambiguous requirements. A writing standard, not an aggregation strategy.
- **Fitness function** — An automated check that asserts an architectural property on every build, failing when the property is violated. A mechanism for turning a documented intention into an enforced one.

## Appendix B — Background and Further Reading

The following informed this paper; claims are paraphrased and attributed.

- **Documentation drift / the "spec-evergreen" problem** — widely discussed as near-universal: documents written once, briefly read, then abandoned while code moves on.
- **Spec-first vs. spec-anchored vs. spec-as-source** — Martin Fowler's site (Birgitta Böckeler, *Exploring Gen AI*) distinguishes maturity levels of spec-driven development and notes that the *maintenance strategy over time* is often left undefined.
- **OpenSpec** — a tool whose model merges per-change "delta" specs into a single source-of-truth specification and archives the deltas; the clearest existing instance of the "balance + ledger" split. (intent-driven.dev; OpenSpec project.)
- **GitHub Spec Kit; Kiro (AWS); Tessl** — representative spec-driven tools; Spec Kit's per-change branching illustrates the sprawl risk, while Kiro's "living specs" and Tessl's "spec-as-source" push toward a maintained current state.
- **Architecture Decision Records** — Michael Nygard, *Documenting Architecture Decisions* (2011); the ADR GitHub organization; the principle that ADRs are short and durable, recording decisions rather than current state.
- **EARS** — Alistair Mavin et al., Rolls-Royce, introduced at RE'09; the five requirement patterns.
- **Fitness functions / evolutionary architecture** — Ford, Parsons, and Kua, *Building Evolutionary Architectures*; the idea that architectural knowledge should be coupled to artifacts with their own enforcement mechanisms.
- **"Spec as source of truth" and the rebuild test** — industry guidance on treating the specification as the primary artifact and code as derived, and on testing spec completeness by attempting to regenerate the system from it.
- **SDD relocates complexity** — InfoQ's analysis that specifications, once authoritative, inherit the properties of source code (technical debt, coupling) and require the same operational rigor.

---

*This is a position paper focused on the problem and the principle of a solution. The implementations referenced are illustrative; the recommended direction is independent of any specific tool.*
