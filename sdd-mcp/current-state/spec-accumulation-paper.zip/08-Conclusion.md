# Conclusion

The problem is not preserving history.

The problem is forcing engineers to reconstruct the present from historical artifacts.

History should remain available.

Current understanding should remain effortless.

The key question is:

What is true today?
