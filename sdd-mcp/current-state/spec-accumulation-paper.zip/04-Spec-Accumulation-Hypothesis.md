# Spec Accumulation Hypothesis

As the cost of generating specifications approaches zero, the bottleneck shifts from knowledge production to knowledge compression.

Traceability improves.

Comprehension decreases.
