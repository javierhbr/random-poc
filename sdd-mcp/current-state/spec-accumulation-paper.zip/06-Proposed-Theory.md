# Proposed Theory

Separate history from current knowledge.

History Layer

- PRDs
- Specs
- RFCs

Purpose:
Preserve evolution.

Current-State Layer

- Architecture
- APIs
- Invariants
- Domain model
- Events
- Dependencies

Purpose:
Optimize understanding.
