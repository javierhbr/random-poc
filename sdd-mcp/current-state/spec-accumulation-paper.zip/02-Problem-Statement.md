# Problem Statement

Long-lived platforms accumulate:

- PRDs
- Specs
- RFCs
- Design docs

Eventually, engineers must reconstruct the current system by reading years of history.

This creates repository archaeology.

The problem is not preserving history.

The problem is forcing humans to navigate history to understand the present.
