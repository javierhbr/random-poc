# Abstract

As AI lowers the cost of generating specifications, organizations face a new problem: spec accumulation.

The challenge is no longer producing knowledge.

The challenge becomes maintaining a clear understanding of the current state of the system.

History should be preserved.

Current understanding should be optimized.
