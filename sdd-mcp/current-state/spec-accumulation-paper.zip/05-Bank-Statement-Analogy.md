# Bank Statement Analogy

Imagine a bank account.

Transaction history:

+100
-50
+200
-10
+40

Current balance:

280

Nobody reconstructs the balance by replaying years of transactions.

History exists.

Current state is materialized.

Software should work similarly.

PRDs and specs are transaction history.

Current knowledge is the account balance.
