# Assumptions

1. History is valuable.
2. History is accessed less frequently than current state.
3. Engineers optimize for understanding today's behavior.
4. Documentation naturally drifts.
5. Cognitive load matters.
