# Wizard UX & Engagement — Validated Design Notes

A critical pass over the ideas raised for improving the Gandalf Game wizard. Each idea gets a
**verdict**, the **reason**, and the **guardrail** that keeps it from backfiring. This is an
assessment, not a wish-list — several ideas are modified or held back on purpose.

---

## The one principle everything is judged against

**Engagement should come from the texture of the interaction, not from a reward bolted on top —
and every effect must either make the next move clearer or make an insight land harder. Anything
that is "fun" for its own sake gets cut.**

Two corollaries that act as filters:

- **Don't fight the purpose.** Gandalf's value is the user *understanding* their decisions. Anything
  that nudges people to answer-to-win, rush, or stop thinking is a regression even if it boosts
  raw completion.
- **Motion is a cost, not a free good.** A wizard that pauses, animates, or chatters between every
  tap feels *less* fluid, not more. Liveliness has to be spent where it earns its place.

### Verdict legend

| Verdict | Meaning |
|---|---|
| ✅ **Adopt** | Sound; low risk; build it. |
| 🟡 **Adopt w/ guardrail** | Good idea, but unsafe or annoying without a specific constraint. |
| 🔵 **Defer** | Valuable later; not yet, or needs a dependency first. |
| ⛔ **Cut** | Conflicts with the principle; don't build. |

---

## A. Reactive feedback (per-step physicality)

Make each interaction feel like it *responds* to you, so a tap confirms "you did something real."

| Idea | Verdict | Reason & guardrail |
|---|---|---|
| **Snap-and-settle** when a chip lands in a bin | ✅ Adopt | Cheap, tactile, confirms the action. Keep < 250ms; honor `prefers-reduced-motion` (already wired). |
| **Spark-line** drawn between two players when a real conflict is tapped | ✅ Adopt | Turns the abstract word "conflict" into something you can see; teaches as it delights. Only on `type:conflict` pairs; fade after a beat so the board doesn't clutter. |
| **Card flip** on the pattern check | ✅ Adopt | Adds tactility to a reveal that already exists. Negligible risk. |
| **Ripple advancing *toward* the user** (the double-charge "arriving") | ✅ Adopt | The single highest-value animation — it dramatizes 2nd/3rd-order effects, which is the hardest idea to feel. Worth real polish. |
| **Payoff matrix lights the losing cell on hover of the wrong row** | 🟡 Adopt w/ guardrail | Risk: hovering *reveals the answer* and kills the "decide" moment. Modify — reveal the consequence only **after a click**, or use a faint hover hint that doesn't give the game away. |

---

## B. Forward pull (open loops)

The strongest completion driver isn't reward — it's an unfinished loop you can see.

| Idea | Verdict | Reason & guardrail |
|---|---|---|
| **Coverage meter** — the tray reads as a board with "what's still uncovered" | ✅ Adopt | Open loops pull people forward better than any badge. Guardrail: frame it as *discovery left to do*, never a quota to hit — don't shame an incomplete board or imply a "100%." |
| **Next-step preview** — the upcoming step shown as a faint silhouette that lights up the instant you finish | 🟡 Adopt w/ guardrail | A genuine pull. But a *row* of locked steps reads as a long, daunting checklist. Modify — preview only **the next one**, not the whole remaining list. |
| **Depth gate as difficulty selector** | ✅ Adopt | Already structural. Reframe "Deep" as *the full game*, not *more tedium*, so thoroughness feels like the richer playthrough. |
| **End scorecard** — "you caught N production landmines before a line of code" | ✅ Adopt | This is recap-as-payoff (the assemble screen's "what a feature-list PRD would have missed"). It's a recognition beat, not a points total — keep it that way. |

---

## C. Narration & character

Let the scenario and the agents talk, so a step feels like a *room with something happening in it*
rather than a form.

| Idea | Verdict | Reason & guardrail |
|---|---|---|
| **The scenario talks back** (e.g. "call recording" speaks up when mis-binned) | 🟡 Adopt w/ guardrail | Delightful at a key moment, cloying if *everything* talks. Limit to **2–3 marquee moments** (the silent player, the vanity metric, the dropped-call ripple). |
| **Agents drop one in-character line** at the right step | ✅ Adopt | This is the suite's existing strength (Security/Risk Analyst). One line, at the money/auth step or the ripple — a scene, not a wall of text. Make it skippable. |
| **A persistent "guide"/game-master mascot that comments throughout** | 🟡 Adopt w/ guardrail (lean Defer) | High Clippy risk. A constant commentator becomes noise fast. Modify — a **consistent voice and tone** across steps (the framing lines), *not* an animated character chattering on every screen. |

---

## D. Clarity discipline (this is a rule, not a feature)

✅ **Adopt as a governing constraint.** One question, one obvious next move, one immediate
response — per step. Every idea in A–C must *serve* this, never crowd it. If an animation or a line
of narration makes the next move less obvious, it's wrong by definition. This rule is what keeps
the "alive" version from becoming the "busy" version.

---

## E. Insight beats (explicitly *not* points or badges)

✅ **Adopt.** When the user catches the silent player or avoids the validity-oracle trap, the moment
lands with a small flourish and the "why," then moves them on. The reward is **recognition of the
insight**, not currency. (Per the explicit steer away from points/badges/leaderboards — see
"What not to build.")

---

## F. Dynamic content via a backend / LLM

The biggest lever and the biggest risk: generate each step's content live so the wizard runs on the
*user's own* feature instead of replaying the IVR example.

### F1. Where the model call lives

| Option | Verdict | Notes |
|---|---|---|
| **Skill-as-backend** (Claude runs the game; the HTML is the view) | ✅ Adopt (now) | No API-key-in-a-file problem; the LLM is already in the loop during `gandalf-play`. Front-end + engine become one live game. |
| **Thin proxy server** (holds the key; the standalone HTML `fetch`es it) | 🔵 Defer | The right answer *if* the wizard must run outside a Claude session. Document it; build later. |
| **API key inside the HTML** | ⛔ Cut | Never ship a key in a file users can open. |

### F2. The answer-key collision (the thing that shapes the whole design)

The static wizard *grades* you against a known key (right outcome, which pairs conflict, which
patterns fire). The moment content is generated for the user's **own, unsolved** feature, those
right answers don't exist — discovering them *is the game*. So dynamic mode must shift the model
from **quizmaster to facilitator** — the same guide-don't-decide stance already in the suite.

✅ **Adopt the shift.** Dynamic steps stop grading; they prompt, propose, and challenge.

### F3. What the model is allowed to do (three jobs, capped)

| Job | Verdict | What it does · the cap |
|---|---|---|
| **Reframe** | ✅ Adopt | Rewrite the step's prompt/examples in the user's domain. Pure cosmetics over the same interaction; safe, high engagement. One call at the start sets the whole voice. |
| **Propose candidates** | 🟡 Adopt w/ guardrail | Suggest a few players / possible conflicts **as questions the user accepts, rejects, or edits** — never auto-filled. Hard cap: **≤ 3, framed as questions.** This is the engaging one *and* the one most likely to slip into deciding-for-the-user. |
| **Challenge** | ✅ Adopt | An agent generates live, in-character pushback against what the user just entered. Highest engagement payoff — a real attack on *their* design. Best at 2–3 leverage points (money/auth, the ripple). |
| **Generate the "correct" answers & discoveries** | ⛔ Cut | This is the line that turns a thinking tool into a slot machine. The model never silently produces conclusions. |

### F4. Selective placement (don't make every step dynamic)

🟡 **Adopt w/ guardrail.** Per-step model calls add latency and variability; a wizard that "thinks"
between every tap kills the feel. So: **reframe once at the start, propose only where the user is
stuck, challenge at 2–3 high-leverage moments — everything else stays instant and static.** The LLM
shows up only where it earns the wait.

---

## Cross-cutting risks & their guardrails

| Risk | Guardrail |
|---|---|
| **Latency / variability** breaks the "step into the door" flow | Selective use (F4); optimistic loading states; cache the opening reframe for the whole session. |
| **Animation/narration becomes noise** | Rule D — every effect must clarify the next move or deepen an insight, or it's cut. |
| **Dynamic content decides for the user** | F2/F3 — facilitator mode, propose-as-questions, ≤3 cap, never generate the answer key. |
| **Key exposure** | No model calls from the static HTML; skill-as-backend or a proxy. |
| **Gimmick fatigue / mascot cloying** | Caps in C; consistent voice, not a constant commentator. |

---

## Per-step application map

How the validated enhancements land on the existing 14 steps (renderers unchanged; this is a layer).

| Step (type) | Reactive | Narration | Dynamic mode |
|---|---|---|---|
| Intro | gentle entrance | one framing line | **Reframe** (set scenario voice) — once |
| 0 Depth (`depth-gate`) | cell snap on resolve | — | static |
| 1 Outcome (`single-select`) | — | — | **Reframe** prompt to user's domain |
| 2 Players (`sort-bins`) | **snap-and-settle** | silent-player "speaks up" (marquee) | **Propose** ≤3 candidate players (as questions) |
| 3 Conflicts (`pair-select`) | **spark-line** on conflict | — | **Propose** candidate tensions (≤3) |
| 4 Equilibrium (`single-select`) | — | — | static |
| 5 Options (`single-select`) | — | — | **Reframe** |
| 6 Pattern Check (`pattern-check`) | **card flip** | one agent line (Security) | **Challenge** (agent attacks live) |
| 7 Ripple (`ripple`) | **advance-toward-you** | "double-charge arrives" beat | **Challenge** (Risk Analyst traces it) |
| 8 Constraints (`multi-select`) | chip lock-in | — | **Propose** domain constraints (≤3) |
| 9 Decide (`payoff-matrix`) | reveal-after-click | — | static |
| 10 Rollout (`order`) | connect-line on correct order | — | static |
| 11 Metrics (`multi-select`) | vanity-metric "called out" | marquee beat | static |
| ▣ Assemble | staggered build | **scorecard** recap | static |

---

## Architecture deltas (small; the renderers don't change)

1. **Config:** add to each step an optional `mode: "static" | "dynamic"` and, for dynamic steps, a
   `dynamic` block: `{ job: "reframe" | "propose" | "challenge", cap: 3, prompt: "<template>" }`.
   Add an optional `fx` block for reactive flourishes (e.g. `{ spark: true, advance: true }`) and an
   optional `narration` array of marquee lines. (Extend `core/wizard.config.schema.json`.)
2. **State:** `game_state.json` already carries `moves[]`; dynamic content and challenges log there.
3. **The seam:** a single `getStepContent(step, gameState)` in the engine. Static steps return their
   config as-is; dynamic steps render a loading state and call the backend, then slot the result
   into the **same** reusable renderer (a proposed player still drops into `sort-bins`). One
   integration point, everything routes through it.
4. **Backend:** skill-as-engine now; a documented thin proxy for standalone later.

---

## Recommended roadmap (cheapest-highest-leverage first)

**Phase 0 — pure feel, no backend (ship first).**
Reactive layer (A) + forward pull (B) + insight beats (E) + the clarity rule (D). All inside the
existing single HTML, zero server, zero risk. The biggest perceived-quality jump for the least work.
*Smallest first slice: snap physics + the ripple-advancing animation + the coverage meter.*

**Phase 1 — authored character, still static.**
Marquee narration and one-line agent quips from **config** (authored, not generated). Adds the
"room with something in it" feel without a backend.

**Phase 2 — dynamic, skill-as-backend.**
Add `mode`/`dynamic` + the `getStepContent` seam. Prove it on **one** step — the live Security
challenge on the payments step, in the user's own domain. Measure: does the aliveness outweigh the
latency? Only then spread it.

**Phase 3 — standalone proxy.**
Documented thin backend so the wizard runs dynamic outside a Claude session; reframe/propose/
challenge across the selected steps from the map above.

---

## What *not* to build

- ⛔ Points, badges, XP, or head-to-head leaderboards (explicitly out of scope by request — they pull
  toward answer-to-win).
- ⛔ Timers or anything that rewards speed (fights understanding).
- ⛔ A mascot that comments on every screen (noise; Clippy risk).
- ⛔ Dynamic generation of the "correct" answers or the discovery list (turns the tool into a slot
  machine; violates guide-don't-decide).
- ⛔ API keys in the HTML.
- ⛔ Any animation that doesn't clarify the next move or deepen an insight.

---

### One-line summary

Make every step feel *alive and obvious* (Phase 0, pure front-end), give it *character* sparingly
(Phase 1, authored), then make it *live* on the user's own feature (Phase 2+, the model as
facilitator — never as answer key).
