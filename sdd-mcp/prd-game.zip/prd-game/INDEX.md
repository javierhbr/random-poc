# Gandalf — complete bundle

Everything built across the conversation, in the order it was made. Gandalf = the
**Game-Theoretic Discovery Framework**: read a software change as a strategic game (players,
incentives, reactions, equilibria) before committing, to surface what a feature-list PRD misses.
Named for the wizard who sees the larger picture and *advises rather than commands* — the same
prime directive the tooling enforces: **guide, don't decide.**

## Contents

**01-framework/ — `Gandalf-v2.md`**
The refactored framework / operational reference. The 11-step spine, the depth gate, and the
8-pattern "Pattern Check" engine. Start here for the method itself.

**02-paper/ — `Gandalf-paper.md`**
The teaching paper. Explains game theory from zero (no math), why feature-list PRDs fail, then
every step with what-it-is / why / required-or-optional. Written for intern → senior.

**03-explainer/ — `gandalf-explainer.html`**
Animated single-page explainer of the paper. Light "game-board" theme; interactive equilibrium
matrix. Open in a browser. (If an in-app browser forces dark mode, open in Safari/Chrome.)

**04-tutorial/ — `gandalf-tutorial-ivr-payments.md`**
A hands-on worked example: applying Gandalf to "add payments to an IVR platform," then assembling the
PRD from the discovery. Shows the framework finding ~12 hidden requirements.

**05-wizards/**
- `gandalf-game-wizard.html` — the original interactive, step-by-step wizard (hardcoded IVR game).
- `gandalf-game-configurable.html` — the config-driven rebuild. Same UI, but every step/question/
  option/dependency comes from a `Gandalf_CONFIG` JSON object. Has a **load config** button so it can
  play any generated config; a built-in IVR sample loads by default.

**06-skill-single/ — `gandalf.skill` + `gandalf/`**
The first single Skill: one facilitator that guides a user through the whole framework
(guide-don't-decide). `gandalf.skill` is the installable package; `gandalf/` is the unpacked source
(SKILL.md + framework.yaml + game_state.template.yaml + an example session).

**07-suite/ — `gandalf-suite/`**
The latest architecture: the single skill split into a suite.
- `core/` — shared rulebook (`framework.yaml`), JSON state schema, and the wizard-config schema.
- `skills/` — `gandalf-setup` (load & set the board), `gandalf-play` (run the game + summon agents),
  `gandalf-decide` (weigh options, capture lightweight ADR stubs, export a dossier — **not** a PRD),
  `gandalf-export-wizard` (turn a played game into a `Gandalf_CONFIG` for the HTML).
- `agents/` — challenger personas the user plays against: `judge`, `security-analyst`,
  `risk-analyst`.
- `wizard/` — a copy of the config-driven HTML, so the suite is self-contained.

**08-plugin/ — `gandalf/`**
The suite packaged as an installable **Claude Code plugin**. `.claude-plugin/plugin.json` manifest,
`commands/` (`/gandalf`, `/gandalf-setup`, `/gandalf-play`, `/gandalf-decide`, `/gandalf-wizard`), the four
`skills/`, the three challenger `agents/` (now first-class subagents), and the shared `core/` +
`wizard/` assets. Skills reference shared files via `${CLAUDE_PLUGIN_ROOT}` so it installs as a
self-contained unit. Same method and behavior as 07; this is the distribution form.

**09-react-wizard/ — lean Vite + React + TS app**
The configurable wizard (05) rebuilt as a React app. Content is a **`GandalfConfig` JSON
loaded at runtime** (the `wizard.config.schema.json` shape) — `?config=<name|/path|url>`,
`?configFile=<abs disk path>`, or a Load button; bundled examples in `public/configs/`
(`ivr.json`, plus `squirrel.json` auto-authored from that project's docs). One small
component per step `type`, plus a **visual-spec-style comment layer**: annotate any
step/prompt/option/chip, comments persist to `comments.json` via Vite `/comments`, and
an agent applies them by editing the JSON config named in each comment's `target.file`
(see its `AGENTS.md`); reload to see changes. `npm install && npm run dev`.

## How the pieces relate

Read the **paper (02)** to learn it → use the **framework (01)** as the checklist → the
**tutorial (04)** shows it worked end to end → the **explainer (03)** and **wizards (05)** are
visual/interactive versions → the **suite (07)** is the tooling that facilitates a live game and can
**export a played game into a wizard config** the HTML in 05 plays.

Note: the suite produces discovery findings (a dossier), not a finished PRD — you write the PRD in
your own tool from that material.
