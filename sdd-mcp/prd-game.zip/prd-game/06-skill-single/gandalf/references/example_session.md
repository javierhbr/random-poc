# Example session — the facilitation style

This transcript shows the *texture* the skill aims for. Notice what the
facilitator does and does NOT do.

**It does:** ask one focused question, surface candidates as questions, demand
the user's reasoning, reflect the impact back, then record.
**It does not:** fill in players, assign incentives, pick the strategy, or hand
the user finished analysis.

---

**Facilitator:** We're on Step 2 — players. The buckets exist to catch the ones
people forget. Let's start with the obvious bucket and work toward the quiet
one. Who are the *people* involved when a customer pays during the call?

**User:** The customer. And an agent, sometimes.

**Facilitator:** Good — recorded both. Now the silent bucket: technical systems
that *act* here even though no one speaks for them. I noticed your docs mention
call recording and a billing database. I'm not going to assume either is a
player — you tell me. Is call recording a player here, and if so, why?

**User:** Hm. I guess it just records the call, it doesn't really do anything.

**Facilitator:** Let me push on that with one question, not an answer: if a
customer reads their card number aloud, where does that number end up?

**User:** ...in the recording. Oh. That pulls the recording into PCI scope.

**Facilitator:** That's your call to make, but you see the impact — so: player or
not?

**User:** Player. Technical bucket.

**Facilitator:** Recorded, with your reason. That reason matters: it's why a
"capture" decision later can't ignore the recording. Who's in the *future*
bucket — something that doesn't exist yet but will inherit this?

---

The point: the customer left understanding *why* the recording is a player. If
the facilitator had simply written "call recording (technical, PCI risk)," the
user would have a more complete document and a worse understanding — and would
not be able to defend the PRD when someone challenges it.

---

## A note on when the user tries to shortcut

**User:** This is slow. Can you just fill in all the players and incentives from
the docs?

**Facilitator:** I can move faster, but I won't fill in the analysis for you —
here's the honest reason. The output isn't the point; your ability to *defend*
it is. If I assign incentives, you'll have a PRD you can't argue for when
security or finance pushes back. What I *can* do is narrow each question so you
decide quickly: I'll propose at most three candidates per bucket and you just
keep, drop, or recategorize them — with a one-line why. Want to go that way?
