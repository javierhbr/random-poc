---
name: gandalf-wizard
description: >
  Play the Gandalf discovery wizard in the terminal — the in-chat twin of the HTML/React Gandalf Game
  wizard. Use when the user says "play the wizard", "run the game wizard", "game-wizard", "play the
  Gandalf wizard in chat", "walk me through the wizard", or points at a wizard config JSON (a
  Gandalf_CONFIG) and wants to play it step by step here instead of in a browser. It walks an ordered
  config of step types, collects the user's choices via the question picker, keeps a discovery tray,
  and exports the SAME dossier the HTML wizard produces. Default is faithful REPLAY of an authored
  config; it can also run DYNAMIC on the user's own feature. It does NOT write a PRD.
---

# Gandalf — Wizard (play the game in the terminal)

This skill is the chat twin of the Gandalf Game wizard (the React app in `09-react-wizard/` and the
self-contained `wizard/gandalf-game-configurable.html`). It renders the exact same `Gandalf_CONFIG` —
an ordered list of typed steps — as a terminal session, keeps the same **discovery tray**, and
emits the **same dossier JSON**. The browser wizard and this skill are two front-ends over one data
contract; play here when chat is more convenient than a browser.

## Prime directive

**Guide, don't decide.** The user makes every call. Surface candidates as questions (max three at a
time), get the *why*, reflect the *impact* before recording. (`../../README.md` has the full
contract.) The one exception is **replay of an authored teaching config** (the bundled IVR sample),
which has answer keys on purpose — there you may reveal right/wrong, because the lesson *is* the
contrast. A **dynamic** session never has an answer key: the user's pick is simply recorded.

## The two modes

- **Replay (default).** Play an authored `Gandalf_CONFIG` with its answer keys. Each step's authored
  `discoveries` are committed to the tray as the user leaves it, so the dossier is deterministic and
  identical to the HTML wizard's. Use the bundled `configs/ivr-sample.json`, a config the user
  points at, or a `gandalf.config.json` produced by **gandalf-export-wizard**.
- **Dynamic.** Run on the user's *own* feature. Drop every answer key (`correct`/`good`/
  `dominant`/`fires`/correct-order); reframe each step's prose and options into the user's domain;
  record the user's REAL picks into the tray. This is where you, the model, do the work the React
  app delegates to a `claude -p` backend — reframe, propose ≤3 candidates, challenge — but never
  fill in the analysis.

At start, if the user named a feature but no config, offer dynamic. If they named/loaded a config,
default to replay. Confirm in one line before playing.

## Files

- `configs/ivr-sample.json` — the bundled authored teaching config (IVR payments). Replay default.
- `../../core/wizard.config.schema.json` — the `Gandalf_CONFIG` shape you render (step types + fields).
- Output: `gandalf-dossier-<slug>.json` (the dossier) and `wizard_state.json` (resumable runtime state).

## Runtime state (write after EVERY step — sessions are resumable)

Keep a `wizard_state.json` next to the config and rewrite it after each step:

```json
{
  "gandalf": "wizard-terminal/1",
  "config": "<path or name>",
  "mode": "replay",
  "feature": null,
  "idx": 0,
  "depth": null,
  "pieces": [{ "id": "...", "text": "...", "cat": "..." }],
  "moves":  [{ "stepId": "...", "type": "..." }]
}
```

- `pieces` is the **discovery tray** — the residue that becomes the dossier.
- On start, if a `wizard_state.json` matching this config exists, offer to resume from `idx`.

## The board & coverage meter

Before playing, compute the **board** = every category appearing in any step's `discoveries`
(the `[id, text, cat]` triples) plus the config's `categories`. After each step, show a one-line
coverage note: which categories are now in the tray and which are *still to uncover* — an open loop
of discovery, never a quota or a percentage.

## The play loop (per step, in config order)

1. **Orient** — print `badge`, `title`, `sub` (strip HTML tags from these strings) in 1–2 lines.
   If a `move` is set, show it as `the move → …`.
2. **Render the interaction** using the recipe for `step.type` (below). Drive selects with the
   **AskUserQuestion** picker; use plain numbered text only where a step exceeds what the picker
   handles (noted per recipe).
3. **React** —
   - *Replay:* reveal right/wrong from the answer key and the step's `why` panel (strip HTML).
   - *Dynamic:* no right/wrong; reflect the impact of the choice (the conflict it creates, the
     requirement it forces, the option it eliminates).
4. **Record** —
   - *Replay:* commit the step's authored `discoveries` to `pieces` (dedupe by `id`). Additionally
     capture pair-select **open-question** flags and any write-ins as their own pieces.
   - *Dynamic:* record the user's REAL picks into `pieces` under the step's category (the first
     `discoveries` cat, else a sensible default: single-select→`decision`, sort-bins→`player`,
     pair-select→`requirement`, multi-select→`constraint`). Replace prior pieces from this step on a
     revisit, don't duplicate.
5. **Log the move** — append `{ stepId, type }` to `moves`.
6. **Persist** — rewrite `wizard_state.json`, then show the coverage note and the next step preview.

## Step recipes (the 11 types)

**intro** — Print `eyebrow`, `title`, `lede`, and the `flow` arrow strip. No question, UNLESS the
step has `featurePrompt` (dynamic): ask the user for their feature and store it in `feature`. Then
advance.

**depth-gate** — One AskUserQuestion call with the two `axes` as two questions (header = a short
axis name; options from `axes[].options[].label`). From the two picks, derive depth via the config's
`matrix["<v0>__<v1>"]` (its `label` is the depth: light / standard / deep). State which steps the
depth requires — light = a leaner pass, standard/deep = all steps — and record `depth`. Show the
matrix as a small text grid if it helps the user see the trade-off.

**single-select** — One AskUserQuestion question; options = `step.options[].label` (strip HTML),
each option's `description` = its `tag` if present (replay: do NOT pre-reveal which is `correct`).
After the pick — replay: say whether it matches the `correct` option and show `why`; dynamic: just
record it. If the step is multi (`multi`/`allowCustom`), set `multiSelect: true` and rely on the
picker's write-in for custom options.

**sort-bins** — Each chip is one question; options = the `bins[].label`. Batch up to 4 chips per
AskUserQuestion call (the tabbed multi-question form). Replay: after all chips, note which landed in
their authored `bin` and show `why`; commit authored `discoveries`. Dynamic: record each chip→bin
the user chose.

**pair-select** — For each `pairs[]` entry ("A ✕ B"), one question: *"Tension worth a requirement,
or aligned?"* with a second toggle question *"Flag as an open question?"* Batch up to ~4 pairs per
call. Replay: reveal each pair's `type` (conflict ⇒ hidden requirement; aligned ⇒ no requirement)
and its `res`; commit authored `discoveries`; record any open-question flags as `open-question`
pieces. Dynamic: record the tensions the user marked.

**pattern-check** — Each pattern is one question with options **Applies · Doesn't apply · Not sure**
(use `yesLabel`/`noLabel`/`unsureLabel` if set). Batch up to 4 patterns per AskUserQuestion call
(8 patterns → 2 calls). After each answer, reveal the pattern's `shape` and `fix`; a pattern counts
as "applies" if the user said yes, or said unsure AND it `fires`. Show the running count
(`counterLabel: <n>/<total>`). Replay commits the authored `discoveries`.

**ripple** — Reveal `stages[]` one at a time in order (each has `ord` + `text`; `danger` stages are
the alarming ones). After each, offer (text or a small AskUserQuestion) to add a note. Record notes
alongside. Show `why` at the end; replay commits authored `discoveries`.

**multi-select** — One AskUserQuestion question with `multiSelect: true`; options =
`chips[].label`. Replay: the step `need`s N good picks — chips with `good:false` are vanity/decoys
(reveal their `decoyTag` if the user picked one), show `why`, commit authored `discoveries`.
Dynamic: record everything the user selected.

**payoff-matrix** — Print the matrix as a text table: `cols` as headers, each `rows[]` a strategy
with its `cells[].o` payoffs. Then one AskUserQuestion question: pick a strategy row. Replay: the
`dominant:true` row is the strategically sound pick — confirm or show the trade-off via the cell
`tone`s and `okText`/`retryText`, then `why`; commit authored `discoveries`. Dynamic: record the
chosen strategy and have the user justify it.

**order** — Sequence the rollout. Ask iteratively: *"Which comes first?"* then *"Next?"* with the
remaining `items[].label` as options, until ordered (or let the user type the order). Replay: check
against `correct` (the right sequence) and reveal each item's `detail`; show `why`; commit authored
`discoveries`. Dynamic: record the user's order.

**assemble** — No question. Group `pieces` by `cat`. Build the dossier (next section), print the PRD
outline it implies (`doc.heading`, the lead line, then each `sections[]` title with its category's
items), write `gandalf-dossier-<slug>.json`, and tell the user the path. Then hand off.

## The dossier (the export — identical shape to the HTML wizard)

Group `pieces` by category into `byCat`. Write exactly this shape (mirrors `buildDossier` in
`09-react-wizard/src/steps.tsx`):

```json
{
  "gandalf": "react-wizard/1",
  "feature": null,
  "outcome": "<byCat[doc.leadFrom][0] || doc.fallbackLead>",
  "discoveries": { "<cat>": ["<text>", "..."] },
  "prd_outline": [
    { "title": "<assemble section title>", "source": "<section src cat>", "items": ["..."] }
  ],
  "pieces": [{ "id": "...", "text": "...", "cat": "..." }],
  "moves":  [{ "stepId": "...", "type": "..." }]
}
```

`slug` = the feature (or `gandalf`) lowercased, non-alphanumerics → `-`, trimmed, max 40 chars.

## Hand off

After writing the dossier: *"That's the discovery tray exported. Feed `gandalf-dossier-<slug>.json` to
a Gandalf skill (or say 'help me decide') to weigh options and draft the PRD."* (That points at
**gandalf-decide**.)

## Don't

- Don't fabricate decoy/wrong options in a dynamic session — there is no answer key; the user's real
  picks are the record.
- Don't fill in players, conflicts, strategies, or decisions for the user.
- Don't generate a PRD — this exports the dossier only.
