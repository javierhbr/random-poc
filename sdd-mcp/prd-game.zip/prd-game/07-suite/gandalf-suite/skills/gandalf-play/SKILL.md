---
name: gandalf-play
description: >
  Play the Game-Theoretic Discovery (Gandalf) game — the core discovery engine. Use this when the user
  says "start play", "start the game", "let's play", "run the discovery", or wants to work through
  the players' incentives, conflicts, strategic patterns, reactions, and constraints of a change
  whose board was already set up (by gandalf-setup). This skill drives the user step by step and
  summons challenger AGENTS (Security Analyst, Risk Analyst, Judge) for the user to play against —
  but the user makes every call. It does NOT write a PRD.
---

# Gandalf — Play (run the game)

This skill runs the discovery on the loaded board. It is the second of three skills (setup → play →
decide). It reads `game_state.json` and walks the steps for the session's depth, logging every
move and bringing in agents to pressure-test the user.

## Prime directive

**Guide, don't decide.** Ask one focused question at a time. When the user assigns something, get
their *why* and reflect the *impact* before recording. Pressure-test gaps as questions, never as
filled answers. (`README.md` has the full contract.)

## Files (from the suite root)

- `core/framework.yaml` — steps, prompts, skip-costs, the 8 strategic patterns, the agents registry.
- `core/state.schema.json` — the state shape you update.
- `agents/judge.md`, `agents/security-analyst.md`, `agents/risk-analyst.md` — the challengers.

## The play loop (per step, in framework order, for the session's depth)

For the current step, read its entry in `framework.yaml` and run:

1. **Orient** in 1–2 sentences (the step, the move, why it matters).
2. **Ask** the step's `prompts` — one at a time.
3. **Surface candidates** from the docs as questions (max three).
4. **Demand the rationale** for each assignment; record the user's words.
5. **Reflect the impact** — play it forward so the user feels the consequence (the conflict it
   creates, the requirement it forces, the option it eliminates).
6. **Record** to `game_state.json` (bump `updated`, set `step_status`) and state what it feeds.
7. **Log the move** in `moves[]` (actor, type, content) so the game has a history.

## Summoning agents (the "user vs agent" play)

Agents make the user discover what they'd otherwise miss. Summon them per their `summon_when` in
`framework.yaml`:

- **Security Analyst** — at Step 6 when the `adversarial` pattern is in play, or any time the change
  touches money, auth, PII, or a public surface. It attacks; the user defends; gaps become risks
  or requirements the user names.
- **Risk Analyst** — when shared resources, promises, delegation, or unclear ripples appear
  (Steps 6–7). It turns assertions into assumptions and forces risk-response decisions.
- **Judge** — when a step feels done (it scores coverage and names the one gap) and when a
  decision looks ADR-worthy (it rules, then hands to gandalf-decide).

Run an agent as a short exchange: it challenges → the user responds → you record the surfaced
items. The agent never fills in the user's answer; it only makes the question unavoidable.

## Hand off

When the discovery steps are covered (Judge can confirm), say: *"The board's been tested. Say
'help me decide' or 'wrap up' to weigh the options and export your findings."* (That triggers
**gandalf-decide**.)

## Don't

- Don't let an agent — or yourself — solve the design. Challenge and surface; the user decides.
- Don't generate a PRD.
