# Gandalf Suite — Game-Theoretic Discovery

A small toolkit that helps a person *play out* a proposed software change as a strategic game —
discovering the players, incentives, conflicts, risks, assumptions, and decisions a feature-list
PRD would miss. It is built so the **user does the thinking**; the tools guide, challenge, and
record.

**It does not write your PRD.** It produces a *dossier* of organized findings. You take that into
whatever PRD tool you like and write the document yourself.

## The pieces

```
gandalf-suite/
├── core/
│   ├── framework.yaml        # the rulebook (YAML): depth gate, players, 8 patterns, steps,
│   │                         #   agents registry, ADR triggers, dossier map
│   ├── state.schema.json     # the game state (JSON): board, moves log, decisions, risks…
│   └── state.example.json    # a partial IVR-payment example
├── skills/
│   ├── gandalf-setup/SKILL.md   # 1 · load sources, set depth, identify the board
│   ├── gandalf-play/SKILL.md    # 2 · run the game, summon agents, drive discovery
│   ├── gandalf-decide/SKILL.md  # 3 · weigh options, capture ADR stubs, export the dossier
│   └── gandalf-wizard/SKILL.md  # alt · play the game wizard config step-by-step in the terminal
└── agents/
    ├── judge.md              # neutral referee — scores coverage, rules on ADRs & readiness
    ├── security-analyst.md   # adversary — attacks the design to surface abuse cases
    └── risk-analyst.md       # worrier — exposes assumptions, ripples, risk-acceptance calls
```

**Why YAML for the rulebook and JSON for the state:** the rulebook is human-edited and rarely
changes, so YAML's readability wins. The state accumulates large free-text blocks — rationales and
a move-by-move game log — and gets read/written programmatically, so JSON (validated by
`state.schema.json`) is the better fit.

## The flow

```
gandalf-setup  →  gandalf-play  →  gandalf-decide  →  discovery-dossier.md + game_state.json
  (load)        (play)         (decide)          (your PRD raw material)
```

1. **Setup** reads your docs, confirms the requirement (e.g. *"make a payment"*), sets the depth
   with you, and leads you to identify the players.
2. **Play** walks the steps and brings in **agents you play against** — the Security Analyst
   attacks, the Risk Analyst surfaces assumptions, the Judge keeps it honest. You defend; the gaps
   become your discoveries.
3. **Decide** helps you weigh options (it may *recommend*, but you choose), records decisions as
   lightweight ADR stubs (what / why / options — nothing deeper), logs risks and assumptions, and
   exports the dossier.

## The two rules that make it work

- **Guide, don't decide.** Setup and Play never fill in your analysis; they surface candidates as
  questions and make you state the *why*. Decide may recommend a move, but you make and own the
  call, and your rationale is what gets recorded. The point is that you can *defend* the result.
- **ADR stubs stay shallow.** When a decision is hard to reverse, sets a contract, accepts a real
  risk, touches many players, or is genuinely contested, it gets an ADR stub: the decision, the
  why, and the options considered. The implementing team elaborates the rest. The game captures the
  *what*, not the deep design.

## Using it

Install the three skills (each `skills/*/` folder is a skill). Keep `core/` and `agents/`
alongside so the skills can read them. Then just talk:

- *"Set up a Gandalf game from ./docs — the feature is taking payments in the IVR."* → **setup**
- *"Start play."* → **play** (agents join in)
- *"Help me decide on the capture approach."* / *"Is this ADR-worthy?"* → **decide**
- *"Wrap up and export the findings."* → **decide** writes the dossier

The output is `discovery-dossier.md` (organized findings + ADR stubs + risks) and the final
`game_state.json`. Neither is a PRD — they're what you build one *from*.

## Alternative front-ends: the wizard

The discovery can also be played as a **wizard** — a fixed sequence of typed steps over a
`Gandalf_CONFIG` (the JSON the wizard consumes) — instead of the open-ended setup → play → decide
flow. There are two front-ends over that one data contract:

- **In a browser** — `wizard/gandalf-game-configurable.html` renders any `Gandalf_CONFIG`. Open it,
  click **load config**, and pick a JSON — or serve it and use `?config=<url>`. A built-in IVR
  sample loads by default.
- **In the terminal** — the **gandalf-wizard** skill plays the same `Gandalf_CONFIG` step-by-step in
  chat, using the question picker, keeping the same discovery tray, and exporting the same dossier.
  It defaults to faithful **replay** of an authored config (bundled `skills/gandalf-wizard/configs/
  ivr-sample.json`) and can also run **dynamic** on the user's own feature.

Feeding either: **gandalf-export-wizard** (skill) turns a played `game_state.json` into a
`gandalf.config.json` (validated against `core/wizard.config.schema.json`).

Generated wizards are a faithful **replay** of the user's own choices (no fabricated decoys); the
built-in sample is the one authored teaching quiz.
