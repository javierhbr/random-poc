# The Game-Theoretic Discovery Framework (Gandalf) v2

### A walkable method for turning a feature request into a good decision

Gandalf treats a product change the way game theory treats a strategic situation: a set of players who each want different things, whose choices react to one another, playing out over many future rounds. The job of discovery is to read that situation correctly **before** committing, so you uncover hidden requirements, hidden costs, and hidden risks while they are still cheap to fix.

This version fixes four weaknesses in the original draft. It (1) uses real game-theoretic *structures*, not just the vocabulary; (2) carries one example end to end; (3) scales effort to the size of the decision so it never becomes busywork; and (4) is honest about what is borrowed and what is new.

---

## The one rule

**Go top to bottom. Do not skip a step. Each step's answer is the input to the next one.**

This is the whole discipline. A missing player changes the incentives. Missing incentives hide a requirement. A missed requirement changes the strategy. The wrong strategy changes the risk and the outcome. The steps are a chain, and a chain skips no links. To make that visible, every step below tells you exactly **what it feeds** and **what breaks if you skip it.**

The framework has two engines running underneath:

- **A discovery engine** — finds what you are missing (players, incentives, second-order effects).
- **A decision engine** — chooses well among the options you found (trade-offs, reactions, reversibility).

Game theory feeds both.

---

## Step 0 — Set the depth (30 seconds)

Not every change deserves the full walk. Decide the depth with two questions, then **never shorten below what this gate tells you.** The gate is deliberately conservative: it only lets you go light when the change is genuinely small and genuinely undoable.

| | **Reversible** (undo is cheap) | **Irreversible** (undo is costly or impossible) |
|---|---|---|
| **Narrow** (1–2 players touched) | **Light** — Steps 1, 2, 3, 5, 10, 11 | **Standard** — all steps |
| **Wide** (3+ players, or a shared/public surface) | **Standard** — all steps | **Deep** — all steps + full Pattern Check + payoff matrix + ADR |

If you are unsure which box you are in, **go one level deeper.** Underestimating blast radius is the most common and most expensive mistake this gate exists to prevent.

> **Worked example starts here.** Throughout, the gray boxes follow one real decision: *"Let any internal team send user notifications through a new shared Notifications service."* It touches many teams, exposes a shared surface, and is hard to walk back once teams depend on it → **Deep.**

---

## Step 1 — Outcome (not feature)

**Question:** What *state change* do we actually want? Describe the world after, not the thing to build.

A feature is already a proposed solution; stating it too early hides every alternative. Describe the outcome and the option space stays open.

- ❌ "Build a notifications service."
- ✅ "Any team can reliably reach a user with a timely, relevant message, without each team rebuilding delivery, and without users being overwhelmed."

**Feeds:** every later step — this is the yardstick you measure strategies against.
**If you skip it:** you optimize the first solution someone named instead of the problem, and you can't tell later which option is actually better.

> **Example — Outcome:** Teams reach users reliably; no duplicated delivery code; users aren't flooded.

---

## Step 2 — Players (everyone, including the ones who can't speak)

**Question:** Who is affected, and who will *react*? List four kinds:

- **Human** — users, the requesting team, support, on-call.
- **Technical** — services, databases, queues, the delivery channel (email/push/SMS providers).
- **Organizational** — security, SRE, finance/cost owners, legal/compliance, vendors.
- **Future** — future consumers (analytics, AI, reporting), future maintainers, the next teams who'll adopt this.

A "player" here means *any actor whose incentives or constraints shape the outcome* — even a database, whose consistency rules constrain you, or a future team you've never met, whose needs you'll either enable or block.

**Feeds:** Steps 3, 7 (you can only analyze incentives and reactions for players you've named).
**If you skip a player:** they surface later as the incident, the blocked launch, or the emergency redesign. Hidden players are where surprises live.

> **Example — Players:** users; every sending team; the notifications team (owner); the email/push vendor; SRE; security (it's a channel to users → phishing/abuse surface); finance (per-message cost); legal (consent/opt-out); future consumers (a digest feature, an AI summarizer).

---

## Step 3 — Incentives, and where they collide

**Question:** What does each player optimize? Then **circle every pair that conflicts.**

Each player maximizes its own payoff: users want fewer interruptions; sending teams want to send more; SRE wants stability; finance wants low cost; security wants a small abuse surface. The conflicts are not noise — **each conflict is a hidden requirement you'd otherwise discover in production.**

**Feeds:** Step 5 (conflicts define what a good strategy must reconcile) and Step 9 (they become the columns of your trade-off table).
**If you skip it:** you build for the requester's incentive only and quietly violate everyone else's.

> **Example — Conflicts found:** *sending teams (send more) vs. users (be left alone)* → requires per-user rate limiting and preferences. *Teams (just ship it) vs. finance (cost)* → requires per-team cost visibility. *Teams vs. security (abuse)* → requires content/recipient controls. Three requirements no one wrote down, surfaced purely from incentive collision.

---

## Step 4 — Current equilibrium (why is it like this?)

**Question:** Why does the system behave the way it does today, and what is holding that in place?

An **equilibrium** is a state no player wants to unilaterally leave. Today, every team sends its own notifications because, for each team alone, that was the cheapest move. That is a stable state, and it is stable *for a reason.* Two consequences:

1. **Chesterton's fence.** Don't remove the current arrangement until you understand why it exists, or you'll reintroduce the problem it was quietly solving.
2. **Equilibria fight back.** If your new design isn't *also* an equilibrium — if a team is better off going around it — teams will route around it, revert to their own sender, and you'll be left maintaining a service no one uses. **A solution that isn't an equilibrium doesn't hold.**

**Feeds:** Step 6 (several patterns are about whether your new state is stable) and Step 10 (you may need to make the old path harder, not just the new one easier).
**If you skip it:** you ship a "correct" design that everyone bypasses.

> **Example — Equilibrium:** Teams self-send because adopting anything shared has a switching cost. So the new service must be *easier than the status quo*, or adoption stalls. This is already a design constraint, discovered before any code.

---

## Step 5 — Options (at least two, always)

**Question:** What are the genuinely different strategies for reaching the outcome?

One option is not a decision; it's a foregone conclusion wearing a decision's clothes. Force at least two structurally different approaches.

> **Example — Options:** (A) a synchronous send API; (B) teams publish events, the service decides delivery; (C) a thin shared library, no central service. Each trades control, coupling, and adoption cost differently.

**Feeds:** Steps 6–9, which you run against these options.
**If you skip it:** you can't see what you're giving up, because there's nothing to compare against.

---

## Step 6 — Strategic Pattern Check ⟵ the engine

**This is the step that makes Gandalf game-theoretic rather than just stakeholder analysis.** Software keeps reproducing a small set of strategic structures that game theory already mapped and already has answers for. You don't solve any equations. You run a **yes/no trigger list.** Each "yes" pulls in a few sharp questions *and a set of known moves you'd otherwise have to learn the hard way.* That is the payoff: pattern recognition lets you inherit decades of solutions.

Run all eight. Answer each in one breath.

| # | Trigger — answer yes/no | The structure (real concept) | If yes, you must… | Known moves to reach for |
|---|---|---|---|---|
| 1 | Could a player **benefit from misusing this**, and will they see your defenses before acting? | Adversarial / **Stackelberg** game — they move *after* observing you | Assume your control is visible and probed at its weakest point | Threat-model the abuse case; rate-limit; validate recipients/content; assume the posture is known |
| 2 | Is a **shared resource** consumed by many players each acting locally? | **Tragedy of the commons** | Expect individually-rational overuse to degrade it for all | Quotas, per-consumer cost/visibility, priority tiers, an owner with authority to throttle |
| 3 | Are you **delegating** behavior to a party whose incentives differ from yours? | **Principal–agent** | Expect drift toward *their* incentive, not yours | Align incentives, monitor usage, encode expectations as enforced contracts/SLAs |
| 4 | Must **many teams converge** on one choice (format, standard, schema)? | **Coordination game / Schelling point** | Expect fragmentation unless a default is obvious early | Pick and publicize *one* default fast; ship the reference path; first mover sets the focal point |
| 5 | Are you **making a promise** others will build on (uptime, compatibility, "we won't change X")? | **Credible commitment** | A promise only shapes behavior if it's believed — and breakable promises get ignored | Versioning, explicit deprecation policy, make reneging visible and costly to yourself |
| 6 | Will you interact with these **same players repeatedly** over future work? | **Repeated game** | The one-shot-optimal hack loses to the cooperative move over many rounds | Pay the small cost now (clean interface, honored contract); reputation compounds across the next fifty features |
| 7 | Does **one side know more** than the other (you about limits, them about their use)? | **Information asymmetry / signaling** | Expect bad decisions on the uninformed side | Surface the hidden info: docs, quotas-as-signals, usage dashboards, clear error semantics |
| 8 | Are **you the one setting the rules** (you own the platform/API)? | **Mechanism design** (reverse game theory) | You can shape the rules so others' self-interest produces *your* desired outcome | Design defaults, limits, and pricing so the easy path is also the safe path |

**Feeds:** Steps 7, 8, 9 — each fired pattern adds reactions to predict, constraints to honor, and trade-offs to weigh.
**If you skip it:** you rediscover these structures as outages and abuse reports. This is the step that earns the word "game-theoretic."

> **Example — Patterns that fire (6 of 8):**
> - **#1 Adversarial:** a channel to users invites phishing/spam → recipient + content controls, assume probing.
> - **#2 Commons:** one shared send-budget and one vendor quota → per-team quotas + usage visibility or one team starves the rest.
> - **#3 Principal–agent:** you run delivery, teams just want their message out → enforce limits in the platform, don't trust callers.
> - **#4 Coordination:** every team needs a message format → publish one schema + reference client *before* opening the door.
> - **#5 Commitment:** teams will depend on your delivery SLA → version the API, state a deprecation policy up front.
> - **#6 Repeated:** the same teams forever → invest in the clean event interface now rather than the quick sync hack.
>
> Six structural risks, each with a known countermeasure, found before line one of code. *That* is the engine's value — and none of it required solving a game formally.

---

## Step 7 — Reactions and ripple

**Question:** For each player, what is their **best response** to your move? Then trace the consequences outward.

This is best-response reasoning made practical: don't ask "what do I want to happen," ask "what will each player *do* once this exists, acting in their own interest." Then follow the orders of effect:

- **First-order:** the direct change.
- **Second-order:** what that forces elsewhere.
- **Third-order:** what *those* changes trigger.

Most failures live in the second and third order.

**Feeds:** Step 9 (reactions are costs/benefits) and Step 10 (some ripples must be rolled out gradually).
**If you skip it:** you account for your move and none of the moves it provokes.

> **Example — Ripple:** *First:* a shared send API exists. *Second:* teams migrate and start sending more because it's now easy → user notification volume spikes. *Third:* users hit fatigue and disable notifications wholesale → the channel's value collapses for *everyone*, including critical alerts. Mitigation surfaces immediately: per-user frequency caps and a priority tier for critical messages — a requirement invisible at Step 1.

---

## Step 8 — Constraints

**Question:** What hard boundaries shape the design? Performance, security, compliance/consent, cost ceilings, vendor limits, data residency.

Constraints aren't obstacles to note and move past — they often *determine* the architecture.

**Feeds:** Step 9 (an option that violates a hard constraint is eliminated, not traded off).
**If you skip it:** you choose an option that's illegal, unaffordable, or technically impossible, and find out late.

> **Example — Constraints:** legal consent + one-click opt-out (compliance); vendor caps N messages/sec (throughput); per-message cost (budget). Option (A)'s naive synchronous send can't honor the vendor rate cap cleanly → constraint eliminates it in favor of a queued/event approach.

---

## Step 9 — Decide

**Question:** Given everything above, which option wins — and why?

Build a **trade-off table**: options as rows, the things players care about (from Steps 3, 6, 7, 8) as columns. Mark each cell benefit / cost / blocked.

For **Deep** decisions where two players' choices genuinely interact, also build a small **payoff matrix** — *your* move down the side, the *other player's* response across the top, the outcome in each cell. (This is the real tool the original draft mislabeled: it shows the *interaction*, not just a list of pros and cons.)

If the decision is irreversible, **record it as an ADR**: context, options considered, decision, consequences. The ADR is the memory of *why*, so the next person doesn't relitigate or accidentally undo it.

**Feeds:** Steps 10 and 11.
**If you skip it:** the choice is made implicitly, undocumented, and impossible to revisit deliberately.

> **Example — Decision:** Option (B), event-driven, with the platform enforcing quotas, per-user caps, and a published schema. A payoff matrix makes the key interaction explicit:
>
> | Platform choice ↓ \ Teams will… → | Send responsibly | Over-send |
> |---|---|---|
> | **Enforce quotas + caps** | Healthy channel | Channel protected; teams adapt |
> | **Trust teams (no enforcement)** | Healthy channel | Channel collapses (fatigue) |
>
> Enforcing is the **dominant** choice — it's at least as good no matter what teams do, and strictly better if any team over-sends. Recorded as an ADR.

---

## Step 10 — Roll out so you can change your mind

**Question:** How do we move toward this in **reversible** steps?

Irreversible big-bang changes remove your ability to react to what you learn. Reach for: tracer bullets (one thin path end to end), feature flags, shadow mode (run it without effects, compare), canary (small slice first), and — recalling Step 4 — a plan to make the *old* path gradually less attractive so the new equilibrium actually holds.

**Feeds:** Step 11 (each stage is a place to read metrics).
**If you skip it:** you bet everything on being right the first time.

> **Example — Rollout:** shadow-mode (mirror existing sends, compare) → one pilot team behind a flag → canary to 5% of users → general availability, with self-send deprecated on a published date so teams don't drift back.

---

## Step 11 — Metrics

**Question:** What numbers tell us this worked — or warn us early that it didn't?

Tie each metric back to the Step 1 outcome and the Step 3 incentives, so you're measuring the thing you meant, not the thing that's easy.

**Feeds:** the next decision — outcomes become the equilibrium the *next* feature inherits. The game repeats.
**If you skip it:** you can't tell success from motion, and you can't learn for next time.

> **Example — Metrics:** adoption (teams migrated), delivery reliability, **user opt-out rate** (the early-warning signal for fatigue), per-team cost, abuse reports caught. The opt-out metric exists only because Step 7 predicted the fatigue ripple.

---

## How this relates to spec-driven development

Gandalf is the **reasoning layer that runs before specs**, not a replacement for them.

```
Idea → Gandalf (understand the game) → PRD → ADR → Functional Spec → Tasks → Build → Validate
```

Specs say *what* to build. Gandalf says *why this and not the alternatives*, *who it affects*, and *what will react.* It hands the spec a defended decision instead of an assumed one.

---

## What's borrowed and what's new (honest positioning)

Gandalf is a **synthesis**, and says so:

- From **game theory**: the structures — equilibrium, best response, Stackelberg/adversarial, commons, principal–agent, coordination, commitment, repeated games, mechanism design.
- From **stakeholder analysis & premortems**: name everyone affected; imagine the failure early.
- From **ADRs & systems thinking**: record decisions; trace higher-order effects and feedback loops.

The **new contribution** is the *Pattern Check engine* (Step 6): a trigger list that maps an ordinary product change onto a known strategic structure and hands you that structure's inherited solutions — plus the *proportionality gate* (Step 0) that keeps the method from collapsing into busywork. The contribution isn't a new theory; it's making real strategic structure **usable by someone who has never taken a game theory course**, as a linear walk they can't accidentally shortcut.

## How to validate it (instead of trusting it)

Don't take the framework's word for it, and don't trust retrofitted success stories. **Back-test it:** take a real past incident or painful redesign your team already lived through, and run Gandalf against the state *before* that decision. If Step 2, 3, 6, or 7 would have surfaced the thing that actually bit you, that's real evidence. If it wouldn't have, the framework has a gap worth fixing. One honest back-test is worth ten just-so stories.

---

## The one-page checklist

Run top to bottom. Don't skip. Each answer feeds the next.

- **0. Depth** — reversible? wide? → Light / Standard / Deep. *Unsure → go deeper.*
- **1. Outcome** — the state change, not the feature.
- **2. Players** — human, technical, organizational, future. Who *reacts*?
- **3. Incentives** — what each optimizes; **circle the conflicts** (= hidden requirements).
- **4. Equilibrium** — why is it like this? Will my new state actually *hold*?
- **5. Options** — at least two, structurally different.
- **6. Pattern Check** — run all 8 triggers; each "yes" adds questions + known moves.
- **7. Reactions & ripple** — best response per player; 1st/2nd/3rd-order effects.
- **8. Constraints** — performance, security, compliance, cost, vendor.
- **9. Decide** — trade-off table (+ payoff matrix if Deep); ADR if irreversible.
- **10. Rollout** — tracer / flag / shadow / canary; retire the old path.
- **11. Metrics** — tied to the outcome and the incentives.

> *The goal isn't a bigger PRD. It's a better decision — and one you can see the reasoning behind.*
