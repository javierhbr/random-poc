# Game Theory for Product Discovery

### Using the logic of strategic decisions to write better Product Requirement Documents

**Who this paper is for.** Anyone who helps decide what software gets built — a junior intern reading their first spec, a product owner shaping a roadmap, or a senior engineer designing a system. No mathematics and no prior knowledge of game theory are required. Every term is explained in plain language the first time it appears.

**What you will get.** First, a gentle explanation of what game theory actually is. Then, why the usual way of writing requirements quietly fails on large systems. Finally, a step-by-step framework you can follow from top to bottom — where every step says what it is, why it exists, and whether you can skip it.

---

# Part I — What is Game Theory?

## The everyday idea

Imagine you are deciding what time to leave for the airport. If you were the only car on the road, the answer would be simple arithmetic. But you are not alone. Thousands of other drivers are making the same decision at the same time, and the traffic you hit depends on *their* choices, not just yours. Your best decision depends on what everyone else decides.

That is the entire idea behind game theory: **it is the study of situations where your outcome depends not only on what you do, but on what others do too.**

The word "game" is unfortunate, because it sounds like entertainment. In this field, a "game" simply means *any situation where several decision-makers affect one another.* A price war between two shops is a game. Two countries negotiating a treaty is a game. Three teams sharing one database is a game. None of these are fun, but all of them have the same shape: several actors, each with their own goals, whose decisions tangle together.

Game theory gives us a vocabulary for thinking clearly about these tangled situations. Let's build that vocabulary one word at a time. Each one is simple on its own.

## The building blocks

**A player** is anyone whose choices affect the outcome. On the road, every other driver is a player. In a company, players might be customers, teams, managers, or even a vendor you depend on. A player doesn't have to be a person — anything that "behaves" and shapes the result counts.

**A strategy** is simply one of the options a player can choose. "Leave at 6 a.m." and "leave at 7 a.m." are two strategies. Game theory's first piece of advice is almost embarrassingly simple: *write down more than one strategy before you choose.* Most bad decisions come from treating the first idea as the only idea.

**A payoff** is what a player gains or loses from an outcome. Crucially, payoffs are not only money. They can be time, safety, reputation, convenience, or stress. The airport traveler's payoff is "catch the flight without wasting three hours waiting at the gate." Every option has both gains and costs, and a payoff is just the honest tally of both.

**An incentive** is what a player is trying to maximize — the thing they care about most. The traveler's incentive is reliability. A shop's incentive might be profit. A safety inspector's incentive is avoiding disasters. Here is the key insight that runs through this entire paper: **different players have different incentives, so they naturally pull in different directions.** Those conflicts are not a problem to hide. They are information. They tell you what a good solution must balance.

**A reaction** (game theorists call it a *best response*) is the move a player will make once they see what everyone else is doing. The right question is rarely "what do I want to happen?" It is "what will each player *actually do*, in their own interest, once my decision exists?" People and systems react, and those reactions are often where plans go wrong.

## The most useful idea: equilibrium

Now the single most valuable concept. An **equilibrium** is a stable situation that *no one wants to walk away from on their own.*

The cleanest example is which side of the road we drive on. In most countries, everyone drives on the right. Why does this hold so firmly? Because if you alone decided to drive on the left, you would crash. No single driver benefits from switching, so the arrangement stays put. That is an equilibrium: a state held in place by everyone's self-interest.

This idea is powerful for two reasons.

First, it explains **why things are the way they are.** When you find a system behaving in some strange, inconvenient way, it is usually sitting in an equilibrium — held there by reasons that may not be obvious. Before you "fix" it, you should understand what is holding it in place, or you may bring back the very problem it was quietly solving.

Second, it tells you **whether your change will actually stick.** If you introduce something new but people are better off ignoring it and going back to the old way, they will. Your change has to become a *new* stable state — a new equilibrium — or it quietly unravels. We will return to this idea many times, because in software it is the difference between a solution that lasts and one that everyone routes around.

## You meet the same people again

One more idea, because it changes how cooperation works. A **repeated game** is one where the same players interact over and over, rather than just once.

If you will never see someone again, the tempting move is to grab the best short-term outcome for yourself, even at their expense. But if you will deal with the same people repeatedly — coworkers, neighboring teams, a long-term vendor — then your reputation matters. Cooperating, keeping promises, and not cutting corners pays off across all the future interactions, even when cheating would win this one round. Most work inside a company is a repeated game. You will depend on the same teams for the next fifty projects, so the "cheap hack today" usually loses to the "clean choice today."

## A few named situations worth recognizing

Game theory has catalogued certain *shapes* of strategic situations that show up again and again. You don't need to memorize these — later, the framework will point them out for you — but a quick tour makes them familiar. Each comes with an everyday example.

- **An adversarial situation.** Someone benefits from working against you, and they get to see your defenses before they act. A burglar studies your locks and picks the weakest door. The lesson: assume your defense is visible and will be probed at its weakest point.

- **A shared resource ("the commons").** Many people draw from one shared thing, and each, acting reasonably for themselves, can ruin it for everyone. Think of a shared office fridge that no one cleans, or a fishing ground that gets over-fished. The lesson: shared things need limits and an owner, or they degrade.

- **A coordination problem.** Several people need to converge on the *same* choice, and it matters less *which* choice than that everyone picks the same one. If friends agree to "meet at the big clock," they find each other; without an obvious meeting point, they scatter. The lesson: pick an obvious default early and make it visible.

- **A promise (commitment).** A promise only changes behavior if people believe you will keep it. A store's "we'll match any lower price" only shapes shopping behavior if customers trust it's real. The lesson: promises others build on must be credible, which means breaking them has to be costly to *you*.

- **Delegating to someone with different goals.** You hire a contractor: you want quality, they want to finish quickly. Their incentives differ from yours, so left alone, things drift toward *their* goal. The lesson: align incentives, watch what's happening, and write down expectations.

- **Designing the rules ("mechanism design").** Sometimes *you* get to set the rules of the game, and you can design them so that everyone acting selfishly still produces a good result. The timeless example: to split a cake fairly between two children, let one cut and the other choose the piece. The cutter is now motivated, by pure self-interest, to cut evenly. The lesson: when you own the rules, design them so the easy path is also the good path.

That's the whole toolkit. Players, strategies, payoffs, incentives, reactions, equilibrium, repeated games, and a handful of recognizable shapes. Nothing here required math — just the habit of asking, *"who else is in this situation, what do they want, and how will they respond?"*

## Why this matters for software

A small program that runs alone is just arithmetic: input in, output out. But modern software is never alone. It runs alongside other services, shared databases, multiple teams, security rules, cost budgets, outside vendors, and future features that don't exist yet. Each of these has its own "incentive," reacts to changes, and sits in some equilibrium.

In other words, **a large software system is not a machine — it is a game.** Every change is a strategic move with consequences that ripple outward to other players. And if that's true, then the document we use to plan changes should be built to think about a game, not just to list features. That document is the PRD, and that is where we turn next.

---

# Part II — The Problem with How We Plan Software

## What a PRD is, and what it's supposed to do

A **PRD** — Product Requirement Document — is the document that describes a change before anyone builds it. It is where a team writes down what they want, for whom, and why. It is meant to be the bridge between an idea and the work of building it.

Most PRDs are written as a **feature list**: a description of what the user asked for and what the team intends to build. This works fine when the software is small and isolated. The trouble is that almost no important software is small and isolated.

## Why the feature list quietly fails

A traditional PRD assumes a simple, tidy path:

```
User request  →  Requirements  →  Build it
```

This picture leaves out everything that makes large systems hard. It says nothing about the other teams who share the same database, the security rules the change has to respect, the costs it will add, the services that will suddenly need to react, or the future features that will depend on the decision. The feature the user asked for is often only a small slice of the real problem.

This is exactly why so many projects run into trouble *late*: the outage, the blocked launch, the emergency redesign, the "wait, this breaks the mobile app." None of these were in the feature list. They were in the *interactions* the feature list ignored. The information was discoverable from the start — it was just never looked for.

The honest summary is this: **traditional PRDs describe a feature. Complex systems require you to understand a game.** A feature list captures *what we want to build*. It does not capture *who else is affected, what they want, how they'll react, and what it will cost downstream.*

## What good discovery should actually answer

The "discovery phase" is the thinking you do *before* committing to a design — the part where you figure out what you're really dealing with. Done well, it answers questions a feature list never asks:

- What outcome do we actually want (not which feature was requested)?
- Who is affected, including the people and systems that can't speak up for themselves?
- Who benefits, and who quietly pays the cost?
- What depends on this, and what will react to it?
- What future capabilities does this help or block?

Notice that these are exactly the game-theory questions from Part I — players, incentives, reactions, downstream effects — just pointed at a software change. That is the whole bet of this paper: **if we run discovery like we're reading a strategic situation, we surface the hidden requirements and hidden risks while they are still cheap to fix.** The framework in Part III is simply a reliable, repeatable way to do that.

---

# Part III — The Framework (Gandalf) Applied to PRD

The **Game-Theoretic Discovery Framework (Gandalf)** turns the ideas from Part I into a checklist you walk through during discovery. The output is not a finished specification. The output is a *well-understood decision*: a clear PRD, the trade-offs you weighed, the architectural choices you made and why, and a plan to roll it out safely.

## The one rule

**Go top to bottom. Don't skip a step. Each step's answer is the input to the next one.**

This is the heart of the method, and it's worth saying plainly *why* skipping is dangerous. The steps form a chain. A player you forgot to list changes the set of incentives. An incentive you missed hides a requirement. A missing requirement points you at the wrong strategy. The wrong strategy changes the risk and the final outcome. Every omission silently changes the answer. So each step below tells you what it **feeds** (where its answer is used next) and what **breaks if you skip it.**

Two engines run quietly underneath the whole walk:

- A **discovery engine** that finds what you're missing — forgotten players, conflicting incentives, second-order effects.
- A **decision engine** that helps you choose well among the options you found — weighing trade-offs and reactions, and rolling out reversibly.

## A note on "required" vs. "optional"

You'll see each step marked as **Core**, **Recommended**, or **Situational**. But how much rigor *your* change needs depends on how risky it is. So before the steps, there's a 30-second sorting question that tells you how deep to go. That keeps the framework honest: a tiny, reversible tweak shouldn't carry the same weight as rebuilding your payment system.

---

## Step 0 — Decide how deep to go

**What it is.** A quick sort, before you start, based on two questions: *Can we undo this cheaply?* and *How many players does it touch?*

| | **Reversible** (easy to undo) | **Irreversible** (hard or costly to undo) |
|---|---|---|
| **Narrow** (1–2 players) | **Light** — just the core steps | **Standard** — all steps |
| **Wide** (3+ players, or a shared/public surface) | **Standard** — all steps | **Deep** — every step, fully |

**Why we need it.** Without this, the framework either feels like overkill on small changes (and people abandon it) or gets rushed on big ones (and people get hurt). This step matches the effort to the stakes.

**Required or optional?** Core. It takes thirty seconds and it decides everything after it. **If you're unsure which box you're in, choose the deeper one** — underestimating how far a change reaches is the most common and most expensive mistake.

> **Running example.** Throughout Part III we'll follow one change: *"Let users add comments to a task."* It sounds tiny, but it touches many players (notifications, search, mobile, moderation) and creates a shared surface others will build on — so it lands in **Standard**, leaning **Deep**.

---

## Step 1 — Name the outcome (not the feature)

**What it is.** A description of the *change in the world* you want — the state after — rather than the thing someone asked you to build.

**Why we need it.** A feature is already a solution in disguise, and naming it too early throws away every alternative before you've considered them. Describe the outcome and the options stay open.

> ❌ "Add a comments box to tasks."
> ✅ "Let people attach discussion and context to a task, so the conversation lives with the work instead of scattered across chat and email."

**Required or optional?** Core, always. This is the yardstick every later step measures against.

**Feeds:** every step after it. **If you skip it:** you optimize the first idea anyone named, and later you can't tell which option is actually better, because you never defined "better."

---

## Step 2 — List the players

**What it is.** Everyone and everything affected by the change, or that will react to it. Look in four places so you don't miss the quiet ones:

- **People** — users, the requesting team, support, the on-call engineer.
- **Technical** — services, databases, the mobile app, search, queues.
- **Organizational** — security, reliability (SRE), finance/cost owners, legal, vendors.
- **Future** — features that don't exist yet (analytics, AI, reporting) and the engineers who'll maintain this later.

A "player" is *anything whose goals or limits shape the result* — even a database (whose rules constrain you) or a future team (whose needs you'll enable or block).

**Why we need it.** The players you forget are exactly where surprises come from. A hidden player doesn't disappear; it reappears later as the incident or the blocked launch.

**Required or optional?** Core, always.

**Feeds:** Steps 3 and 7 — you can only reason about incentives and reactions for players you've actually named. **If you skip a player:** every later step is blind to them.

> **Example — players for comments:** users; the product team; the mobile app; **search** (will someone want to find tasks by comment text?); the **notifications** system (a comment probably pings someone); **moderation/trust** (comments can carry spam or abuse); a possible future **AI summarizer**. Several of these no one mentioned in the original request.

---

## Step 3 — Find the incentives, and circle the conflicts

**What it is.** What each player is trying to optimize — and then, the important part, marking every pair whose goals **collide.**

**Why we need it.** This is the discovery engine doing its most valuable work. Users want simplicity; search wants structured data; security wants a small abuse surface; finance wants low cost. These goals fight each other, and **each conflict is a hidden requirement you would otherwise have discovered in production.**

**Required or optional?** Core, always. This single step surfaces more missing requirements than any other.

**Feeds:** Step 5 (a good strategy must reconcile the conflicts) and Step 9 (the conflicts become the things you weigh). **If you skip it:** you build for the requester's goal alone and quietly violate everyone else's.

> **Example — conflicts for comments:** users want a clean, simple box, but **search** wants structured, indexable text → you'll need to store comments in a searchable form, not just a blob. Users want freedom, but **moderation** wants control → you'll need a way to flag or remove abuse. Two requirements no one wrote down, found just by noticing whose goals collide.

---

## Step 4 — Understand why it's like this today

**What it is.** An honest look at why the system currently behaves the way it does, and what is holding that in place — the *current equilibrium* from Part I.

**Why we need it.** Two reasons. First, the "don't tear down a fence until you know why it's there" rule: the current arrangement may be quietly solving a problem you can't see, and removing it brings the problem back. Second, equilibria resist change. If your new design leaves any player better off ignoring it, they'll ignore it — and you'll have shipped something everyone routes around.

**Required or optional?** Recommended for most changes; Core for anything replacing existing behavior. For a truly new, isolated feature there may be no current equilibrium to study, which is the one case you can move quickly past it.

**Feeds:** Steps 6 and 10 — knowing what holds the old state in place tells you what your new state must overcome. **If you skip it:** you ship a technically correct design that everyone bypasses, or you reintroduce an old bug.

> **Example — for comments:** today people discuss tasks in chat and email. That's not laziness — chat is *fast and already open*. So a comments feature has to be at least as fast and convenient, or people will keep using chat and the feature will sit empty.

---

## Step 5 — Lay out at least two options

**What it is.** Two or more genuinely different ways to reach the outcome.

**Why we need it.** One option isn't a decision — it's a foregone conclusion. You can't see what you're giving up if there's nothing to compare against. Forcing a second option is how you discover the first one had a cost you hadn't noticed.

**Required or optional?** Core, always. "At least two" is non-negotiable.

**Feeds:** Steps 6 through 9, which you run against these options. **If you skip it:** you can't weigh trade-offs, because there's nothing on the other side of the scale.

> **Example — options for comments:** (A) a simple text field stored as plain text; (B) structured comments with authors, timestamps, and mentions, stored so search can index them; (C) reuse an existing chat system and just link it to the task. Each trades simplicity, searchability, and effort differently.

---

## Step 6 — Run the Strategic Pattern Check ⟵ the part that's truly game-theoretic

**What it is.** A short list of yes/no questions, each one checking whether your change matches one of the recognizable strategic *shapes* from Part I. This is the engine that makes Gandalf more than a stakeholder checklist. **You don't solve anything** — you just answer eight quick questions, and each "yes" hands you a few sharp follow-up questions *and the known ways people have solved that shape before.* That's the payoff: you inherit decades of hard-won answers instead of rediscovering them in an outage.

Run all eight.

| Ask yourself… | The shape it reveals | If yes, reach for… |
|---|---|---|
| 1. Could someone **benefit from misusing this**, and see our defenses first? | An adversarial situation | Assume the defense is visible; threat-model the abuse case; validate and rate-limit inputs |
| 2. Is a **shared resource** used by many, each acting for themselves? | A commons | Quotas, per-user limits, usage visibility, a clear owner |
| 3. Are we **handing behavior to a party with different goals**? | Delegation | Align incentives, monitor, write expectations down as enforced rules |
| 4. Must **many teams agree** on one format or standard? | A coordination problem | Pick and publish one obvious default early; ship a reference example |
| 5. Are we **making a promise** others will build on (uptime, "we won't change X")? | A commitment | Versioning, a clear change/deprecation policy, make breaking it costly to us |
| 6. Will we deal with these **same players again and again**? | A repeated game | Pay the small cost now for the clean choice; reputation compounds over future work |
| 7. Does **one side know more** than the other? | Information asymmetry | Surface the hidden info: docs, dashboards, clear limits and errors |
| 8. Are **we the ones setting the rules**? | Mechanism design | Design defaults and limits so the easy path is also the safe one |

**Why we need it.** Every one of these shapes, if ignored, comes back as a real failure — abuse, an overloaded shared resource, a fragmented mess, a broken promise. Recognizing the shape *before* building lets you apply the known fix. This is where "game-theoretic" stops being a label and starts doing work.

**Required or optional?** Recommended for Standard changes; Core for Deep ones. On a tiny Light-path change you can skim it, but even then the questions take under a minute.

**Feeds:** Steps 7, 8, and 9 — each "yes" adds reactions to expect, constraints to honor, and trade-offs to weigh. **If you skip it:** you'll meet these shapes anyway, just later and more expensively.

> **Example — patterns that fire for comments:**
> - **#1 Adversarial → yes:** comments can carry spam, links, abuse → you need moderation and input limits.
> - **#4 Coordination → yes:** mobile, web, and search all need the same comment format → publish one schema before building clients.
> - **#5 Commitment → yes:** once teams read comment data, its shape is a promise → version it from day one.
> - **#6 Repeated → yes:** you'll maintain this with the same teams for years → store comments cleanly now, not as a quick blob.
>
> Four real risks, each with a known countermeasure, found before writing any code.

---

## Step 7 — Predict reactions and trace the ripple

**What it is.** For each player, the move they'll make *in their own interest* once your change exists — then the chain of consequences that follows. Trace three levels:

- **First-order:** the direct change.
- **Second-order:** what that forces elsewhere.
- **Third-order:** what *those* changes trigger.

**Why we need it.** Most failures don't live in the first-order effect (which everyone sees) but in the second and third (which no one planned for). Asking "what will react?" is how you find them early.

**Required or optional?** Core, always. The ripple is where the expensive surprises hide.

**Feeds:** Step 9 (reactions are real costs and benefits) and Step 10 (some ripples must be rolled out gradually). **If you skip it:** you account for your own move and none of the moves it sets off.

> **Example — ripple for comments:** *First:* people can comment. *Second:* every comment probably fires a **notification** → notification volume jumps. *Third:* users get notification fatigue and mute the task entirely → they stop seeing important updates too. The fix surfaces immediately: batch notifications and let users control them. That requirement was invisible at Step 1 and only appeared by tracing two steps out.

---

## Step 8 — Write down the constraints

**What it is.** The hard boundaries the design must respect: performance, security, legal/compliance, cost ceilings, vendor limits, data rules.

**Why we need it.** Constraints aren't footnotes — they often *decide* the design. An option that violates a hard constraint isn't a worse choice; it's not a choice at all.

**Required or optional?** Core, always.

**Feeds:** Step 9, where any option that breaks a hard constraint is eliminated before you even compare it. **If you skip it:** you might choose something illegal, unaffordable, or technically impossible, and find out after building it.

> **Example — constraints for comments:** abuse reporting may be legally required in some regions (compliance); comment text counts against storage cost (budget); search has a limit on how much text it can index per item (technical). That last one may quietly rule out unlimited comment length.

---

## Step 9 — Make the decision (and record it if it's hard to undo)

**What it is.** Choosing an option, with the reasoning visible. Build a simple **trade-off table**: options down the side, the things players care about across the top, each cell marked benefit, cost, or blocked. For big, interacting decisions, also sketch a tiny **outcome table** — *your* move versus the *other player's* likely response — to see how they interact. If the decision is hard to reverse, write it down as a short **decision record**: what you chose, what else you considered, and the consequences.

**Why we need it.** A decision made in someone's head can't be reviewed, explained, or revisited on purpose. Writing down *why* protects the next person from undoing it by accident or relitigating it from scratch.

**Required or optional?** The trade-off table is Recommended for Standard, Core for Deep. The written decision record is Situational — needed when the choice is expensive to reverse, skippable when it isn't.

**Feeds:** Steps 10 and 11. **If you skip it:** the choice gets made implicitly, undocumented, and impossible to examine later.

> **Example — decision for comments:** choose structured, searchable comments (Option B) with a published format, input limits, and batched notifications — because the trade-off table shows it's the only option that satisfies search, moderation, *and* the future AI summarizer at once. Recorded, because changing the stored format later would be painful.

---

## Step 10 — Roll it out so you can still change your mind

**What it is.** A plan to move toward the chosen design in *reversible* steps rather than all at once. Common tools: a thin end-to-end slice first, on/off switches (feature flags), a "shadow" run that does the work without real effects so you can compare, and a small first audience (a canary) before everyone.

**Why we need it.** A big, all-at-once, irreversible change removes your ability to react to what you learn. Reversible steps turn a risky bet into a series of cheap experiments. (And recall Step 4: you may also need to gently retire the old way, or people drift back to it.)

**Required or optional?** Strongly recommended always; effectively Core for anything wide or irreversible.

**Feeds:** Step 11 — each rollout stage is a place to read the numbers. **If you skip it:** you're betting everything on being right the first time.

> **Example — rollout for comments:** turn it on for one internal team behind a flag → watch the notification volume → expand to 5% of users → general release, with notification batching tuned based on what you saw.

---

## Step 11 — Decide how you'll measure success

**What it is.** The handful of numbers that will tell you it worked — or warn you early that it didn't. Tie each one back to the outcome from Step 1 and the incentives from Step 3.

**Why we need it.** Without metrics, you can't tell success from mere activity, and you can't learn anything for the next decision. The right metric often comes straight from the ripple you traced in Step 7.

**Required or optional?** Core, always.

**Feeds:** the *next* decision — today's outcome becomes the equilibrium the next feature inherits. The game repeats. **If you skip it:** you'll never know whether it worked, and you'll repeat the same mistakes.

> **Example — metrics for comments:** comment adoption, search usage of comment text, and — the early-warning signal — the **notification mute rate**. That last metric exists only because Step 7 predicted the fatigue problem.

---

## How Gandalf fits with the rest of the process

Gandalf is the **thinking layer that runs before the specification**, not a replacement for it:

```
Idea → Gandalf (understand the game) → PRD → Decision records → Detailed spec → Tasks → Build → Measure
```

The specification says *what* to build. Gandalf says *why this option and not the others*, *who it affects*, and *what will react.* It hands the spec a defended decision instead of an assumption.

---

# Part IV — Honesty, Validation, and a Cheat Sheet

## What's borrowed and what's new

Gandalf doesn't pretend to invent everything. It's an honest **combination** of existing good ideas:

- From **game theory**: the way of seeing — players, incentives, reactions, equilibrium, repeated games, and the recognizable strategic shapes.
- From **established product practice**: naming your stakeholders, imagining failures before they happen, and recording architectural decisions.
- From **systems thinking**: tracing effects two and three steps out instead of stopping at the obvious one.

What's genuinely new is the **Pattern Check (Step 6)** — a simple trigger list that maps an ordinary product change onto a known strategic shape and hands you its known solutions — together with the **depth sort (Step 0)** that keeps the whole thing from becoming busywork. The contribution isn't a new theory. It's making real strategic reasoning usable by someone who has never studied game theory, as a straight-line walk they can't accidentally shortcut.

## Don't trust it — test it

The best way to check whether this framework earns its place is not to admire it, and not to believe a polished success story. It's to **back-test it.** Take a real problem your team already lived through — an outage, a painful redesign, a launch that slipped — and run Gandalf against the situation *as it was before that decision was made.* If Step 2, 3, 6, or 7 would have surfaced the thing that actually bit you, that's real evidence the framework works. If it wouldn't have, you've found a gap worth fixing. One honest back-test is worth ten flattering anecdotes.

## The one-page cheat sheet

Run top to bottom. Don't skip. Each answer feeds the next.

| Step | The question | Status |
|---|---|---|
| **0. Depth** | Reversible? Wide? → Light / Standard / Deep. *Unsure → go deeper.* | Core |
| **1. Outcome** | What change in the world do we want? (not the feature) | Core |
| **2. Players** | Who's affected — people, technical, organizational, future? | Core |
| **3. Incentives** | What does each want — and where do they **conflict**? | Core |
| **4. Equilibrium** | Why is it like this today? Will my change actually hold? | Recommended |
| **5. Options** | At least two genuinely different approaches. | Core |
| **6. Pattern Check** | Run all 8 triggers; each "yes" adds questions + known fixes. | Recommended / Core |
| **7. Reactions** | What will each player do? Trace 1st, 2nd, 3rd-order effects. | Core |
| **8. Constraints** | Performance, security, legal, cost, vendor limits. | Core |
| **9. Decide** | Trade-off table; record the decision if it's hard to undo. | Recommended / Core |
| **10. Rollout** | Move in reversible steps; retire the old path. | Strongly recommended |
| **11. Metrics** | The numbers that prove it worked — tied to the outcome. | Core |

> The goal is not a bigger PRD. The goal is a better decision — and one whose reasoning anyone, from intern to senior engineer, can read and follow.
