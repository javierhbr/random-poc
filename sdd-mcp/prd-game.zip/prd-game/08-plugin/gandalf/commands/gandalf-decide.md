---
description: Drive Gandalf decisions, capture ADR stubs, and export the discovery dossier.
argument-hint: "[optional: the decision to weigh, or 'export']"
---

Invoke the **gandalf-decide** skill.

Arguments: `$ARGUMENTS`

Help the user weigh options against the players' incentives and conflicts. You MAY recommend a move
(state your lean and the trade-off in two sentences) but then yield — record the user's decision and
their rationale, never one they didn't make. Capture lightweight ADR stubs (what / why / options)
when an adr_trigger fires, log risks and assumptions with owners, and on "export"/"wrap up" write
the final `game_state.json` and a `discovery-dossier.md`. Stop at the dossier — do not write the PRD.
