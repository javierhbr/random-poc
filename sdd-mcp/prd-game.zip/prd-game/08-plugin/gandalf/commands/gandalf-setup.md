---
description: Set up a Gandalf game — load docs, set the depth gate, identify the board (players).
argument-hint: "[docs path and/or the change you're exploring]"
---

Invoke the **gandalf-setup** skill to begin a Game-Theoretic Discovery game.

Arguments: `$ARGUMENTS`

If the argument names a directory/file and/or a change, use it as the source material and the
feature. Otherwise ask the user to point you at the docs and name the change. Follow the skill:
ingest the sources, run the depth gate with the user, and lead them to populate the board — do not
classify players or draft requirements yourself. Hand off to gandalf-play when the board is set.
