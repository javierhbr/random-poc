---
description: Game-Theoretic Discovery — overview and entry point. Routes to setup/play/decide.
argument-hint: "[feature or docs path, optional]"
---

The user invoked the Gandalf (Game-Theoretic Discovery Framework) plugin. Gandalf reads a proposed
software change as a strategic game — players, incentives, conflicts, strategic patterns, reactions,
equilibria — to surface the requirements a feature-list PRD would miss. Its prime directive is
**guide, don't decide**: lead the user to discover the answers; never fill the analysis in for them.
The output is a discovery *dossier*, not a PRD.

The workflow is three skills in sequence:

1. **gandalf-setup** — load the docs, set the depth gate, identify the board (players).
2. **gandalf-play** — run the steps, summon challenger agents (Security Analyst, Risk Analyst, Judge).
3. **gandalf-decide** — weigh options, capture ADR stubs, export the dossier.
   (Optionally **gandalf-export-wizard** turns a played game into a clickable HTML replay.)

Arguments: `$ARGUMENTS`

If the user named a feature or pointed at a docs directory, begin by invoking the **gandalf-setup**
skill on it. If they gave nothing, briefly explain the three-step flow above and ask them to point
you at the docs (a folder or a file) and name the change they're exploring — then start setup.
Do not start analyzing or filling in players yourself.
