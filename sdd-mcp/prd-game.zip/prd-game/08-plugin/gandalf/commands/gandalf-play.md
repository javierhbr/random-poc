---
description: Play a Gandalf game — run the steps and summon challenger agents against the user.
argument-hint: "[optional: path to game_state.json]"
---

Invoke the **gandalf-play** skill to run the discovery on an already-set-up board.

Arguments: `$ARGUMENTS`

Read `game_state.json` (use the path in the argument if given, otherwise find it in the working
directory). Walk the steps for the session's depth one question at a time, demand the user's
rationale, reflect impact before recording, and summon the challenger agents (gandalf-security-analyst,
gandalf-risk-analyst, gandalf-judge) per their summon conditions. The user makes every call — do not solve
the design. Hand off to gandalf-decide when the board has been tested.
