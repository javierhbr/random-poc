---
description: Export a played Gandalf game to an interactive HTML wizard config (a faithful replay).
argument-hint: "[optional: path to game_state.json]"
---

Invoke the **gandalf-export-wizard** skill.

Arguments: `$ARGUMENTS`

Turn the played `game_state.json` into a `gandalf.config.json` validated against the wizard config
schema, then tell the user to open `${CLAUDE_PLUGIN_ROOT}/wizard/gandalf-game-configurable.html` and
load it. This is a faithful replay of the user's own choices — never fabricate wrong-answer decoys,
options, or conflicts the game didn't contain.
