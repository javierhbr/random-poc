---
description: Grill one fuzzy Gandalf item (player, conflict, option, requirement, metric…) until it's crisp.
argument-hint: "[the item/idea/concept to clarify]"
---

Invoke the **gandalf-grill** skill to clarify a single game item by interviewing the user depth-first.

Arguments: `$ARGUMENTS`

Treat the argument as the one item to grill (e.g. "the 'recording' player", "the speed-vs-security
conflict", "what 'masking' means", "the outcome"). If no argument is given, ask the user which one
piece is fuzzy. Interview one question at a time, surface contradictions, demand the rationale, and
do NOT define it for them — clarify until they can define and defend it, play it back for
confirmation, then record the sharpened item into `game_state.json` and re-flow anything downstream.
Return to gandalf-play / gandalf-decide when done.
