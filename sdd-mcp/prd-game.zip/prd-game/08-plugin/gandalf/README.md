# Gandalf — Game-Theoretic Discovery (Claude Code plugin)

Read a proposed software change as a strategic game — players, incentives, conflicts, strategic
patterns, reactions, equilibria — *before* you commit, to surface the requirements a feature-list
PRD would miss. The plugin **guides the user to discover** those requirements; it never fills the
analysis in. The deliverable is the user's *understanding*; the dossier is the residue.

**It does not write your PRD.** It produces a *dossier* of organized findings (plus lightweight ADR
stubs and a risk log). You take that into whatever PRD tool you like and write the document yourself.

## The two rules that make it work

- **Guide, don't decide.** Setup and Play never fill in your analysis — they surface candidates as
  questions (max three at a time) and make you state the *why*. Decide may *recommend* a move, but
  you make and own the call, and your rationale is what gets recorded. The point is that you can
  *defend* the result.
- **ADR stubs stay shallow.** When a decision is hard to reverse, sets a contract, accepts a real
  risk, touches many players, or is genuinely contested, it gets an ADR stub: the decision, the why,
  and the options considered. The implementing team elaborates the rest.

## What's in the plugin

```
gandalf/
├── .claude-plugin/plugin.json    # manifest
├── commands/                     # /gandalf, /gandalf-setup, /gandalf-play, /gandalf-grill, /gandalf-decide, /gandalf-wizard
├── skills/                       # the discovery skills (auto-trigger from chat too)
│   ├── gandalf-setup/               # 1 · load sources, set depth, identify the board
│   ├── gandalf-play/                # 2 · run the game, summon agents, drive discovery
│   ├── gandalf-grill/               #   · clarify ONE fuzzy item, depth-first, until defensible
│   ├── gandalf-decide/              # 3 · weigh options, capture ADR stubs, export the dossier
│   └── gandalf-export-wizard/       # turn a played game into an HTML wizard config
├── agents/                       # challenger subagents you play AGAINST
│   ├── gandalf-judge.md             #   neutral referee — scores coverage, rules on ADRs & readiness
│   ├── gandalf-security-analyst.md  #   adversary — attacks the design to surface abuse cases
│   └── gandalf-risk-analyst.md      #   worrier — exposes assumptions, ripples, risk-acceptance calls
├── core/                         # shared rulebook + schemas (read via ${CLAUDE_PLUGIN_ROOT})
│   ├── framework.yaml            #   depth gate, player categories, 8 patterns, steps, adr_triggers
│   ├── state.schema.json         #   the game-state shape (JSON, validated)
│   ├── state.example.json        #   a worked IVR-payment example
│   └── wizard.config.schema.json #   the Gandalf_CONFIG shape the HTML wizard renders
└── wizard/
    └── gandalf-game-configurable.html   # clickable front-end; renders any Gandalf_CONFIG
```

Why YAML for the rulebook and JSON for the state: the rulebook is human-edited and rarely changes,
so YAML's readability wins; the state accumulates large free-text rationales and a move-by-move log
and is read/written programmatically, so JSON (validated by `state.schema.json`) fits better.

## Installing

Add this directory as a plugin (e.g. via a marketplace entry pointing at `08-plugin/gandalf`, or by
copying it into your plugins directory). Once installed, the skills auto-trigger from natural
language and the `/gandalf*` commands appear. Skills locate their shared rulebook and schemas through
`${CLAUDE_PLUGIN_ROOT}/core/…`, so the plugin is self-contained — keep `core/`, `agents/`, and
`wizard/` alongside the skills.

## Using it — just talk, or use the commands

| You say / run | What happens |
|---|---|
| `/gandalf <feature or docs path>` | overview + routes into setup |
| *"Set up a Gandalf game from ./docs — the feature is taking payments in the IVR."* / `/gandalf-setup` | **gandalf-setup** |
| *"Start play."* / `/gandalf-play` | **gandalf-play** (challenger agents join in) |
| *"I'm not sure what this player/conflict really is — grill me."* / `/gandalf-grill <item>` | **gandalf-grill** (clarify one piece) |
| *"Help me decide on the capture approach."* / *"Is this ADR-worthy?"* / `/gandalf-decide` | **gandalf-decide** |
| *"Wrap up and export the findings."* / `/gandalf-decide export` | **gandalf-decide** writes the dossier |
| *"Make a wizard / export to the HTML."* / `/gandalf-wizard` | **gandalf-export-wizard** |

The flow is `gandalf-setup → gandalf-play → gandalf-decide`, producing `discovery-dossier.md` and the final
`game_state.json` in your working directory. Neither is a PRD — they're what you build one *from*.

## The wizard (alternative front-end)

The discovery can also be played as a clickable HTML wizard instead of in chat.
`wizard/gandalf-game-configurable.html` renders any `Gandalf_CONFIG`. **gandalf-export-wizard** turns a
played `game_state.json` into a `gandalf.config.json`; open the HTML, click **load config**, and pick
it (or serve it and use `?config=<url>`). A built-in IVR sample loads by default. Generated wizards
are a faithful **replay** of the user's own choices — no fabricated decoys; only the built-in sample
is an authored teaching quiz.

---

This plugin packages the Gandalf suite (`07-suite/`). See the repo root [INDEX.md](../../INDEX.md) for
the framework spec, teaching paper, tutorial, and standalone explainer.
