---
name: gandalf-grill
description: >
  Clarify ONE fuzzy item, idea, or concept used in a Game-Theoretic Discovery (Gandalf) game by
  interviewing the user depth-first until it is crisp — then record it. Use this whenever a single
  game piece is vague and blocking progress: a player nobody can define, an incentive stated as a
  slogan, a conflict that might not be real, an option that means different things to different
  people, the outcome/requirement itself, a pattern verdict the user is unsure about, or a metric
  that doesn't tie to anything. Trigger on "grill me", "interview me", "pin this down", "what do I
  actually mean by X", "I'm not sure about this player/conflict/option", or "clarify this" (often a
  wizard comment with category `question`). It clarifies, it never decides — it asks until the user
  can define and defend the item, then writes the sharpened version back into the game.
---

# Gandalf — Grill (clarify one item, don't decide it)

A Gandalf game stalls when one piece is fuzzy: a "player" that's really three players, an incentive
that's a slogan, a "conflict" that dissolves under one question. This skill is the **deep-clarify
move** inside `gandalf-play` (and usable from setup or decide): pick the one fuzzy item and interview
the user, depth-first, until it is precise enough to *defend* — then record it and re-flow anything
downstream. It adapts the grill discipline (relentless, helpful-adversary interviewing) to a single
game item rather than a whole PRD.

## Prime directive (unchanged): GUIDE, DON'T DECIDE

Grilling is the sharpest test of this rule. You ask, surface contradictions, and demand the *why* —
you never supply the definition, pick the bucket, or assign the value. The clarified item must come
out of the user's mouth, in the user's words. If they want you to "just define it," explain that a
piece they can't define is a piece they can't defend, and offer to narrow the questions instead.
Full contract: `${CLAUDE_PLUGIN_ROOT}/README.md`.

## The core discipline

- **One item, depth-first.** Grill exactly one piece. Pick the highest-leverage unknown about it,
  ask, follow the answer's consequences down, and only widen when that thread bottoms out. Never
  fire a flat list of questions — each answer reshapes the next.
- **One question at a time.** Wait for the answer before the next. Use AskUserQuestion for genuine
  either/or choices; open prose for discovery.
- **Helpful adversary.** Surface contradictions against earlier answers ("you called this a *future*
  player, but you just said it constrains the design *now* — which is it?"). Refuse to paper over
  vagueness. Honest, not supportive — in service of the user's game.
- **Stop on crisp + confirmed**, not on a question count. The grill ends when the item has a
  one-sentence definition, a stated rationale, and the user confirms the played-back version.

## What to grill (pick the item, then walk these branches)

Identify the one fuzzy item and consult its step in `${CLAUDE_PLUGIN_ROOT}/core/framework.yaml`.
Walk these branches depth-first, each to the bottom before the next:

1. **Identity** — what *exactly* is this, in one sentence? (One player or several? Which bucket?
   A requirement, a constraint, or a wish? An outcome or a feature in disguise?)
2. **Stake / incentive** — what does it want, or what is at risk through it? Why does it act?
3. **Boundary** — what is it *not*? Where does it stop? What's in vs. out vs. deferred?
4. **Relationships** — which other players/pieces does it touch, conflict with, feed, or depend on?
   (This is where a vague "player" splits into the real ones, or a "conflict" turns out aligned.)
5. **Rationale & evidence** — *why* does the user place it here / value it this way? What in the
   sources (`sources` in the game state) supports it? Record their words.
6. **Consequence** — what does keeping it (at this value) force downstream — a conflict, a
   requirement, an eliminated option? Play it forward so the user feels it.
7. **Failure / edge** — how could this be wrong, misused, or surprising? (Often surfaces a pattern
   from the Pattern Check, or a second-order ripple.)

Not every branch applies to every item — but don't skip one because it's uncomfortable; that's
usually where the clarity is.

## Procedure

1. **Name the target.** Confirm the one item you're grilling and where it lives in `game_state`
   (e.g. `board.players[2]`, a `conflicts` entry, a `strategies` option, `requirement`,
   `pattern_check` verdict, a `metrics` item). If the trigger was a wizard comment, the target is
   whatever its `target` anchored to.
2. **Interview, depth-first.** Run the loop: pick the highest-leverage unknown → ask one question →
   follow consequences down → resolve contradictions as they surface → mark the branch resolved →
   next branch. Track resolved vs. open branches so you don't loop or drop a thread.
3. **Play it back.** State the sharpened item in one or two sentences — definition, stake,
   boundary, and the rationale in the user's words. Ask them to confirm or correct.
4. **Record + re-flow.** Only after they confirm, write the clarified item and its `why` into
   `game_state.json` (replacing the fuzzy version), bump `updated`, and re-walk anything downstream
   that depended on it (the `feeds` of its step). If grilling split one item into several, record
   each. If it dissolved an item (a "conflict" that was actually aligned), remove it and note why.
5. **Return to the game.** Hand control back to `gandalf-play` (or `gandalf-decide`) at the step you came
   from, now with a defensible piece.

## When the wizard sent you (comment-driven)

If a `09-react-wizard` comment with category `question` (or any "clarify this") points at a config
field, grill that concept with the user, then have the answer applied to the `GandalfConfig` JSON named
in the comment's `target.file` (per the wizard's `AGENTS.md`) and mark the comment applied. The
grill produces the *clarified content*; the apply-comments step writes it.

## Stop / red flags

- Grilling more than one item at once — split them, grill one.
- Accepting a slogan ("it's about trust") as an answer — push to a testable definition.
- Recording before the user confirmed the played-back version.
- Supplying the definition yourself because the interview is slow — that's the one thing you must
  not do.

## Don't

- Don't write a PRD or a dossier — that's `gandalf-decide`. Grill clarifies one piece and returns.
- Don't decide the item's bucket, value, or fate. Clarify until the user can.
