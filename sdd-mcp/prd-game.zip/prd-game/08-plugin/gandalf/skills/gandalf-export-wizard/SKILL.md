---
name: gandalf-export-wizard
description: >
  Generate an interactive wizard config (Gandalf_CONFIG) from a played Game-Theoretic Discovery game,
  so the user can replay the discovery in the Gandalf Game HTML instead of in chat. Use this when the
  user says "make a wizard", "export to the HTML", "generate the config", "I want the visual
  version", or wants to turn a finished or in-progress game_state.json into something they can open
  in the browser and share. The generated wizard is a faithful REPLAY of the user's own choices —
  it never fabricates wrong-answer decoys.
---

# Gandalf — Export to Wizard

Turn a played game into a `Gandalf_CONFIG` — the JSON the `gandalf-game-configurable.html` wizard
renders — so the discovery becomes a clickable, shareable visual exercise. This is an *alternative
front-end*, not a new analysis: it replays what the user already decided.

## When to run

After a game has meaningful content in `game_state.json` (ideally after `gandalf-decide`, but a
partial game exports fine — missing steps are simply omitted). It can also export an *authored*
teaching example, but its main job is replaying *real* games.

## The honesty rule (important)

The built-in IVR sample is a *teaching quiz* with deliberate wrong-answer decoys, because someone
authored a solved example. A config generated from a real game must **not** invent decoys — that
would be putting words in the user's mouth and inventing "right answers" the game never produced.
So:

- For `single-select` steps, mark the user's **chosen** answer `correct: true`. Any other options
  must be the **real alternatives the user actually weighed** (from `strategies` /
  `options_considered`), never fabricated distractors. If there was only one real answer, emit a
  single option — the wizard renders it as a review/confirm card.
- For `multi-select`, every real item is `good: true`. Only include a `good:false` decoy if the
  game itself recorded a rejected/vanity candidate.
- `pattern-check` `fires` comes straight from the user's recorded verdict, not a presumed truth.

## Files

- `${CLAUDE_PLUGIN_ROOT}/core/wizard.config.schema.json` — the shape to emit. Validate against it before handing over.
- `${CLAUDE_PLUGIN_ROOT}/core/framework.yaml` — for pattern `shape` names and the canonical `categories`.
- `${CLAUDE_PLUGIN_ROOT}/core/state.schema.json` — the input you read.
- `${CLAUDE_PLUGIN_ROOT}/wizard/gandalf-game-configurable.html` — the wizard that renders the config.

## Mapping (game_state.json → Gandalf_CONFIG step)

Emit `brand` from `session.feature`, `categories` from `framework.yaml`, then one step per section
that has content, in framework order:

| state field | wizard step `type` | how to fill it |
|---|---|---|
| `session.feature` | `intro` | title + lede from the feature; `flow` from the steps you'll emit |
| `session.depth` | `single-select` | options = light/standard/deep; `correct` = recorded depth; `why` = `depth_rationale` |
| `outcome` | `single-select` | one option = `outcome.statement`, `correct:true`; `why` = `user_rationale` |
| `board.players` | `sort-bins` | one chip per player (`bin` = its `category`); `why` from the standout player's `why` |
| `board.conflicts` | `pair-select` | one pair per conflict (`type:conflict`, `res` = `hidden_requirement`) |
| `board.equilibrium` | `single-select` | option = "keep the fence(s)"; `why` = `holds_because`; discoveries from `fences_to_keep` |
| `strategies` + `decision` | `single-select` | options = the strategies; `correct` = `decision.chosen`; `why` = `decision.why` |
| `pattern_check` | `pattern-check` | one card per entry; `fires` = (entry.fires=='yes'); `shape` from framework; `fix` = adopted mitigations |
| `reactions` | `ripple` | `stages` grouped by `order` (1/2/3); `why` = the requirement that dropped out |
| `constraints` | `multi-select` | one chip per constraint, all `good:true`; `need` = count |
| `decision.payoff_matrix` | `payoff-matrix` (if present) | else fold the decision into the strategies `single-select` |
| `rollout` | `order` | `items` = stages; `correct` = recorded order |
| `metrics` | `multi-select` | one chip per metric, all `good:true`; `need` = count |
| `discovered_requirements` etc. | `assemble` | sections map categories → headings (see `dossier`/`prd_sections`) |

For each step, set `discoveries` from that step's contributed pieces (use the same category keys as
`categories`) so the tray and the final assemble screen populate. Carry `feeds` and `requires`
across from `framework.yaml` so the dependency display still works.

## Output & handoff

1. Write `gandalf.config.json` (validated against `wizard.config.schema.json`).
2. Tell the user how to use it with the wizard HTML, both ways:
   - **Open `${CLAUDE_PLUGIN_ROOT}/wizard/gandalf-game-configurable.html`, click "load config", pick
     `gandalf.config.json`.** (Works from a double-clicked file — the reliable path.)
   - Or, if serving over http, open `gandalf-game-configurable.html?config=<url-to-json>`.
3. Present both files. Remind the user this is a replay of *their* game — a visual, shareable
   version of the discovery, not a regenerated analysis.

## Don't

- Don't fabricate options, decoys, conflicts, or "correct" answers the game didn't contain.
- Don't write a PRD. The wizard's assemble screen is a recap, not a deliverable PRD.
