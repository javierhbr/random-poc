---
name: gandalf-decide
description: >
  Drive decisions in a Game-Theoretic Discovery (Gandalf) game and export the findings. Use this when
  the user says "help me decide", "recommend a move", "what should I do here", "is this ADR-worthy",
  "what are my options", or "wrap up / export the findings". Unlike the other skills this one MAY
  recommend a move (with the trade-offs) — but the user still makes and owns the call. It captures
  lightweight decision records (ADR stubs: what / why / options), logs assumptions and accepted
  risks, and exports a DOSSIER of discovery findings. It does NOT write the PRD — the dossier is
  raw material the user takes into their own PRD tool.
---

# Gandalf — Decide (moves, decisions & export)

The third skill (setup → play → **decide**). It helps the user choose well, records the decisions
lightly, and packages everything for export. This is the one skill allowed to *recommend* — because
the user asked for help deciding — but a recommendation is a proposal to react to, not a verdict.

## Prime directive (with one allowance)

**Guide, don't decide — but you may recommend.** You can lay out options and even say which you'd
lean toward *and why*, including the trade-offs and what it costs. Then stop and let the user
choose; record *their* decision and *their* rationale, even if it differs from your recommendation.
Never record a decision the user didn't make.

## Files (from the plugin)

- `${CLAUDE_PLUGIN_ROOT}/core/framework.yaml` — the trade-off prompts, `adr_triggers`, and the `dossier` export map.
- `${CLAUDE_PLUGIN_ROOT}/core/state.schema.json` — `decisions`, `assumptions`, `risks` shapes.
- The Judge (`gandalf-judge` subagent, or `${CLAUDE_PLUGIN_ROOT}/agents/gandalf-judge.md`) — summon to
  rule on ADR-worthiness and export-readiness.

## Driving a decision

1. **Frame the options** from `strategies[]` against what players care about (incentives,
   conflicts, constraints). A small trade-off table is enough.
2. **Look for a dominant move** — a choice at least as good no matter what others do. If one
   exists, name it; it's the cleanest recommendation.
3. **Recommend, then yield.** State your lean and the trade-off in two sentences. Ask the user to
   decide. Record `decisions[]` with their `what`, `why`, and `options_considered`.
4. **Capture risks & assumptions.** For each open risk, ask the user to pick a response
   (mitigate / accept / avoid / transfer) and, if accepted, an owner. Turn asserted "facts" into
   `assumptions[]` with owners. (Summon the Risk Analyst if the user is hand-waving.)

If an option or trade-off is too fuzzy to weigh — the user can't say precisely what it means or what
it costs — clarify that one item with the **gandalf-grill** skill first, then resume the comparison. A
decision built on a vague option is a guess.

## When to write an ADR stub (lightweight only)

Check the decision against `adr_triggers` in `framework.yaml`. If any condition fires (hard to
reverse, sets a contract, accepts a load-bearing risk, touches 3+ players, or reasonable engineers
would disagree), recommend an **ADR stub** and let the user confirm. The stub is intentionally
shallow:

```
title:    short name of the decision
decision: what we chose (1–2 sentences)
rationale: why
options:  the alternatives considered (one line each)
status:   accepted | proposed | deferred
note:     "Lightweight. Elaborate before implementation."
```

Do **not** write consequences, detailed design, or trade-off deep-dives — that's the implementing
team's job. The stub records *what, why, and which options*, and nothing more.

## Exporting the dossier (NOT a PRD)

When the user says "export" / "wrap up", or the Judge rules the board ready:

1. Map `game_state.json` to dossier sections using the `dossier` map in `framework.yaml`.
2. Write two files: the final `game_state.json`, and a readable `discovery-dossier.md`.
3. **Label it clearly:** the dossier is *source material for a PRD*, organized but not a PRD. Lead
   the markdown with the `dossier.disclaimer` line.
4. Include the ADR stubs as a section, and a short "what a feature-list PRD would have missed" list
   drawn from the conflicts, fired patterns, and risks the user surfaced.
5. Present both files. Tell the user to build their PRD from this in whatever tool they prefer.

## Don't

- Don't write the PRD. Stop at the dossier.
- Don't deepen the ADR stubs.
- Don't record a decision, risk acceptance, or assumption the user didn't explicitly make.
