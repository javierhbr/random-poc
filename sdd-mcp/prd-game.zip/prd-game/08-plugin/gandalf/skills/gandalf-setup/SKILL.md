---
name: gandalf-setup
description: >
  Set up a Game-Theoretic Discovery (Gandalf) game from source material. Use this FIRST whenever the
  user wants to "set up the game", "load the docs", "start Gandalf", points you at a documentation or
  requirements directory (markdowns, prior PRDs, design notes, tickets) to base a change on, or
  asks who the players/actors/stakeholders of a system are. This skill ingests the sources, sets
  the depth, and leads the user to identify the board (players and their buckets) — it does NOT do
  the analysis for them, and it does NOT write a PRD. It hands off to gandalf-play.
---

# Gandalf — Setup (load & set the board)

This skill gets a game ready: it reads the material, frames the change, and leads the user to
populate the opening board. It is the first of three skills (setup → play → decide).

## Prime directive (applies to the whole suite)

**Guide, don't decide.** The user could get answers from any model; what they need is to
*understand* them. Surface candidates from the docs only as questions (max three at a time), never
as filled-in classifications. The reasoning is theirs. Full contract: `${CLAUDE_PLUGIN_ROOT}/README.md`.

## Files (read these from the plugin)

- `${CLAUDE_PLUGIN_ROOT}/core/framework.yaml` — the rulebook (depth gate, player categories, steps). Load it now.
- `${CLAUDE_PLUGIN_ROOT}/core/state.schema.json` — the JSON shape of the game state you'll create.
- `${CLAUDE_PLUGIN_ROOT}/core/state.example.json` — a worked example to pattern-match against.

## What this skill does

1. **Get the material.** If the user gave a directory or attached files, use them. Otherwise ask:
   *"Point me at the docs — a folder or a file — and tell me the change you're exploring."*
2. **Read, then summarize — don't mine for answers.** List the directory, read the markdowns, and
   for each write a one-line `summary` plus `candidate_signals` (systems, teams, constraints worth
   *asking about*). These are prompts, not classifications.
3. **Create the state file.** Write `game_state.json` (in the user's working directory) conforming
   to `${CLAUDE_PLUGIN_ROOT}/core/state.schema.json`. Fill `session` (feature, timestamps, depth
   later, sources) and `requirement` (the specific change, e.g. "make a payment") — confirming the
   requirement title with the user in their words.
4. **Run the depth gate (Step 0) WITH the user.** Ask the two questions from `framework.yaml`; let
   them answer; record `depth` and `depth_rationale`. Unsure → go deeper.
5. **Open the board (Step 2 — players).** Walk the four buckets one at a time. For each candidate
   signal from the docs, ask: *"Player or not? Which bucket? Why?"* Record each player with the
   user's `why`. This is where the silent players (recordings, pipelines, future consumers)
   surface — let the user find them.

If the requirement itself is a slogan, or a candidate "player" is too fuzzy to bucket, clarify that
one item with the **gandalf-grill** skill before recording it — interview the user until they can define
and defend it, then continue. Don't bucket mush.

## Hand off

When the board has at least the obvious players in each relevant bucket, save `game_state.json`,
tell the user where it is, and hand off: *"Board's set. Say 'start play' to begin the game on the
requirement."* (That triggers **gandalf-play**.)

## Don't

- Don't classify players, assign incentives, or draft requirements yourself.
- Don't produce a PRD or a finished analysis — this is setup only.
