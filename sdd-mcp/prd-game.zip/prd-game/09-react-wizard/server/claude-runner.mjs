// Shared dynamic-step engine: turns a {job, cap, voice, prompt} request into
// the model's strict JSON by shelling out to the Claude CLI (`claude -p`).
// No API key — the CLI carries its own auth. Used by BOTH the Vite dev
// middleware (vite.config.ts) and the standalone server (server/api.mjs).

import { spawn } from 'node:child_process';

const log = (...a) => console.log('[gandalf:dynamic]', ...a);

/** Facilitator framing + a per-job output contract, prepended to the user prompt. */
export function composePrompt(body) {
  const { job, cap, voice, prompt, shape, bins } = body || {};
  const guard =
    'You are a facilitator for a strategic-discovery game, NOT a quizmaster. ' +
    'You never reveal the "correct" answers and never produce the discovery list for the user. ' +
    'Respond with STRICT JSON only — no prose, no markdown code fences.';
  let schema;
  if (job === 'reframe') {
    // reframe rewrites this step into the user's domain. For interactive steps
    // it regenerates the NON-GRADED body (options/chips/pairs) — never marking a
    // right answer; deciding is the user's job.
    const base = '"title": string, "sub": string';
    const byShape = {
      prose: `Return {${base}} rewriting this step into the user's domain. Keep it short and concrete.`,
      options: `Return {${base}, "options": [{"label": string}]} — 3 to 4 plausible options the user could pick between for their feature. Do NOT mark any correct or hint which is right.`,
      sort: `Return {${base}, "chips": [{"label": string, "bin": string}]} — 5 to 7 players (stakeholders, systems, or future features) for the feature; each "bin" is exactly one of these category keys: ${(bins || []).join(', ')}. Include at least one easily-overlooked, non-human player.`,
      pairs: `Return {${base}, "pairs": [{"a": string, "b": string}]} — 3 to 4 pairs of goals that could pull against each other for this feature. Do not say which actually conflict; that's the user's call.`,
      multi: `Return {${base}, "chips": [{"label": string}], "need": number} — 5 to 7 candidate hard constraints for the feature; "need" = how many the user should lock in (no greater than the number of chips).`,
    };
    schema = byShape[shape] || byShape.prose;
  } else if (job === 'propose') {
    schema = `Return {"candidates": [{"id": string, "label": string}]} with at most ${cap ?? 3} items, each a short candidate the user can accept, reject, or edit. Do not mark any as correct.`;
  } else {
    schema = `You are an in-character ${voice || 'analyst'}. Return {"voice": string, "text": string} — one sharp, specific line (<=240 chars) attacking the user's design. Do not solve it for them.`;
  }
  return `${guard}\n${schema}\n\nContext / task:\n${prompt}`;
}

/** Run `claude -p <prompt> --output-format json`, with a hard timeout. */
export function runClaude(prompt, { timeoutMs = 30_000 } = {}) {
  return new Promise((resolvePromise, reject) => {
    const t0 = Date.now();
    log(`spawn: claude -p … (${prompt.length} chars) --output-format json`);
    const child = spawn('claude', ['-p', prompt, '--output-format', 'json'], { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => { log('timeout — killing claude'); child.kill('SIGKILL'); reject(new Error('claude timed out')); }, timeoutMs);
    child.stdout.on('data', (d) => (stdout += d));
    child.stderr.on('data', (d) => (stderr += d));
    child.on('error', (err) => { clearTimeout(timer); log('spawn error:', err.message); reject(err); }); // e.g. claude not on PATH
    child.on('close', (code) => {
      clearTimeout(timer);
      log(`claude exited ${code} in ${Date.now() - t0}ms (${stdout.length} bytes stdout)`);
      if (code !== 0) { reject(new Error('claude exited ' + code + ': ' + stderr.slice(0, 200))); return; }
      resolvePromise(stdout);
    });
  });
}

/** `claude --output-format json` wraps the answer in {result: "..."}. Pull that
 *  out, then parse the model's own JSON (tolerating stray prose / fences). */
export function extractJson(cliOut) {
  let text = cliOut;
  try {
    const env = JSON.parse(cliOut);
    if (env && typeof env.result === 'string') text = env.result;
  } catch { /* not the envelope — treat stdout as the payload */ }
  try { return JSON.parse(text); } catch { /* fall through to brace extraction */ }
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start >= 0 && end > start) return JSON.parse(text.slice(start, end + 1));
  throw new Error('no JSON in model output');
}

/** End-to-end: a parsed request body -> the model's JSON object (or throws). */
export async function handleStepRequest(body) {
  const { job, cap, voice, prompt } = body || {};
  log(`request: job=${job} cap=${cap ?? '-'} voice=${voice ?? '-'} shape=${body?.shape ?? '-'} promptChars=${(prompt || '').length}`);
  try {
    const composed = composePrompt(body);
    const out = await runClaude(composed);
    const json = extractJson(out);
    log('parsed result:', JSON.stringify(json).slice(0, 200));
    return json;
  } catch (e) {
    log('FAILED:', e.message, '→ caller will answer 503 (front-end falls back to static)');
    throw e;
  }
}
