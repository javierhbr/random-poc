// Standalone dynamic-step backend — the same POST /api/step contract as the
// Vite dev middleware, but on its own port so the wizard runs dynamic OUTSIDE
// `npm run dev` (e.g. `vite preview` or a deployed `dist/`).
//
//   node server/api.mjs            # listens on :5190
//   PORT=8080 node server/api.mjs  # custom port
//
// Point the front-end at it by building with VITE_API_BASE, e.g.
//   VITE_API_BASE=http://localhost:5190 npm run build && npm run preview
//
// CORS is open so a separately-served static build can reach it. No API key —
// it shells out to the Claude CLI, which carries its own auth.

import { createServer } from 'node:http';
import { handleStepRequest } from './claude-runner.mjs';

const PORT = Number(process.env.PORT) || 5190;

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

const server = createServer((req, res) => {
  if (req.method === 'OPTIONS') { send(res, 204, ''); return; }       // CORS preflight
  const url = (req.url || '').split('?')[0];
  if (req.method === 'GET' && url === '/health') { send(res, 200, { ok: true }); return; }
  if (req.method !== 'POST' || url !== '/api/step') { send(res, 404, 'not found'); return; }

  let chunks = '';
  req.on('data', (c) => (chunks += c));
  req.on('end', async () => {
    try {
      const json = await handleStepRequest(JSON.parse(chunks || '{}'));
      send(res, 200, json);
    } catch (e) {
      send(res, 503, 'dynamic backend unavailable: ' + e.message); // front-end falls back to static
    }
  });
});

server.listen(PORT, () => console.log(`[gandalf] dynamic backend on http://localhost:${PORT}  (POST /api/step)`));
