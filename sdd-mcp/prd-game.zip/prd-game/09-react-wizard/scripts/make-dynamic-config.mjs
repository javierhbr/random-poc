// Build public/configs/ivr-dynamic.json from ivr.json by turning on dynamic
// mode across the steps where a live model call earns its latency.
//
//   node scripts/make-dynamic-config.mjs
//
// Per-step jobs follow the validated UX map: reframe (rewrite prose to the
// user's feature), propose (≤3 candidates AS QUESTIONS), challenge (an in-
// character attack). The graded "answer-key" steps (depth, equilibrium, decide,
// rollout, metrics) stay static — the model never decides for the user.

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const cfgDir = resolve(here, '..', 'public', 'configs');
const c = JSON.parse(readFileSync(resolve(cfgDir, 'ivr.json'), 'utf8'));

c.brand = 'Gandalf Game · live';

const intro = c.steps.find((s) => s.type === 'intro');
intro.featurePrompt = 'What feature do you want to run through the game?';
intro.lede = 'Run <b>your own</b> feature through the framework. Name it below — each step then adapts to <i>your</i> feature: it reframes the prompt, proposes candidates to consider, and an agent attacks your design.';
intro.next = 'Begin →';

// stepId -> dynamic spec. Anything not listed stays static & instant.
// reframe regenerates the step's NON-GRADED body for the user's feature; the
// user still does the deciding. challenge layers a live in-character attack.
const DYNAMIC = {
  outcome: { job: 'reframe', prompt: 'The user\'s feature is "{feature}". This step asks them to name the real OUTCOME — the change in the world a good design is measured against, not the feature itself. Offer 3-4 candidate outcome phrasings (one too-narrow "a feature in disguise", one too-vague, and one or two genuine outcomes) for them to choose between. Do not mark which is right.' },
  players: { job: 'reframe', prompt: 'The user\'s feature is "{feature}". This step asks them to list the PLAYERS — every stakeholder, system, or future feature that is affected or reacts. Generate 5-7 players sorted into the category bins, including at least one easily-overlooked, non-human, "silent" player.' },
  conflicts: { job: 'reframe', prompt: 'The user\'s feature is "{feature}". This step surfaces TENSIONS — pairs of goals that may pull against each other. Generate 3-4 candidate pairs for them to weigh.' },
  options: { job: 'reframe', prompt: 'The user\'s feature is "{feature}". This step asks them to pick a primary APPROACH. Offer 3-4 plausible, distinct approaches for them to choose between. Do not mark which is best.' },
  patterns: { job: 'challenge', voice: 'Security Analyst', prompt: 'The user is taking this feature through a strategic-discovery game: "{feature}". So far they have surfaced:\n{pieces}\nAs an adversarial Security Analyst, deliver ONE sharp, specific line attacking the security/abuse weak point of THEIR feature. Do not fix it for them.' },
  ripple: { job: 'challenge', voice: 'Risk Analyst', prompt: 'For "{feature}", as a Risk Analyst, deliver ONE sharp line tracing a dangerous 2nd- or 3rd-order consequence the team would likely miss. Name the chain, not the fix.' },
  constraints: { job: 'reframe', prompt: 'The user\'s feature is "{feature}". This step locks in hard CONSTRAINTS — non-negotiable boundaries the design must respect. Generate 5-7 candidate constraints; the user selects which bind.' },
  metrics: { job: 'reframe', prompt: 'The user\'s feature is "{feature}". This step picks SUCCESS METRICS that tie to the outcome and the risks. Generate 5-7 candidate metrics; the user selects which to track.' },
};

// The remaining graded steps (equilibrium, decide, rollout) stay static — the
// model must not generate their "correct" answer. But their IVR discoveries
// would pollute the user's dossier, so strip them.

let on = 0;
for (const s of c.steps) {
  const spec = DYNAMIC[s.id];
  if (spec) {
    s.mode = 'dynamic';
    s.dynamic = spec;
    on++;
  } else if (s.discoveries) {
    // static step in a dynamic run: keep its teaching interaction, but don't
    // inject its IVR answer pieces into the user's dossier.
    delete s.discoveries;
  }
}

writeFileSync(resolve(cfgDir, 'ivr-dynamic.json'), JSON.stringify(c, null, 2) + '\n');
console.log(`wrote ivr-dynamic.json — ${on} dynamic steps: ${Object.keys(DYNAMIC).join(', ')}`);
