# Agent guide — applying Gandalf wizard comments

This is a lean Vite + React wizard. Its content is **not** in the source — it's a
`GandalfConfig` **JSON file loaded at runtime** (the same shape as
`07-suite/gandalf-suite/core/wizard.config.schema.json`, which `gandalf-export-wizard`
emits). The user annotates the running UI; you apply each comment by editing the
**JSON config file it points at**, then the user reloads (the app re-fetches).

## Where the config lives

The wizard picks its config from the URL (see `src/useConfig.ts`):

| URL | loads | apply target (`target.file`) |
| --- | --- | --- |
| `/` (default) | `public/configs/ivr.json` | `public/configs/ivr.json` |
| `?config=squirrel` | `public/configs/squirrel.json` | `public/configs/squirrel.json` |
| `?config=/configs/x.json` | a served path | `public/configs/x.json` |
| `?config=https://…/x.json` | a URL | that URL |
| `?configFile=/abs/path/gandalf.config.json` | any file on disk (via the dev `/load-config` bridge) | `/abs/path/gandalf.config.json` |
| **Load…** button / file picker | an in-memory JSON | the file name (not round-trippable to disk) |

**Every comment records the file it belongs to in `target.file`** — edit *that*
file, not a guess.

## The loop

```
user turns on Comment mode → clicks a step/prompt/option/chip → leaves a note
        │
        ▼
comments.json  (sidecar, written by the dev server)
        │
        ▼
you read it → for each comment, edit target.file (a GandalfConfig JSON) → user reloads
        │
        ▼
mark the comment "applied" in comments.json (audit trail; never delete)
```

## The sidecar — `comments.json`

```jsonc
{
  "version": 1,
  "comments": [
    {
      "id": "c-1a2b3c4d",
      "workflow": "gandalf-wizard",
      "target": {
        "file": "public/configs/squirrel.json",  // the GandalfConfig JSON to edit
        "stepId": "outcome",                       // steps[].id in that JSON
        "stepLabel": "Step 1",
        "role": "option",                          // option | player-chip | conflict-pair | pattern-card |
                                                   // multiselect-chip | order-chip | matrix-cell | ripple-step |
                                                   // why-box | prompt | sub | flow-chip | prd-section | bin-label
        "index": 1,                                // nth element of that role (tiebreaker only)
        "snippet": "Make paying easier"            // text at the element — primary, drift-resilient anchor
      },
      "category": "edit",                          // edit | add | remove | logic | question | note
      "comment": "make this option clearly wrong and longer",
      "status": "open"                             // open | applied
    }
  ]
}
```

## Procedure

1. **Read** `comments.json`; take only `status: "open"`. Group by `target.file`.
2. **Open the JSON** at `target.file`. Resolve each comment to a field:
   - Find the step object by `target.stepId` (`steps[].id`).
   - Map `role` → the field, then match by **`snippet`** (text wins; `index` only
     breaks ties):
     | role | field |
     | --- | --- |
     | `option` | `options[].label` |
     | `player-chip` | `chips[].label` (sort-bins) |
     | `bin-label` | `bins[].label` |
     | `conflict-pair` | `pairs[]` (`a`/`b`/`res`) |
     | `pattern-card` | `patterns[]` (`q`/`shape`/`fix`) |
     | `multiselect-chip` | `chips[].label` (multi-select) |
     | `order-chip` | `items[].label` |
     | `matrix-cell` | `rows[].cells[].o` |
     | `ripple-step` | `stages[].text` |
     | `prompt` | the step's `title` |
     | `sub` | the step's `sub` |
     | `why-box` | the step's `why` / `closingWhy` |
     | `prd-section` | `sections[]` (assemble) |
     | `flow-chip` | `flow[]` (intro) |
   - If you can't locate it confidently, **skip and report** — never guess.
3. **Apply** the edit, keeping the file **valid JSON** that still satisfies
   `wizard.config.schema.json`. For `add`/`remove`, insert/delete array items and
   keep `discoveries` consistent if you add/remove a piece-producing element.
   Apply multiple edits to one array **bottom-up by index**.
4. **Mark applied** — set each handled comment's `status` to `"applied"` in
   `comments.json` (don't delete).
5. **Report** one table: `id · file · step · role · snippet · what changed · ✅/⏭️`.
   Tell the user to reload the browser (the config is fetched at runtime).

## `question` comments → grill, don't guess

A comment with `category: "question"` (or any "clarify this / what does X mean")
is a request to *clarify a concept*, not a mechanical edit. Don't invent an answer.
Run the **gandalf-grill** skill on that one item — interview the user depth-first until
they can define and defend it — then apply the clarified content to the field at
`target.file` and mark the comment applied. The grill produces the content; this
procedure writes it.

## Rules

- The JSON config at `target.file` is the source of truth — edit it directly, keep
  it valid.
- Snippet beats `index`. If they disagree, trust the snippet.
- Honesty: a config generated from a *real* game must not gain fabricated
  wrong-answer decoys (the `gandalf-export-wizard` rule). An authored teaching example
  (like `squirrel.json`) may. Don't change a config's nature when applying edits.
