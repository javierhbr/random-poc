import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { handleStepRequest } from './server/claude-runner.mjs';

/**
 * Tiny sidecar-comment bridge (the visual-spec model, lean).
 *   GET  /comments  -> the comments.json sidecar (created empty on first read)
 *   POST /comments  -> overwrite it with the request body
 * Comments are persisted next to the source; an agent reads them and applies
 * the edits to src/config.ts. Editing config.ts triggers Vite HMR, so the UI
 * refreshes on its own — no manual reload.
 */
function commentsSidecar(): Plugin {
  const file = resolve(__dirname, 'comments.json');
  const empty = JSON.stringify({ version: 1, comments: [] }, null, 2);
  return {
    name: 'gandalf-comments-sidecar',
    configureServer(server) {
      // GET /load-config?path=<abs or repo-relative> -> read any GandalfConfig JSON
      // off disk, so the wizard can load a config that lives in another project.
      server.middlewares.use('/load-config', (req, res) => {
        const q = new URL(req.url || '', 'http://localhost').searchParams.get('path');
        if (!q) { res.statusCode = 400; res.end('path required'); return; }
        const abs = resolve(q);
        if (!existsSync(abs)) { res.statusCode = 404; res.end('not found: ' + abs); return; }
        res.setHeader('Content-Type', 'application/json');
        res.end(readFileSync(abs, 'utf8'));
      });
      server.middlewares.use('/comments', (req, res) => {
        if (req.method === 'GET') {
          const body = existsSync(file) ? readFileSync(file, 'utf8') : empty;
          res.setHeader('Content-Type', 'application/json');
          res.end(body);
          return;
        }
        if (req.method === 'POST') {
          let chunks = '';
          req.on('data', (c) => (chunks += c));
          req.on('end', () => {
            try {
              const parsed = JSON.parse(chunks || empty);
              writeFileSync(file, JSON.stringify(parsed, null, 2));
              res.statusCode = 204;
              res.end();
            } catch {
              res.statusCode = 400;
              res.end('bad json');
            }
          });
          return;
        }
        res.statusCode = 405;
        res.end();
      });

      // POST /api/step -> generate one dynamic step via the Claude CLI.
      // Body: { job, cap?, voice?, prompt }. We shell out to `claude -p` (no API
      // key — the CLI carries its own auth) and return the model's strict JSON.
      // Any failure answers 503 so the front-end falls back to the static step.
      server.middlewares.use('/api/step', (req, res) => {
        if (req.method !== 'POST') { res.statusCode = 405; res.end(); return; }
        let chunks = '';
        req.on('data', (c) => (chunks += c));
        req.on('end', async () => {
          try {
            const json = await handleStepRequest(JSON.parse(chunks || '{}'));
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(json));
          } catch (e) {
            res.statusCode = 503;
            res.end('dynamic backend unavailable: ' + (e as Error).message);
          }
        });
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), commentsSidecar()],
  server: { port: 5180, open: true },
});
