# Gandalf React Wizard

The Gandalf Game discovery exercise as a **lean Vite + React + TypeScript app** —
the same guided IVR-payments game as the HTML wizards in `05-wizards/`, but with
the 700 lines of imperative `innerHTML` replaced by:

- **content as data** — the steps live in a `GandalfConfig` **JSON file loaded at runtime**
  (the shape from `07-suite/gandalf-suite/core/wizard.config.schema.json`), not in the source;
- **one small component per step `type`** in [`src/steps.tsx`](src/steps.tsx);
- a **visual-spec-style comment layer** ([`src/comments.tsx`](src/comments.tsx)) so
  you can annotate any step/prompt/option/chip in the browser and have an agent
  apply the change.

## Run

```bash
cd 09-react-wizard
npm install
npm run dev          # http://localhost:5180 (opens automatically)
```

## The config is data — loaded from a JSON file

The wizard ships **no content in its source**. It loads a `GandalfConfig` **JSON file at
runtime** and renders whichever one you point it at — via the URL or the **Load…**
control in the top bar:

| URL | loads |
| --- | --- |
| `http://localhost:5180/` | `public/configs/ivr.json` (IVR teaching example, default) |
| `…/?config=squirrel` | `public/configs/squirrel.json` (air-gap vault-sync, auto-authored from the *squirrel* `docs/`) |
| `…/?config=/configs/x.json` | any JSON served from `public/` |
| `…/?config=https://…/x.json` | any JSON by URL |
| `…/?configFile=/abs/path/gandalf.config.json` | **any file on disk** (e.g. a config in your project) via the dev `/load-config` bridge |
| **Load…** button | a JSON file picked from disk |

To add a game, drop a `GandalfConfig` JSON in `public/configs/` (or anywhere on disk and
use `?configFile=`). The engine never changes — only the data.

### the two bundled examples

- **`public/configs/ivr.json`** — the IVR pay-by-phone teaching example.
- **`public/configs/squirrel.json`** — an **air-gap vault-sync** game for the *squirrel*
  project, auto-authored from that project's `docs/` context. It is a synthesized
  teaching example (the discovery was generated, not played), labelled as such on its intro.

## The comment → apply → refresh loop

1. Click **💬 Comment** (bottom-right) to enter comment mode.
2. Click any **step, prompt, option, player chip, pattern card, …** — a popover
   opens. Pick a category, type what should change, **Save**.
3. The comment is written to [`comments.json`](comments.json) by the dev server
   (the `/comments` bridge in [`vite.config.ts`](vite.config.ts)). If you open the
   built files without the dev server, comments fall back to `localStorage` and you
   can **Download / Copy** the sidecar from the panel.
4. In a Claude session: *"apply the wizard comments"* → the agent reads
   `comments.json`, edits the **JSON config file each comment names in `target.file`**,
   and marks each comment applied (see [`AGENTS.md`](AGENTS.md)).
5. **Reload the browser** — the config is fetched at runtime, so the change appears on
   refresh. (Served `public/configs/*.json` also trigger a Vite reload on save.)

## How it maps to agentic-visual-spec

| visual-spec | here |
| --- | --- |
| sidecar `visual-spec-comments.json` | `comments.json` |
| target `{path, kind, snippet, heading}` | target `{file, stepId, role, index, snippet}` |
| snippet-first, drift-resilient anchoring | same — snippet wins, `index` is a tiebreaker |
| `workflow` routing tag | `workflow: "gandalf-wizard"` |
| `apply-comments` skill edits the source | agent edits the `GandalfConfig` JSON in `target.file` (see `AGENTS.md`) |
| dev server serves UI + comment bridge | the `gandalf-comments-sidecar` Vite plugin |

It deliberately does **not** pull in `@metuur/visual-spec` itself (Babel marker
injection, the editor shell): the wizard is one data file, so a ~40-line Vite
middleware + a React overlay is the lean equivalent.

## Files

```
09-react-wizard/
├── index.html
├── vite.config.ts        # react + the /comments sidecar + /load-config bridges
├── comments.json         # the sidecar an agent applies
├── AGENTS.md             # how the agent resolves + applies comments
├── public/configs/       # GandalfConfig JSON — the content as data (edit these to apply)
│   ├── ivr.json
│   └── squirrel.json
└── src/
    ├── main.tsx
    ├── App.tsx           # loader shell + the wizard engine (idx, tray pieces, nav)
    ├── useConfig.ts      # resolves ?config / ?configFile and fetches the JSON
    ├── types.ts          # the typed GandalfConfig model
    ├── steps.tsx         # one renderer per step type
    ├── comments.tsx      # the comment layer (FAB, popover, panel, dots, sidecar I/O)
    └── styles.css        # the Gandalf Game theme + comment-layer styles
```
