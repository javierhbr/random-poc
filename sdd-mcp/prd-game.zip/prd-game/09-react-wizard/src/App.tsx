import { useEffect, useMemo, useState } from 'react';
import { StepView, DynamicStepView, Narration, clearWizardState } from './steps';
import { CommentLayer } from './comments';
import { useConfig } from './useConfig';
import type { GandalfConfig, Piece, Move } from './types';
import type { GameState } from './dynamic';

/** Plain text from a config HTML string — for the compact next-step preview. */
function stripTags(html: string): string { return html.replace(/<[^>]*>/g, ''); }

/* ---- the config loader control (file picker + name/path input) ---- */
function ConfigLoader({ label, onSpec, onPick }: { label: string; onSpec: (s: string) => void; onPick: (c: GandalfConfig, file: string) => void }) {
  const [spec, setSpec] = useState('');
  function readFile(file: File) {
    const fr = new FileReader();
    fr.onload = () => { try { onPick(JSON.parse(String(fr.result)) as GandalfConfig, file.name); } catch { alert('Not valid JSON'); } };
    fr.readAsText(file);
  }
  return (
    <div className="loader">
      <span className="loader-cur" title={label}>{label.replace(/^.*\//, '')}</span>
      <input className="loader-in" placeholder="name or /path.json" value={spec}
        onChange={(e) => setSpec(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && spec.trim()) onSpec(spec.trim()); }} />
      <button className="loader-b" onClick={() => spec.trim() && onSpec(spec.trim())}>Load</button>
      <label className="loader-b file">Open…<input type="file" accept="application/json,.json" hidden
        onChange={(e) => { const f = e.target.files?.[0]; if (f) readFile(f); e.target.value = ''; }} /></label>
    </div>
  );
}

export function App() {
  const { config, source, error, loadObject, loadSpec } = useConfig();
  const loader = <ConfigLoader label={source.label} onSpec={loadSpec} onPick={loadObject} />;

  if (error) return (
    <div className="boot">
      <div className="boot-card"><h2>Couldn’t load config</h2>
        <p className="sub">tried <code>{source.url || source.file}</code> — {error}</p>{loader}</div>
    </div>
  );
  if (!config) return <div className="boot"><div className="boot-card"><h2>Loading…</h2>{loader}</div></div>;

  return <Wizard key={source.file} config={config} configFile={source.file} loader={loader} />;
}

/* ------------------------------ the engine ------------------------------ */
function Wizard({ config, configFile, loader }: { config: GandalfConfig; configFile: string; loader: React.ReactNode }) {
  const steps = config.steps;
  const [idx, setIdx] = useState(0);
  const [done, setDone] = useState(false);
  const [pieces, setPieces] = useState<Piece[]>([]);
  const [swapping, setSwapping] = useState(false);

  const [beat, setBeat] = useState<string | null>(null); // insight-beat toast
  const [feature, setFeature] = useState(config.feature || ''); // dynamic mode: the user's own feature
  const [moves, setMoves] = useState<Move[]>([]);          // recorded actions for dynamic prompts
  const gameState: GameState = { feature, pieces, moves };

  const step = steps[idx];
  const last = idx === steps.length - 1;
  // A feature-capture intro must wait for the feature (its own `done`); the
  // plain intro and the assemble screen auto-advance.
  const auto = step.type === 'assemble' || (step.type === 'intro' && !step.featurePrompt);

  // The "board": every category some step can discover. Drives the coverage
  // meter — an open loop of discovery left, never a quota or a 100%.
  const boardCats = useMemo(() => {
    const seen: string[] = [];
    steps.forEach((s) => (s.discoveries || []).forEach(([, , cat]) => { if (!seen.includes(cat)) seen.push(cat); }));
    return seen;
  }, [steps]);
  const coveredCats = useMemo(() => new Set(pieces.map((p) => p.cat)), [pieces]);

  useEffect(() => { setDone(false); setSwapping(true); const t = setTimeout(() => setSwapping(false), 180); window.scrollTo({ top: 0 }); return () => clearTimeout(t); }, [idx]);

  // Recognition beat: a brief flash when an insight-bearing step is solved.
  useEffect(() => {
    if (!done || !step.beat) return;
    setBeat(step.beat);
    const t = setTimeout(() => setBeat(null), 2600);
    return () => clearTimeout(t);
  }, [done, step.beat]);

  function commit() {
    const add = step.discoveries || [];
    if (!add.length) return;
    setPieces((prev) => {
      const seen = new Set(prev.map((p) => p.id));
      const next = prev.slice();
      add.forEach(([id, text, cat]) => { if (!seen.has(id)) next.push({ id, text, cat }); });
      return next;
    });
  }

  // Steps report the user's REAL selections (dynamic content, multi-picks,
  // write-ins, open questions) into the tray — keyed by step id + channel so a
  // revisit replaces, not dupes, and a step can feed two channels (e.g. its
  // picks and its open questions) without them colliding.
  const dynFallbackCat: Record<string, string> = { 'single-select': 'decision', 'sort-bins': 'player', 'pair-select': 'requirement', 'multi-select': 'constraint' };
  const [selfReported, setSelfReported] = useState<Set<string>>(new Set());
  // A dynamic step that went OFFLINE renders the authored example, but its
  // interactive parts can't report the user's picks — so we let it commit its
  // authored discoveries instead, the same as a static step would.
  const [fellBack, setFellBack] = useState<Set<string>>(new Set());
  function markFallback(id: string) { setFellBack((s) => (s.has(id) ? s : new Set(s).add(id))); }
  function reportDiscoveries(texts: string[], opts?: { channel?: string; cat?: string }) {
    const channel = opts?.channel ?? '';
    const cat = opts?.cat || step.discoveries?.[0]?.[2] || dynFallbackCat[step.type] || 'requirement';
    const prefix = `${step.id}::${channel}::`;
    if (!channel) setSelfReported((s) => (s.has(step.id) ? s : new Set(s).add(step.id)));
    setPieces((prev) => {
      const kept = prev.filter((p) => !p.id.startsWith(prefix));
      const add = texts.filter(Boolean).map((t, i) => ({ id: `${prefix}${i}`, text: t, cat }));
      return [...kept, ...add];
    });
  }

  function next() {
    // dynamic steps and self-reporting static steps already pushed the user's
    // real picks into the tray — don't also add the authored discoveries. An
    // offline dynamic step is the exception: it showed the example, so commit
    // the example's discoveries too (unless it still self-reported its picks).
    const usesAuthored = step.mode !== 'dynamic' || fellBack.has(step.id);
    if (usesAuthored && !selfReported.has(step.id)) commit();
    setMoves((m) => [...m, { stepId: step.id, type: step.type }]);
    if (last) { setIdx(0); setPieces([]); setMoves([]); setSelfReported(new Set()); setFellBack(new Set()); clearWizardState(); return; }
    setIdx((i) => i + 1);
  }
  function back() { if (idx > 0) setIdx((i) => i - 1); }

  const nextLabel = step.next || (last ? 'Start over' : 'Next →');
  const railPct = (idx / (steps.length - 1)) * 100;
  const cats = config.categories;
  const stepKey = useMemo(() => idx, [idx]); // remount StepView per step → fresh state

  return (
    <>
      <div className="topbar">
        <div className="topbar-inner">
          <div className="brand"><span className="pip" /> {config.brand || 'Gandalf Game'}</div>
          <div className="topbar-right">
            {loader}
            <div className="pcount">pieces · <b>{pieces.length}</b></div>
          </div>
        </div>
        <div className="rail"><i style={{ width: railPct + '%' }} /></div>
      </div>

      <div className="shell">
        <div className="cols">
          <main className={'stage' + (swapping ? ' swapping' : '')} id="stage" aria-live="polite">
            {step.mode === 'dynamic'
              ? <DynamicStepView key={stepKey} step={step} pieces={pieces} gameState={gameState} onDone={() => setDone(true)} feature={feature} onFeature={setFeature} onReport={reportDiscoveries} onFallback={() => markFallback(step.id)} />
              : <StepView key={stepKey} step={step} pieces={pieces} onDone={() => setDone(true)} feature={feature} onFeature={setFeature} moves={moves} onReport={reportDiscoveries} />}
            <Narration key={'narr-' + stepKey} step={step} done={done} />
          </main>
          <aside>
            <div className="tray">
              <h3>Discovery tray <span className="n">{pieces.length}</span></h3>
              {boardCats.length > 0 && (
                <div className="coverage" title="discovery so far">
                  {boardCats.map((c) => (
                    <span key={c} className={'cov' + (coveredCats.has(c) ? ' on' : '')}
                      style={coveredCats.has(c) ? { background: cats[c]?.color, borderColor: cats[c]?.color } : undefined}
                      title={cats[c]?.label || c} />
                  ))}
                  <span className="cov-label">{coveredCats.size < boardCats.length ? 'still to uncover' : 'all areas in play'}</span>
                </div>
              )}
              <div className="hint">pieces you uncover collect here, then build your PRD</div>
              <div className="traylist">
                {pieces.map((p) => (
                  <div className="titem" key={p.id}>
                    <span className="dot2" style={{ background: cats[p.cat]?.color || 'var(--ink)' }} />
                    <span><span className="ct">{cats[p.cat]?.label || p.cat}</span>{p.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
        <div className="nav">
          <button className="btn ghost" style={{ visibility: idx === 0 ? 'hidden' : 'visible' }} onClick={back}>← Back</button>
          {!last && step.type !== 'intro' && steps[idx + 1] && steps[idx + 1].type !== 'assemble' && (
            <span className={'nextprev' + (done ? ' lit' : '')}>
              next · {steps[idx + 1].badge || stripTags(steps[idx + 1].title || steps[idx + 1].id)}
            </span>
          )}
          <button className="btn primary" disabled={!auto && !done} onClick={next}>{nextLabel}</button>
        </div>
      </div>

      <div className={'toast' + (beat ? ' show' : '')} aria-live="polite">{beat}</div>

      <CommentLayer stepId={step.id} stepLabel={step.badge || step.id} configFile={configFile} />
    </>
  );
}
