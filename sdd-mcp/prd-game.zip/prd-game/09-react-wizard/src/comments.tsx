import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Comment layer — the visual-spec sidecar model, in React.
 * Turn on comment mode, click any step/prompt/option/chip, leave a note.
 * Comments persist to comments.json (via the dev server) and an agent applies
 * them by editing the GandalfConfig JSON named in each comment's target.file.
 * Anchors are {stepId, role, snippet} —
 * snippet-first, drift-resilient, exactly like visual-spec.
 */

type Anchor = { file: string; stepId: string; stepLabel: string; role: string; index: number; snippet: string };
type Comment = {
  id: string; workflow: string; target: Anchor; category: string;
  selectedContent: string; comment: string; status: 'open' | 'applied'; ts: string;
};
type Doc = { version: 1; comments: Comment[] };

const WORKFLOW = 'gandalf-wizard';
const LS = 'gandalf-react-comments-v1';
const CATS: [string, string][] = [
  ['edit', 'reword / change'], ['add', 'add an option/item'], ['remove', 'remove this'],
  ['logic', 'change behavior'], ['question', 'ask a question'], ['note', 'note'],
];
const ROLE_SEL: [string, string][] = [
  ['.opt', 'option'], ['.chip', 'player-chip'], ['.pair', 'conflict-pair'], ['.pcard', 'pattern-card'],
  ['.mschip', 'multiselect-chip'], ['.ord-chip', 'order-chip'], ['.mxc', 'matrix-cell'],
  ['.rstep', 'ripple-step'], ['.why', 'why-box'], ['.prompt', 'prompt'], ['.sub', 'sub'],
  ['.flow span', 'flow-chip'], ['.psec', 'prd-section'], ['.titem', 'tray-item'], ['.bin h4', 'bin-label'],
];

const empty: Doc = { version: 1, comments: [] };
const norm = (j: unknown): Doc => (j && (j as Doc).comments ? { version: 1, comments: (j as Doc).comments } : empty);
const snip = (el: Element) => (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 160);
const rand = () => Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

export function CommentLayer({ stepId, stepLabel, configFile }: { stepId: string; stepLabel: string; configFile: string }) {
  const [doc, setDoc] = useState<Doc>(empty);
  const [mode, setMode] = useState(false);
  const [serverLive, setServerLive] = useState(false);
  const [pop, setPop] = useState<{ x: number; y: number; anchor: Anchor; existing?: Comment } | null>(null);
  const [dots, setDots] = useState<{ id: string; x: number; y: number; n: number; comment: Comment }[]>([]);
  const docRef = useRef(doc); docRef.current = doc;
  const liveRef = useRef(serverLive); liveRef.current = serverLive;

  /* ---- persistence ---- */
  const persist = useCallback((next: Doc) => {
    setDoc(next);
    try { localStorage.setItem(LS, JSON.stringify(next)); } catch { /* ignore */ }
    if (liveRef.current) {
      fetch('/comments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(next) })
        .catch(() => setServerLive(false));
    }
  }, []);

  useEffect(() => {
    let alive = true;
    fetch('/comments').then((r) => (r.ok ? r.json() : null)).then((j) => {
      if (!alive) return;
      if (j) { setServerLive(true); setDoc(norm(j)); }
      else { try { setDoc(norm(JSON.parse(localStorage.getItem(LS) || 'null'))); } catch { /* ignore */ } }
    }).catch(() => { try { setDoc(norm(JSON.parse(localStorage.getItem(LS) || 'null'))); } catch { /* ignore */ } });
    return () => { alive = false; };
  }, []);

  /* ---- anchoring ---- */
  const open = doc.comments.filter((c) => c.status === 'open');
  const anchorOf = useCallback((el: HTMLElement): Anchor => {
    const role = el.dataset.vsRole || el.tagName.toLowerCase();
    const scope = el.closest('#stage') ? document.getElementById('stage') : el.closest('aside');
    const peers = scope ? Array.from(scope.querySelectorAll<HTMLElement>(`[data-vs-role="${role}"]`)) : [el];
    return { file: configFile, stepId, stepLabel, role, index: Math.max(0, peers.indexOf(el)), snippet: snip(el) };
  }, [stepId, stepLabel, configFile]);

  const findEl = useCallback((a: Anchor): HTMLElement | null => {
    if (a.stepId !== stepId) return null;
    const scope = document.getElementById('stage'); if (!scope) return null;
    const peers = Array.from(scope.querySelectorAll<HTMLElement>(`[data-vs-role="${a.role}"]`));
    const bySnip = peers.filter((n) => snip(n) === a.snippet);
    if (bySnip.length === 1) return bySnip[0];
    if (bySnip.length > 1) return bySnip[Math.min(a.index, bySnip.length - 1)];
    return peers[a.index] || null;
  }, [stepId]);

  /* ---- tag annotatable elements when in comment mode / on step change ---- */
  useEffect(() => {
    document.querySelectorAll('[data-vs-ann]').forEach((n) => { n.removeAttribute('data-vs-ann'); (n as HTMLElement).removeAttribute('data-vs-role'); });
    if (!mode) return;
    ['#stage', 'aside'].forEach((sc) => {
      const root = document.querySelector(sc); if (!root) return;
      ROLE_SEL.forEach(([sel, role]) => root.querySelectorAll<HTMLElement>(sel).forEach((n) => {
        if (!n.hasAttribute('data-vs-ann')) { n.setAttribute('data-vs-ann', '1'); n.dataset.vsRole = role; }
      }));
    });
  }, [mode, stepId]);

  /* ---- click-to-annotate (capture, so wizard handlers don't fire) ---- */
  useEffect(() => {
    if (!mode) return;
    const onClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (t.closest('.vs-pop,.vs-panel,.vs-fab,.vs-dot,.vs-hint-bar')) return;
      const el = t.closest<HTMLElement>('[data-vs-ann]');
      if (!el) return;
      e.preventDefault(); e.stopImmediatePropagation();
      setPop({ x: e.clientX, y: e.clientY, anchor: anchorOf(el) });
    };
    document.addEventListener('click', onClick, true);
    const onEsc = (e: KeyboardEvent) => { if (e.key === 'Escape') { setPop(null); setMode(false); } };
    document.addEventListener('keydown', onEsc);
    return () => { document.removeEventListener('click', onClick, true); document.removeEventListener('keydown', onEsc); };
  }, [mode, anchorOf]);

  /* ---- dots for comments on the current step ---- */
  useEffect(() => {
    const place = () => {
      if (!mode) { setDots([]); return; }
      const next: typeof dots = [];
      open.forEach((c, i) => { const el = findEl(c.target); if (!el) return; const r = el.getBoundingClientRect(); next.push({ id: c.id, x: r.left, y: r.top, n: i + 1, comment: c }); });
      setDots(next);
    };
    place();
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
    return () => { window.removeEventListener('scroll', place, true); window.removeEventListener('resize', place); };
  }, [mode, doc, stepId, findEl]); // eslint-disable-line

  /* ---- actions ---- */
  function save(text: string, category: string) {
    if (!pop) return;
    if (!text.trim()) { setPop(null); return; }
    const cs = docRef.current.comments.slice();
    if (pop.existing) {
      const c = cs.find((x) => x.id === pop.existing!.id); if (c) { c.comment = text; c.category = category; }
    } else {
      cs.push({ id: 'c-' + rand(), workflow: WORKFLOW, target: pop.anchor, category, selectedContent: pop.anchor.snippet, comment: text, status: 'open', ts: new Date().toISOString() });
    }
    persist({ version: 1, comments: cs });
    setPop(null);
  }
  function remove(id: string) { persist({ version: 1, comments: docRef.current.comments.filter((c) => c.id !== id) }); setPop(null); }

  return (
    <>
      <button className={'vs-fab' + (mode ? ' on' : '')} onClick={() => { setMode((m) => !m); setPop(null); }}>
        💬 Comment <span className="vs-n">{open.length}</span>
      </button>

      {mode && <div className="vs-hint-bar">Comment mode — click any step, prompt, option or chip. Esc to exit.</div>}

      {mode && (
        <div className="vs-panel">
          <header><h3>Comments</h3><span className={'vs-sync' + (serverLive ? ' live' : '')}>{serverLive ? 'synced' : 'local'}</span></header>
          <div className="vs-list">
            {open.length === 0 && <div className="vs-empty">No comments yet. Click any step, prompt, option or chip to annotate.</div>}
            {open.map((c) => (
              <div className="vs-item" key={c.id}>
                <div className="vs-meta"><span>{c.target.stepLabel} · {c.target.role}</span><span>{c.category}</span></div>
                <button className="vs-del" onClick={() => remove(c.id)}>remove</button>
                <div className="vs-snip">“{c.target.snippet.slice(0, 70)}{c.target.snippet.length > 70 ? '…' : ''}”</div>
                <div className="vs-text">{c.comment}</div>
              </div>
            ))}
          </div>
          <footer>
            <button className="vs-b" onClick={() => navigator.clipboard?.writeText(JSON.stringify(doc, null, 2))}>Copy JSON</button>
            <button className="vs-b" onClick={() => {
              const blob = new Blob([JSON.stringify(doc, null, 2)], { type: 'application/json' });
              const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'comments.json'; a.click();
            }}>Download</button>
          </footer>
        </div>
      )}

      {dots.map((d) => (
        <div key={d.id} className="vs-dot" style={{ left: d.x, top: d.y }} title={d.comment.comment}
          onClick={(e) => { e.stopPropagation(); const el = findEl(d.comment.target); const r = el?.getBoundingClientRect(); setPop({ x: r?.left ?? d.x, y: r?.bottom ?? d.y, anchor: d.comment.target, existing: d.comment }); }}>{d.n}</div>
      ))}

      {pop && <Popover key={pop.existing?.id || 'new'} pop={pop} onSave={save} onCancel={() => setPop(null)} onDelete={pop.existing ? () => remove(pop.existing!.id) : undefined} />}
    </>
  );
}

function Popover({ pop, onSave, onCancel, onDelete }:
  { pop: { x: number; y: number; anchor: Anchor; existing?: Comment }; onSave: (t: string, c: string) => void; onCancel: () => void; onDelete?: () => void }) {
  const [text, setText] = useState(pop.existing?.comment || '');
  const [cat, setCat] = useState(pop.existing?.category || 'edit');
  const a = pop.anchor;
  const left = Math.min(pop.x, window.innerWidth - 320);
  const top = Math.min(pop.y + 8, window.innerHeight - 230);
  return (
    <div className="vs-pop" style={{ left: Math.max(12, left), top: Math.max(12, top) }}>
      <div className="vs-anchor"><b>{a.stepLabel}</b> · {a.role} #{a.index}<br />“{a.snippet.slice(0, 90)}{a.snippet.length > 90 ? '…' : ''}”</div>
      <select value={cat} onChange={(e) => setCat(e.target.value)}>{CATS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
      <textarea autoFocus placeholder="What should change here?" value={text} onChange={(e) => setText(e.target.value)} />
      <div className="vs-row">
        {onDelete && <button className="vs-b ghost" onClick={onDelete}>Delete</button>}
        <button className="vs-b ghost" onClick={onCancel}>Cancel</button>
        <button className="vs-b save" onClick={() => onSave(text, cat)}>Save</button>
      </div>
    </div>
  );
}
