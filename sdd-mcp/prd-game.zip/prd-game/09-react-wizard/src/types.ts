// Gandalf_CONFIG — the typed data model the wizard renders.
// Mirrors 07-suite/gandalf-suite/core/wizard.config.schema.json so the
// gandalf-export-wizard skill's output drops straight in.

export type Tone = 'good' | 'bad';
export type AxisTone = 'pos' | 'neg';

/** [id, text, category] — a piece added to the tray when a step is left. */
export type Discovery = [string, string, string];

/** One authored, in-character line (Phase 1). Capped by authoring discipline:
 *  2–3 marquee moments per playthrough — not a line on every step. */
export interface NarrationLine {
  voice?: string;               // "Security Analyst", "Risk Analyst", or a scenario voice
  text: string;                 // HTML-safe, one line
  trigger?: 'enter' | 'done';   // when it appears (default 'done')
  once?: boolean;               // don't repeat on Back/Next revisits
}

/** A single dynamic-mode job (Phase 2). The model is a facilitator, never a
 *  quizmaster: it reframes, proposes ≤3 candidates as questions, or challenges. */
export interface DynamicSpec {
  job: 'reframe' | 'propose' | 'challenge';
  cap?: number;                 // ≤3 for 'propose'
  prompt: string;               // template; may reference {feature} {outcome} {pieces}
  voice?: string;               // persona for 'challenge'
}

export interface StepBase {
  id: string;
  badge?: string;
  move?: string;
  feeds?: string[];
  requires?: string[];
  title?: string;
  sub?: string;
  why?: string;
  next?: string;
  discoveries?: Discovery[];
  help?: string;                // on-demand explanation of the question (HTML)
  beat?: string;                // insight-beat toast text (Phase 0/1)
  narration?: NarrationLine[];  // authored in-character lines (Phase 1)
  mode?: 'static' | 'dynamic';  // default 'static' (Phase 2)
  dynamic?: DynamicSpec;        // present when mode === 'dynamic' (Phase 2)
}

export interface IntroStep extends StepBase {
  type: 'intro';
  eyebrow?: string;
  lede?: string;
  flow?: string[];
  footnote?: string;
  featurePrompt?: string;       // dynamic mode: ask the user for their own feature
}

export interface DepthAxisOption { label: string; value: string; tone: AxisTone; short?: string }
export interface DepthAxis { key: string; prompt: string; options: DepthAxisOption[]; hint?: string; explain?: string }
export interface DepthCell { label: string; tone: Tone }
export interface DepthGateStep extends StepBase {
  type: 'depth-gate';
  axes: DepthAxis[];
  matrix: Record<string, DepthCell>;
  matrixNote?: string;
}

export interface SelectOption { label: string; correct: boolean; tag?: string }
export interface SingleSelectStep extends StepBase {
  type: 'single-select';
  options: SelectOption[];
  multi?: boolean;        // allow selecting more than one option (and unselecting)
  allowCustom?: boolean;  // allow writing in a new option of your own
}

export interface Bin { key: string; label: string; color: string }
export interface SortChip { label: string; bin: string; reveal?: boolean }
export interface SortBinsStep extends StepBase {
  type: 'sort-bins';
  bins: Bin[];
  chips: SortChip[];
}

export interface Pair { a: string; b: string; type: 'conflict' | 'aligned'; res: string }
export interface PairSelectStep extends StepBase {
  type: 'pair-select';
  pairs: Pair[];
}

export interface Pattern { q: string; fires: boolean; shape: string; fix: string }
export interface PatternCheckStep extends StepBase {
  type: 'pattern-check';
  yesLabel?: string;
  noLabel?: string;
  unsureLabel?: string;
  counterLabel?: string;
  patterns: Pattern[];
}

export interface RippleStage { ord: string; text: string; danger?: boolean }
export interface RippleStep extends StepBase {
  type: 'ripple';
  revealLabel?: string;
  stages: RippleStage[];
}

export interface MultiChip { label: string; good: boolean; decoyTag?: string }
export interface MultiSelectStep extends StepBase {
  type: 'multi-select';
  need: number;
  chips: MultiChip[];
}

export interface MatrixCell { o: string; tone: Tone }
export interface MatrixRow { key: string; label: string; dominant: boolean; cells: MatrixCell[] }
export interface PayoffMatrixStep extends StepBase {
  type: 'payoff-matrix';
  cols: string[];
  rows: MatrixRow[];
  pickPrompt?: string;
  okText?: string;
  retryText?: string;
}

export interface OrderItem { id: string; label: string; detail?: string }
export interface OrderStep extends StepBase {
  type: 'order';
  items: OrderItem[];
  correct: string[];
}

export interface AssembleSection { title: string; src: string; note?: string }
export interface AssembleDoc { kicker: string; heading: string; leadFrom: string; fallbackLead: string }
export interface AssembleStep extends StepBase {
  type: 'assemble';
  doc: AssembleDoc;
  sections: AssembleSection[];
  closingWhy?: string;
}

export type Step =
  | IntroStep
  | DepthGateStep
  | SingleSelectStep
  | SortBinsStep
  | PairSelectStep
  | PatternCheckStep
  | RippleStep
  | MultiSelectStep
  | PayoffMatrixStep
  | OrderStep
  | AssembleStep;

export interface Category { label: string; color: string }

export interface GandalfConfig {
  brand?: string;
  categories: Record<string, Category>;
  steps: Step[];
  feature?: string;             // dynamic mode: the user's own feature (seeds reframes)
}

export interface Piece { id: string; text: string; cat: string }

/** A recorded user action, for dynamic prompts to reference (Phase 2). */
export interface Move { stepId: string; type: string; payload?: unknown }
