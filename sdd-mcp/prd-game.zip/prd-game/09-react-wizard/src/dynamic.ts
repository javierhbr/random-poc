// The single seam between the static wizard and live, model-generated content.
//
// Static steps return their config verbatim and instantly. Dynamic steps POST
// to /api/step (a dev-server middleware that shells out to the Claude CLI) and
// slot the result back into the SAME reusable renderer. The model is a
// FACILITATOR, never a quizmaster: it reframes a step's prose, proposes ≤3
// candidates as questions, or challenges what the user entered — it never
// produces the "correct" answers or the discovery list.
//
// Hard rule: any failure (no backend, no `claude` on PATH, timeout, bad JSON)
// degrades to `source:'fallback'` with the static step — zero user-facing
// breakage. `vite preview` (no middleware) simply always falls back.

import type { Step, Piece, Move } from './types';

export interface GameState { feature: string; pieces: Piece[]; moves: Move[] }

/** An UNCONFIRMED candidate the user accepts, rejects, or edits. Never auto-applied. */
export interface Proposal { id: string; label: string }

export interface StepContent {
  step: Step;                                  // possibly reframed prose
  proposals?: Proposal[];                      // for 'propose'
  challenge?: { voice: string; text: string }; // for 'challenge'
  source: 'static' | 'dynamic' | 'fallback';
}

/** Opening reframes are paid for once per (feature + step). */
const reframeCache = new Map<string, StepContent>();

/** De-dupe concurrent identical requests (e.g. React StrictMode's double mount
 *  in dev) so the costly `claude` CLI fires once, not twice. */
const inFlight = new Map<string, Promise<StepContent>>();

const TIMEOUT_MS = 32_000;

// Where the dynamic backend lives. Empty = same origin (the Vite dev
// middleware). Set VITE_API_BASE at build time to point a static `dist/` at the
// standalone server, e.g. VITE_API_BASE=http://localhost:5190.
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined) || '';

function summarizePieces(pieces: Piece[]): string {
  if (!pieces.length) return '(nothing yet)';
  return pieces.map((p) => `- [${p.cat}] ${p.text}`).join('\n');
}

/** Fill {feature} {outcome} {pieces} placeholders in a dynamic prompt template. */
function fillTemplate(tpl: string, gs: GameState): string {
  const outcome = gs.pieces.find((p) => p.cat === 'outcome')?.text || gs.feature || '';
  return tpl
    .replace(/\{feature\}/g, gs.feature || '(unspecified feature)')
    .replace(/\{outcome\}/g, outcome)
    .replace(/\{pieces\}/g, summarizePieces(gs.pieces));
}

// console.log (not .debug) so it shows at the browser's default level.
const log = (...args: unknown[]) => console.log('%c[gandalf:dynamic]', 'color:#0E6F66;font-weight:700', ...args);

export async function getStepContent(step: Step, gs: GameState): Promise<StepContent> {
  if (step.mode !== 'dynamic' || !step.dynamic) { log('static step', step.id); return { step, source: 'static' }; }
  const spec = step.dynamic;

  const cacheKey = `${spec.job}::${gs.feature}::${step.id}`;
  if (spec.job === 'reframe' && reframeCache.has(cacheKey)) { log('reframe cache hit', cacheKey); return reframeCache.get(cacheKey)!; }
  const pending = inFlight.get(cacheKey);
  if (pending) { log('joining in-flight request', cacheKey); return pending; }

  const promise = fetchStepContent(step, spec, gs, cacheKey);
  inFlight.set(cacheKey, promise);
  promise.finally(() => inFlight.delete(cacheKey));
  return promise;
}

/** For reframe, the body shape the model should regenerate (ungraded). */
function shapeFor(step: Step): string {
  switch (step.type) {
    case 'single-select': return 'options';
    case 'sort-bins': return 'sort';
    case 'pair-select': return 'pairs';
    case 'multi-select': return 'multi';
    default: return 'prose';
  }
}

async function fetchStepContent(step: Step, spec: NonNullable<Step['dynamic']>, gs: GameState, cacheKey: string): Promise<StepContent> {
  const filled = fillTemplate(spec.prompt, gs);
  const url = API_BASE + '/api/step';
  const shape = spec.job === 'reframe' ? shapeFor(step) : undefined;
  const bins = step.type === 'sort-bins' ? step.bins.map((b) => b.key) : undefined;
  const t0 = performance.now();
  log(`→ ${spec.job} step="${step.id}" shape=${shape ?? '-'} feature="${gs.feature}" POST ${url}`, { cap: spec.cap, voice: spec.voice, prompt: filled });

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ job: spec.job, cap: spec.cap, voice: spec.voice, prompt: filled, shape, bins }),
      signal: ctrl.signal,
    });
    const ms = Math.round(performance.now() - t0);
    if (!res.ok) throw new Error('status ' + res.status + ' (' + (await res.text().catch(() => '')).slice(0, 120) + ')');
    const data = await res.json();
    log(`← ${spec.job} step="${step.id}" ok in ${ms}ms`, data);
    const content = mapResult(step, spec.cap, data);
    if (spec.job === 'reframe') reframeCache.set(cacheKey, content);
    return content;
  } catch (e) {
    const ms = Math.round(performance.now() - t0);
    log(`✕ ${spec.job} step="${step.id}" FALLBACK after ${ms}ms —`, (e as Error).message);
    return { step, source: 'fallback' };
  } finally {
    clearTimeout(timer);
  }
}

function str(v: any): string { return typeof v === 'string' ? v : ''; }

function mapResult(step: Step, cap: number | undefined, data: any): StepContent {
  const spec = step.dynamic!;
  if (spec.job === 'reframe') {
    // Rewrite prose, and for interactive steps regenerate the NON-GRADED body
    // in the user's domain. No `correct`/`good`/`type` answer keys are produced
    // — the user still does the deciding. Drop the IVR `discoveries`; the user's
    // real selections are reported into the tray instead.
    const s: any = { ...step, discoveries: undefined };
    if (str(data?.title)) s.title = data.title;
    if (str(data?.sub)) s.sub = data.sub;
    if (step.type === 'single-select') {
      const opts = (Array.isArray(data?.options) ? data.options : []).map((o: any) => ({ label: str(o?.label), correct: false })).filter((o: any) => o.label);
      if (!opts.length) return { step, source: 'fallback' };
      s.options = opts;
    } else if (step.type === 'sort-bins') {
      const keys = new Set(step.bins.map((b) => b.key));
      const chips = (Array.isArray(data?.chips) ? data.chips : []).map((c: any) => ({ label: str(c?.label), bin: keys.has(c?.bin) ? c.bin : step.bins[0].key })).filter((c: any) => c.label);
      if (!chips.length) return { step, source: 'fallback' };
      s.chips = chips;
    } else if (step.type === 'pair-select') {
      const pairs = (Array.isArray(data?.pairs) ? data.pairs : []).map((p: any) => ({ a: str(p?.a), b: str(p?.b), type: 'conflict', res: '' })).filter((p: any) => p.a && p.b);
      if (!pairs.length) return { step, source: 'fallback' };
      s.pairs = pairs;
    } else if (step.type === 'multi-select') {
      const chips = (Array.isArray(data?.chips) ? data.chips : []).map((c: any) => ({ label: str(c?.label), good: true })).filter((c: any) => c.label);
      if (!chips.length) return { step, source: 'fallback' };
      s.chips = chips;
      s.need = typeof data?.need === 'number' ? Math.max(1, Math.min(Math.round(data.need), chips.length)) : Math.min(step.need, chips.length);
    }
    return { step: s, source: 'dynamic' };
  }
  if (spec.job === 'propose') {
    const raw: any[] = Array.isArray(data?.candidates) ? data.candidates : [];
    const proposals: Proposal[] = raw
      .slice(0, cap ?? 3)
      .map((c, i) => ({ id: String(c?.id ?? `cand${i}`), label: String(c?.label ?? '') }))
      .filter((c) => c.label);
    return { step, proposals, source: 'dynamic' };
  }
  // challenge
  return {
    step,
    challenge: { voice: String(data?.voice ?? spec.voice ?? 'Analyst'), text: String(data?.text ?? '') },
    source: 'dynamic',
  };
}
