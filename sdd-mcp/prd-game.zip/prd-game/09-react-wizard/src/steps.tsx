import { useEffect, useState } from 'react';
import type {
  Step, Piece, Move, IntroStep, DepthGateStep, SingleSelectStep, SortBinsStep,
  PairSelectStep, PatternCheckStep, RippleStep, MultiSelectStep,
  PayoffMatrixStep, OrderStep, AssembleStep,
} from './types';
import { getStepContent, type GameState, type StepContent, type Proposal } from './dynamic';

const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* --- per-step answers that survive Back/Next navigation ---
   StepView remounts on every step change (key={idx} in App), so local
   useState resets. This module-level store lives outside React and keeps
   each step's selection keyed by step id. Cleared on "Start over". */
const _store = new Map<string, unknown>();
export function clearWizardState() { _store.clear(); }
function usePersisted<T>(key: string, init: T | (() => T)) {
  const [val, setVal] = useState<T>(() =>
    _store.has(key) ? (_store.get(key) as T) : (typeof init === 'function' ? (init as () => T)() : init));
  useEffect(() => { _store.set(key, val); }, [key, val]);
  return [val, setVal] as const;
}

/** Render a trusted HTML string from the config (titles, why-panels, etc.). */
function H({ tag = 'div', html, className }: { tag?: keyof JSX.IntrinsicElements; html: string; className?: string }) {
  const Tag = tag as 'div';
  return <Tag className={className} dangerouslySetInnerHTML={{ __html: html }} />;
}

function Meta({ step }: { step: Step }) {
  if (!step.badge) return null;
  return (
    <div className="stepmeta">
      <span className="badge">{step.badge}</span>
      {step.move && <span className="move">the move → {step.move}</span>}
    </div>
  );
}

function Head({ step }: { step: Step }) {
  const [help, setHelp] = usePersisted<boolean>(step.id + ':help', false);
  return (
    <>
      <Meta step={step} />
      {step.title && (
        <div className="prompt-row">
          <H tag="h2" className="prompt" html={step.title} />
          {step.help && <button className="whatsthis" onClick={() => setHelp((h) => !h)}>{help ? 'hide' : 'what’s this?'}</button>}
        </div>
      )}
      {step.sub && <H tag="p" className="sub" html={step.sub} />}
      {step.help && help && <H className="step-help" html={step.help} />}
    </>
  );
}

function Why({ html, show }: { html?: string; show: boolean }) {
  if (!html) return null;
  return <H className={'why' + (show ? '' : ' hidden')} html={html} />;
}

/* --- authored character: one in-character line at a marquee beat (Phase 1) ---
   Skippable. `trigger:'enter'` shows on arrival, `'done'` (default) after the
   step is solved. `once` lines don't re-appear when you navigate back to the
   step — a snapshot of "seen before this mount" decides visibility. */
export function Narration({ step, done }: { step: Step; done: boolean }) {
  const lines = step.narration;
  const [dismissed, setDismissed] = usePersisted<Record<number, boolean>>(step.id + ':narr-x', {});
  const [seen, setSeen] = usePersisted<Record<number, boolean>>(step.id + ':narr-seen', {});
  const [seenAtMount] = useState(() => ({ ...seen })); // snapshot before this mount marks anything
  useEffect(() => {
    if (!lines) return;
    lines.forEach((l, i) => {
      const trig = l.trigger || 'done';
      const showing = trig === 'enter' || (trig === 'done' && done);
      if (showing && l.once) setSeen((s) => (s[i] ? s : { ...s, [i]: true }));
    });
  }, [done, lines, setSeen]);
  if (!lines || !lines.length) return null;
  return (
    <div className="narration">
      {lines.map((l, i) => {
        const trig = l.trigger || 'done';
        const show = trig === 'enter' || (trig === 'done' && done);
        if (!show || dismissed[i] || (l.once && seenAtMount[i])) return null;
        return (
          <div className="narr" key={i}>
            {l.voice && <span className="narr-voice">{l.voice}</span>}
            <span className="narr-text" dangerouslySetInnerHTML={{ __html: l.text }} />
            <button className="narr-x" aria-label="dismiss" onClick={() => setDismissed((d) => ({ ...d, [i]: true }))}>×</button>
          </div>
        );
      })}
    </div>
  );
}

/* ----------------------------- intro ----------------------------- */
function Intro({ step, onDone, feature, onFeature }: { step: IntroStep; onDone: () => void; feature?: string; onFeature?: (v: string) => void }) {
  // In dynamic mode the intro asks for the user's own feature; the wizard then
  // runs on it. Without a featurePrompt this is the static hero, unchanged.
  const dyn = !!step.featurePrompt;
  useEffect(() => { if (!dyn) onDone(); }, [dyn]); // eslint-disable-line
  useEffect(() => { if (dyn && (feature || '').trim()) onDone(); }, [dyn, feature]); // eslint-disable-line
  return (
    <div className="hero-card">
      {step.eyebrow && <div className="eye">{step.eyebrow}</div>}
      {step.title && <H tag="h1" html={step.title} />}
      {step.lede && <H tag="p" html={step.lede} />}
      {step.flow && <div className="flow">{step.flow.map((f, i) => <span key={i}>{f}</span>)}</div>}
      {dyn && (
        <div className="feature-in">
          <label htmlFor="feature">{step.featurePrompt}</label>
          <input id="feature" type="text" value={feature || ''} placeholder="e.g. let customers cancel a subscription from the account page"
            onChange={(e) => onFeature?.(e.target.value)} />
        </div>
      )}
      {step.footnote && <p style={{ fontSize: 14, color: 'var(--ink-faint)', margin: 0 }}>{step.footnote}</p>}
    </div>
  );
}

/* --------------------------- depth-gate -------------------------- */
function DepthGate({ step, onDone }: { step: DepthGateStep; onDone: () => void }) {
  const [ans, setAns] = usePersisted<Record<string, string>>(step.id + ':ans', {});
  const [open, setOpen] = usePersisted<Record<string, boolean>>(step.id + ':open', {});
  const [a0, a1] = step.axes;
  const both = a0 && a1 && ans[a0.key] && ans[a1.key];
  useEffect(() => { if (both) onDone(); }, [both]); // eslint-disable-line
  return (
    <>
      <Head step={step} />
      <div className="depthq-list">
        {step.axes.map((ax, qi) => (
          <div className="depthq" key={ax.key}>
            <div className="depthq-head">
              <div className="depthq-prompt"><span className="depthq-n">Question {qi + 1}</span> {ax.prompt}</div>
              {ax.explain && (
                <button className="whatsthis" onClick={() => setOpen((o) => ({ ...o, [ax.key]: !o[ax.key] }))}>
                  {open[ax.key] ? 'hide' : 'what’s this?'}
                </button>
              )}
            </div>
            {ax.hint && <div className="depthq-hint">{ax.hint}</div>}
            <div className="yn">
              {ax.options.map((o) => (
                <button key={o.value}
                  className={'ynbtn' + (ans[ax.key] === o.value ? (o.tone === 'neg' ? ' on-no' : ' on-yes') : '')}
                  onClick={() => setAns((s) => ({ ...s, [ax.key]: o.value }))}>{o.label}</button>
              ))}
            </div>
            {ax.explain && open[ax.key] && <H className="depthq-explain" html={ax.explain} />}
          </div>
        ))}
      </div>
      <div className="mx" style={{ marginTop: 18, maxWidth: 520 }}>
        <div className="mxl" />
        {a0.options.map((c) => <div className="mxl" key={c.value}>{(c.short || c.label).toUpperCase()}</div>)}
        {a1.options.map((row) => (
          <div className="mxrow" key={row.value}>
            <div className="mxl side">{(row.short || row.label).toUpperCase()}</div>
            {a0.options.map((col) => {
              const m = step.matrix[`${col.value}__${row.value}`];
              const active = both && ans[a0.key] === col.value && ans[a1.key] === row.value;
              return <div className={'mxc' + (active ? ' ' + (m?.tone === 'bad' ? 'bad' : 'good') : '')} key={col.value}><div className="o">{m?.label}</div></div>;
            })}
          </div>
        ))}
      </div>
      {step.matrixNote && <H className="matrixnote" html={step.matrixNote} />}
      <Why html={step.why} show={!!both} />
    </>
  );
}

/* ------------------------- single-select ------------------------- */
type ReportFn = (texts: string[], opts?: { channel?: string; cat?: string }) => void;

function SingleSelect({ step, onDone, dynamic, onReport }: { step: SingleSelectStep; onDone: () => void; dynamic?: boolean; onReport?: ReportFn }) {
  if (step.multi || step.allowCustom) return <MultiPick step={step} onDone={onDone} onReport={onReport} />;
  const [picked, setPicked] = usePersisted<number | null>(step.id + ':picked', null);
  const done = picked !== null;
  useEffect(() => { if (done) { onDone(); if (dynamic && picked != null) onReport?.([plain(step.options[picked].label)]); } }, [done, picked]); // eslint-disable-line
  return (
    <>
      <Head step={step} />
      {step.options.map((o, i) => {
        // Dynamic mode has no answer key — discovering it is the game. So no
        // right/wrong, just a neutral "picked" state the user records.
        const cls = dynamic ? (i === picked ? 'picked' : '') : (done ? (i === picked ? (o.correct ? 'right' : 'wrong') : (o.correct ? 'right' : '')) : '');
        const tag = dynamic || !done ? '' : i === picked ? o.tag : o.correct ? '← the right pick' : '';
        return (
          <button key={i} className={'opt ' + cls}
            onClick={() => setPicked(i)}>
            <H tag="span" html={o.label} />
            {tag && <span className="tagx">{tag}</span>}
          </button>
        );
      })}
      <Why html={dynamic ? undefined : step.why} show={done} />
    </>
  );
}

/* multi-pick variant of single-select: toggle any number of options on/off and
   write in your own. No answer key — the user's real picks are what's recorded. */
function MultiPick({ step, onDone, onReport }: { step: SingleSelectStep; onDone: () => void; onReport?: ReportFn }) {
  const [sel, setSel] = usePersisted<Record<string, boolean>>(step.id + ':msel', {});
  const [customs, setCustoms] = usePersisted<string[]>(step.id + ':custom', []);
  const [draft, setDraft] = useState('');
  const labelFor = (k: string) => k[0] === 'b' ? plain(step.options[+k.slice(1)]?.label || '') : (customs[+k.slice(1)] || '');
  const chosen = Object.keys(sel).filter((k) => sel[k]);
  const done = chosen.length > 0;
  const cat = step.discoveries?.[0]?.[2];
  const key = chosen.join('|') + '#' + customs.join('|');
  useEffect(() => { if (done) onDone(); onReport?.(chosen.map(labelFor), cat ? { cat } : undefined); }, [key]); // eslint-disable-line
  function addCustom() {
    const v = draft.trim();
    if (!v) return;
    setSel((s) => ({ ...s, ['c' + customs.length]: true }));
    setCustoms((c) => [...c, v]);
    setDraft('');
  }
  return (
    <>
      <Head step={step} />
      {step.options.map((o, i) => {
        const k = 'b' + i;
        return (
          <button key={k} className={'opt' + (sel[k] ? ' picked' : '')} onClick={() => setSel((s) => ({ ...s, [k]: !s[k] }))}>
            <H tag="span" html={o.label} />
          </button>
        );
      })}
      {customs.map((c, j) => {
        const k = 'c' + j;
        return (
          <button key={k} className={'opt custom' + (sel[k] ? ' picked' : '')} onClick={() => setSel((s) => ({ ...s, [k]: !s[k] }))}>
            <span>{c}</span>
            <span className="opt-rm" role="button" aria-label="remove"
              onClick={(e) => { e.stopPropagation(); setSel((s) => { const n = { ...s }; delete n[k]; return n; }); setCustoms((cs) => cs.filter((_, x) => x !== j)); }}>×</span>
          </button>
        );
      })}
      {step.allowCustom && (
        <div className="writein">
          <input type="text" value={draft} placeholder="write your own…"
            onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addCustom(); }} />
          <button className="btn ghost" onClick={addCustom}>+ Add</button>
        </div>
      )}
      <div className="pickhint">{done ? `${chosen.length} selected — tap again to unselect` : 'select one or more'}</div>
    </>
  );
}

/* --------------------------- sort-bins --------------------------- */
function SortBins({ step, onDone, dynamic, onReport }: { step: SortBinsStep; onDone: () => void; dynamic?: boolean; onReport?: (t: string[]) => void }) {
  const [sel, setSel] = useState<number | null>(null);
  const [placed, setPlaced] = usePersisted<Record<number, boolean>>(step.id + ':placed', {});
  const [revealed, setRevealed] = usePersisted<boolean>(step.id + ':revealed', false);
  const [drag, setDrag] = useState<number | null>(null);
  const [over, setOver] = useState<string | null>(null);
  const [justDropped, setJustDropped] = useState<string | null>(null); // bin accept-pulse
  const dropped: Record<string, string[]> = {};
  const allPlaced = step.chips.every((_, i) => placed[i]);
  useEffect(() => { if (allPlaced) { setRevealed(true); onDone(); if (dynamic) onReport?.(step.chips.map((c) => plain(c.label))); } }, [allPlaced]); // eslint-disable-line
  step.chips.forEach((c, i) => { if (placed[i]) (dropped[c.bin] ||= []).push(c.label); });
  function placeChip(idx: number) {
    if (idx == null || placed[idx]) return;
    if (step.chips[idx].reveal) setRevealed(true);
    if (!reduce) { const bin = step.chips[idx].bin; setJustDropped(bin); setTimeout(() => setJustDropped(null), 260); }
    setPlaced((p) => ({ ...p, [idx]: true }));
    setSel(null);
  }
  const active = sel !== null || drag !== null;
  function autoSort() {
    if (!reduce) setJustDropped('*');
    setPlaced(Object.fromEntries(step.chips.map((_, i) => [i, true])));
    setSel(null);
    if (!reduce) setTimeout(() => setJustDropped(null), 260);
  }
  return (
    <>
      <Head step={step} />
      <div className="pool">
        {step.chips.map((c, i) => placed[i] ? null : (
          <button key={i} draggable
            className={'chip' + (sel === i ? ' sel' : '') + (drag === i ? ' dragging' : '')}
            onClick={() => setSel((s) => (s === i ? null : i))}
            onDragStart={(e) => { setDrag(i); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(i)); }}
            onDragEnd={() => { setDrag(null); setOver(null); }}>{c.label}</button>
        ))}
        {!allPlaced && <button className="autofill" onClick={autoSort}>⤓ Auto-sort into types</button>}
      </div>
      <div className="bins">
        {step.bins.map((bin) => (
          <div key={bin.key}
            className={'bin' + (active ? ' active' : '') + (over === bin.key ? ' over' : '') + (justDropped === bin.key ? ' just-dropped' : '')}
            onClick={() => { if (sel !== null) placeChip(sel); }}
            onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; if (over !== bin.key) setOver(bin.key); }}
            onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(null); }}
            onDrop={(e) => {
              e.preventDefault();
              const idx = drag ?? Number(e.dataTransfer.getData('text/plain'));
              placeChip(idx);
              setDrag(null); setOver(null);
            }}>
            <h4><span className="d" style={{ background: bin.color }} />{bin.label}</h4>
            <div className="drop">{(dropped[bin.key] || []).map((t, j) => <span className="dchip" key={j}>{t}</span>)}</div>
          </div>
        ))}
      </div>
      <Why html={dynamic ? undefined : step.why} show={revealed} />
    </>
  );
}

/* -------------------------- pair-select -------------------------- */
function PairSelect({ step, onDone, dynamic, onReport }: { step: PairSelectStep; onDone: () => void; dynamic?: boolean; onReport?: ReportFn }) {
  const [done, setDone] = usePersisted<Record<number, boolean>>(step.id + ':done', {});
  const [openq, setOpenq] = usePersisted<Record<number, boolean>>(step.id + ':openq', {});
  const all = step.pairs.every((_, i) => done[i]);
  const doneKey = step.pairs.map((_, i) => (done[i] ? '1' : '0')).join('');
  const oqKey = step.pairs.map((_, i) => (openq[i] ? '1' : '0')).join('');
  useEffect(() => { if (all) onDone(); if (dynamic) onReport?.(step.pairs.filter((_, i) => done[i]).map((p) => `${plain(p.a)} vs ${plain(p.b)}`)); }, [doneKey]); // eslint-disable-line
  // Open questions ride a separate tray channel, so they accumulate alongside
  // (not instead of) the conflicts — things to dig into for more detail later.
  useEffect(() => { onReport?.(step.pairs.filter((_, i) => openq[i]).map((p) => `${plain(p.a)} ⚔ ${plain(p.b)}`), { channel: 'oq', cat: 'open-question' }); }, [oqKey]); // eslint-disable-line
  return (
    <>
      <Head step={step} />
      <div className="pairs">
        {step.pairs.map((p, i) => (
          <div key={i} className={'pair' + (done[i] ? ' done ' + p.type : '') + (openq[i] ? ' openq' : '')} onClick={() => setDone((d) => ({ ...d, [i]: !d[i] }))}>
            <div className="vs">
              <span className="side">{p.a}</span>
              <span className="x">✕</span>
              <span className="side">{p.b}</span>
              {done[i] && p.type === 'conflict' && <span className="spark" aria-hidden="true" />}
              <button className={'oq-btn' + (openq[i] ? ' on' : '')}
                onClick={(e) => { e.stopPropagation(); setOpenq((o) => ({ ...o, [i]: !o[i] })); }}>
                {openq[i] ? '◆ open question' : '◇ open question'}
              </button>
            </div>
            <div className="res">
              <span className="tag">{done[i] ? (dynamic ? 'noted — a tension to weigh' : (p.type === 'conflict' ? 'hidden requirement' : 'aligned — no requirement')) : ''}</span>
              {!dynamic && done[i] && <span dangerouslySetInnerHTML={{ __html: p.res }} />}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

/* ------------------------- pattern-check ------------------------- */
type PatAns = 'yes' | 'no' | 'unsure';
function PatternCheck({ step, onDone }: { step: PatternCheckStep; onDone: () => void }) {
  const [ans, setAns] = usePersisted<Record<number, PatAns>>(step.id + ':ans', {});
  const answered = Object.keys(ans).length;
  // "applies" = the user said it shows up (yes), or it really fires and they
  // weren't sure — either way it's a shape worth carrying forward.
  const applies = step.patterns.filter((_, i) => ans[i] === 'yes' || (ans[i] === 'unsure' && step.patterns[i].fires)).length;
  const toCheck = Object.values(ans).filter((v) => v === 'unsure').length;
  const all = answered >= step.patterns.length;
  useEffect(() => { if (all) onDone(); }, [all]); // eslint-disable-line
  const set = (i: number, v: PatAns) => setAns((s) => ({ ...s, [i]: v }));
  return (
    <>
      <Head step={step} />
      <div className="patgrid">
        {step.patterns.map((p, i) => {
          const a = ans[i];
          const tone = a === undefined ? '' : a === 'unsure' ? 'unsure' : p.fires ? 'fires' : 'nofire';
          const verdict = a === 'unsure' ? 'worth checking — here’s the shape' : p.fires ? 'applies — here’s the fix' : 'doesn’t apply here';
          return (
            <div key={i} className={'pcard' + (a !== undefined ? ' answered ' + tone : '')}>
              <div className="pcard-inner">
                <div className="pcard-front">
                  <div className="pn">0{i + 1}</div>
                  <div className="q">{p.q}</div>
                  <div className="ans yn">
                    <button className="ynbtn" onClick={() => set(i, 'yes')}>{step.yesLabel || 'Applies to us'}</button>
                    <button className="ynbtn" onClick={() => set(i, 'no')}>{step.noLabel || 'Doesn’t apply'}</button>
                    <button className="ynbtn unsure" onClick={() => set(i, 'unsure')}>{step.unsureLabel || 'I don’t know yet'}</button>
                  </div>
                </div>
                <div className="pcard-back">
                  <div className="verdict">{verdict}</div>
                  <div className="shape">{p.shape}</div>
                  <div className="fix">{p.fix}</div>
                  <button className="pcard-change" onClick={() => setAns((s) => { const n = { ...s }; delete n[i]; return n; })}>↺ change my answer</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div className="firecount">
        {step.counterLabel || 'shapes that apply so far'}: <b>{applies}</b> / {step.patterns.length}
        {toCheck > 0 && <span className="tocheck"> · {toCheck} to look into</span>}
      </div>
    </>
  );
}

/* ----------------------------- ripple ---------------------------- */
function Ripple({ step, onDone }: { step: RippleStep; onDone: () => void }) {
  const [shown, setShown] = usePersisted(step.id + ':shown', 1);
  // The newest-revealed stage gets the one-shot "arrive" animation (advance
  // toward the viewer). Only while live — not on Back/Next re-entry.
  const [arriving, setArriving] = useState(-1);
  const [notes, setNotes] = usePersisted<Record<number, string>>(step.id + ':notes', {});
  const [editing, setEditing] = useState<Record<number, boolean>>({});
  const all = shown >= step.stages.length;
  useEffect(() => { if (all) onDone(); }, [all]); // eslint-disable-line
  function reveal() {
    setShown((n) => {
      const nx = n + 1;
      if (!reduce) { setArriving(nx - 1); setTimeout(() => setArriving(-1), 600); }
      return nx;
    });
  }
  return (
    <>
      <Head step={step} />
      <div className="ripple">
        {step.stages.map((s, i) => (
          <div key={i}>
            <div className={'rstep' + (s.danger ? ' danger' : '') + (i < shown ? ' show' : '') + (i === arriving ? ' arriving' : '')}>
              <span className="ord">{s.ord}</span>
              <div className="rtxt">
                <span dangerouslySetInnerHTML={{ __html: s.text }} />
                {i < shown && (editing[i] || notes[i] !== undefined ? (
                  <div className="rnote">
                    <textarea value={notes[i] ?? ''} placeholder="your note on this stage…" rows={2}
                      onChange={(e) => setNotes((n) => ({ ...n, [i]: e.target.value }))}
                      onBlur={() => { if (!(notes[i] ?? '').trim()) { setNotes((n) => { const x = { ...n }; delete x[i]; return x; }); } setEditing((ed) => ({ ...ed, [i]: false })); }} />
                  </div>
                ) : (
                  <button className="rnote-add" onClick={() => setEditing((ed) => ({ ...ed, [i]: true }))}>+ add a note</button>
                ))}
              </div>
            </div>
            {i < step.stages.length - 1 && <div className="rconn" />}
          </div>
        ))}
      </div>
      {!all && <button className="btn ghost" style={{ marginTop: 16 }} onClick={reveal}>{step.revealLabel || 'Reveal →'}</button>}
      <Why html={step.why} show={all} />
    </>
  );
}

/* -------------------------- multi-select ------------------------- */
function MultiSelect({ step, onDone, dynamic, onReport }: { step: MultiSelectStep; onDone: () => void; dynamic?: boolean; onReport?: ReportFn }) {
  const [on, setOn] = usePersisted<Record<number, boolean>>(step.id + ':on', {});
  const goodCount = step.chips.filter((c, i) => on[i] && c.good).length;
  const done = goodCount >= step.need;
  const onKey = step.chips.map((_, i) => (on[i] ? '1' : '0')).join('');
  useEffect(() => { if (done) onDone(); if (dynamic) onReport?.(step.chips.filter((_, i) => on[i]).map((c) => plain(c.label))); }, [onKey]); // eslint-disable-line
  return (
    <>
      <Head step={step} />
      <div className="ms">
        {step.chips.map((c, i) => (
          <button key={i} className={'mschip' + (on[i] ? (c.good ? ' on' : ' decoy-on') : '')}
            onClick={() => setOn((s) => ({ ...s, [i]: !s[i] }))}>
            {c.label}{on[i] && !c.good ? '  ✕ ' + (c.decoyTag || 'vanity') : ''}
          </button>
        ))}
      </div>
      <Why html={dynamic ? undefined : step.why} show={done} />
    </>
  );
}

/* ------------------------- payoff-matrix ------------------------- */
function PayoffMatrix({ step, onDone }: { step: PayoffMatrixStep; onDone: () => void }) {
  const [pick, setPick] = usePersisted<string | null>(step.id + ':pick', null);
  const dominant = step.rows.find((r) => r.dominant);
  const ok = pick !== null && pick === dominant?.key;
  useEffect(() => { if (ok) onDone(); }, [ok]); // eslint-disable-line
  return (
    <>
      <Head step={step} />
      <div className="mx">
        <div className="mxl" />
        {step.cols.map((c, i) => <div className="mxl" key={i}>{c}</div>)}
        {step.rows.map((row) => {
          const reveal = pick === row.key;
          return (
            <div className="mxrow" key={row.key}>
              <div className="mxl side" style={{ cursor: 'pointer' }} onClick={() => setPick(row.key)}>{row.label}</div>
              {row.cells.map((cell, ci) => (
                <div key={ci} className={'mxc' + (reveal ? ' ' + (cell.tone === 'bad' ? 'bad' : 'good') : '')} onClick={() => setPick(row.key)}>
                  <div className="o">{cell.o}</div>
                </div>
              ))}
            </div>
          );
        })}
      </div>
      <div className="mxpick">{pick === null ? (step.pickPrompt || 'tap a row.') : ok ? (step.okText || '') : (step.retryText || '')}</div>
      <Why html={step.why} show={ok} />
    </>
  );
}

/* ----------------------------- order ----------------------------- */
function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function Order({ step, onDone }: { step: OrderStep; onDone: () => void }) {
  const [shuffled] = usePersisted(step.id + ':shuffled', () => shuffle(step.items));
  const [picked, setPicked] = usePersisted<string[]>(step.id + ':picked', []);
  const [shake, setShake] = useState<string | null>(null);
  const done = picked.length === step.correct.length;
  useEffect(() => { if (done) onDone(); }, [done]); // eslint-disable-line
  function tap(id: string) {
    if (picked.includes(id)) return;
    if (step.correct[picked.length] !== id) { setShake(id); setTimeout(() => setShake(null), 240); return; }
    setPicked((p) => [...p, id]);
  }
  const hasDetail = step.items.some((it) => it.detail);
  return (
    <>
      <Head step={step} />
      <div className="ord-pool">
        {shuffled.map((it) => (
          <button key={it.id} className={'ord-chip' + (picked.includes(it.id) ? ' used' : '')}
            style={shake === it.id ? { transform: 'translateX(4px)' } : undefined} onClick={() => tap(it.id)}>{it.label}</button>
        ))}
      </div>
      <div className="ord-tools">
        {!done && <button className="autofill" onClick={() => setPicked(step.correct.slice())}>⤓ Auto-order the rollout</button>}
        {picked.length > 0 && <button className="ord-reset" onClick={() => setPicked([])}>↺ reset</button>}
      </div>
      <div className="ord-line">
        {picked.map((id, i) => {
          const it = step.items.find((x) => x.id === id)!;
          return <span key={id}>{i > 0 && <span className="arr">→ </span>}<span className="slot">{it.label}</span></span>;
        })}
      </div>
      {hasDetail && (
        <ol className="ord-detail">
          {picked.map((id, i) => {
            const it = step.items.find((x) => x.id === id)!;
            return it.detail ? <li key={id}><b>{i + 1}. {it.label}</b> — <span dangerouslySetInnerHTML={{ __html: it.detail }} /></li> : null;
          })}
        </ol>
      )}
      <Why html={step.why} show={done} />
    </>
  );
}

/* ---------------------------- assemble --------------------------- */
const plain = (html: string) => html.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').trim();

/** The dossier: a structured residue of the session a Gandalf skill can read to
 *  draft the full PRD. Built from what the user actually surfaced — the wizard
 *  records, it does not write the PRD itself. */
function buildDossier(step: AssembleStep, pieces: Piece[], feature?: string, moves?: Move[]) {
  const byCat: Record<string, string[]> = {};
  pieces.forEach((p) => (byCat[p.cat] ||= []).push(p.text));
  return {
    gandalf: 'react-wizard/1',
    feature: feature || null,
    outcome: (byCat[step.doc.leadFrom] || [])[0] || step.doc.fallbackLead,
    discoveries: byCat,
    prd_outline: step.sections.map((s) => ({ title: plain(s.title), source: s.src, items: byCat[s.src] || [] })),
    pieces,
    moves: moves || [],
  };
}

function downloadJson(filename: string, obj: unknown) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

function Assemble({ step, pieces, onDone, feature, moves }: { step: AssembleStep; pieces: Piece[]; onDone: () => void; feature?: string; moves?: Move[] }) {
  const [mounted, setMounted] = useState(false);
  const [copied, setCopied] = useState(false);
  useEffect(() => { onDone(); const t = setTimeout(() => setMounted(true), reduce ? 0 : 60); return () => clearTimeout(t); }, []); // eslint-disable-line
  const byCat: Record<string, string[]> = {};
  pieces.forEach((p) => (byCat[p.cat] ||= []).push(p.text));
  const lead = (byCat[step.doc.leadFrom] || [])[0] || step.doc.fallbackLead;
  const dossier = () => buildDossier(step, pieces, feature, moves);
  const slug = (feature || 'gandalf').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'gandalf';
  async function copy() {
    try { await navigator.clipboard.writeText(JSON.stringify(dossier(), null, 2)); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch { /* ignore */ }
  }
  return (
    <>
      <Meta step={step} />
      <H tag="h2" className="prompt" html={step.title || ''} />
      <div className="prd">
        <div className="ph">{step.doc.kicker}</div>
        <h2 dangerouslySetInnerHTML={{ __html: step.doc.heading }} />
        <p className="lead">{lead}</p>
        {step.sections.map((sec, i) => (
          <div key={i} className={'psec' + (mounted ? ' in' : '')} style={{ transitionDelay: (reduce ? 0 : 0.12 * (i + 1)) + 's' }}>
            <h4><span dangerouslySetInnerHTML={{ __html: sec.title }} /> {sec.note && <span className="src">{sec.note}</span>}</h4>
            <ul>{(byCat[sec.src] || []).map((t, j) => <li key={j} dangerouslySetInnerHTML={{ __html: t }} />)}</ul>
          </div>
        ))}
      </div>
      <div className="prd-actions">
        <button className="btn ghost" onClick={() => downloadJson(`gandalf-dossier-${slug}.json`, dossier())}>↓ Download PRD input (JSON)</button>
        <button className="btn ghost" onClick={copy}>{copied ? '✓ copied' : 'Copy JSON'}</button>
        <span className="prd-actions-hint">feed this to a Gandalf skill to draft the full PRD</span>
      </div>
      {step.closingWhy && <H className="why" html={step.closingWhy} />}
    </>
  );
}

/* --------------------------- dispatcher -------------------------- */
export function StepView({ step, pieces, onDone, dynamic, feature, onFeature, moves, onReport }: {
  step: Step; pieces: Piece[]; onDone: () => void;
  dynamic?: boolean; feature?: string; onFeature?: (v: string) => void; moves?: Move[]; onReport?: ReportFn;
}) {
  switch (step.type) {
    case 'intro': return <Intro step={step} onDone={onDone} feature={feature} onFeature={onFeature} />;
    case 'depth-gate': return <DepthGate step={step} onDone={onDone} />;
    case 'single-select': return <SingleSelect step={step} onDone={onDone} dynamic={dynamic} onReport={onReport} />;
    case 'sort-bins': return <SortBins step={step} onDone={onDone} dynamic={dynamic} onReport={onReport} />;
    case 'pair-select': return <PairSelect step={step} onDone={onDone} dynamic={dynamic} onReport={onReport} />;
    case 'pattern-check': return <PatternCheck step={step} onDone={onDone} />;
    case 'ripple': return <Ripple step={step} onDone={onDone} />;
    case 'multi-select': return <MultiSelect step={step} onDone={onDone} dynamic={dynamic} onReport={onReport} />;
    case 'payoff-matrix': return <PayoffMatrix step={step} onDone={onDone} />;
    case 'order': return <Order step={step} onDone={onDone} />;
    case 'assemble': return <Assemble step={step} pieces={pieces} onDone={onDone} feature={feature} moves={moves} />;
  }
}

/* --------------------- dynamic-mode wrapper ---------------------- */
/* The ONE seam: a dynamic step fetches live content (via the Claude CLI behind
   /api/step), shows a loading state, then slots the result into the SAME
   renderer. Any failure falls back to the static step — never breaks. */
function StepLoading({ step }: { step: Step }) {
  return (
    <>
      <Head step={step} />
      <div className="dyn-loading"><span className="spin" />thinking through your feature…</div>
    </>
  );
}

function ChallengeLine({ voice, text }: { voice: string; text: string }) {
  return (
    <div className="narration">
      <div className="narr challenge">
        <span className="narr-voice">{voice}</span>
        <span className="narr-text">{text}</span>
      </div>
    </div>
  );
}

function Proposals({ items }: { items: Proposal[] }) {
  return (
    <div className="proposals">
      <div className="prop-label">candidates to consider — accept, reject, or edit. Nothing is filled in for you.</div>
      <div className="pool">{items.map((p) => <span className="chip cand" key={p.id}>{p.label}</span>)}</div>
    </div>
  );
}

export function DynamicStepView({ step, pieces, gameState, onDone, feature, onFeature, onReport, onFallback }: {
  step: Step; pieces: Piece[]; gameState: GameState; onDone: () => void;
  feature?: string; onFeature?: (v: string) => void; onReport?: ReportFn; onFallback?: () => void;
}) {
  const [content, setContent] = usePersisted<StepContent | null>(step.id + ':content', null);
  const [loading, setLoading] = useState(!content);
  useEffect(() => {
    if (content) { console.log('%c[gandalf:dynamic]', 'color:#0E6F66;font-weight:700', 'reusing cached content for', step.id); return; }
    console.log('%c[gandalf:dynamic]', 'color:#0E6F66;font-weight:700', `dynamic step "${step.id}" mounted (${step.dynamic?.job}) → fetching…`);
    let alive = true;
    setLoading(true);
    getStepContent(step, gameState).then((c) => { if (alive) { setContent(c); setLoading(false); } });
    return () => { alive = false; };
  }, [step.id]); // eslint-disable-line
  // Offline: tell the engine this step fell back to the example, so it commits
  // the authored discoveries (the user's picks here can't be reported).
  useEffect(() => { if (content?.source === 'fallback') onFallback?.(); }, [content?.source]); // eslint-disable-line
  if (loading || !content) return <StepLoading step={step} />;
  const isDyn = content.source === 'dynamic'; // a fallback renders as the plain static step
  return (
    <>
      <StepView step={content.step} pieces={pieces} onDone={onDone} dynamic={isDyn} feature={feature} onFeature={onFeature} onReport={onReport} />
      {content.proposals && content.proposals.length > 0 && <Proposals items={content.proposals} />}
      {content.challenge && content.challenge.text && <ChallengeLine voice={content.challenge.voice} text={content.challenge.text} />}
      {content.source === 'fallback' && <span className="fallback-pill">offline · showing the example</span>}
    </>
  );
}
