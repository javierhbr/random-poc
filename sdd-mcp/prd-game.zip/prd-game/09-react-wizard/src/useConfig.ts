import { useEffect, useState } from 'react';
import type { GandalfConfig } from './types';

/**
 * Where the wizard gets its GandalfConfig. The config is DATA loaded at runtime
 * from a JSON file — never bundled TS. `file` is the path an agent edits to
 * apply comments (recorded in each comment's target.file).
 */
export type ConfigSource = { url: string; file: string; label: string };

const DEFAULT: ConfigSource = { url: '/configs/ivr.json', file: 'public/configs/ivr.json', label: 'ivr' };

/** Turn a `?config=` value into a source. Accepts a bare name, a served path, or a URL. */
export function specToSource(spec: string): ConfigSource {
  const s = spec.trim();
  if (/^https?:\/\//.test(s)) return { url: s, file: s, label: s };
  if (s.includes('/') || s.endsWith('.json')) {
    const url = s.startsWith('/') ? s : '/' + s;
    return { url, file: 'public' + url, label: url };
  }
  return { url: `/configs/${s}.json`, file: `public/configs/${s}.json`, label: s };
}

/** Read the source from the URL: ?configFile=<abs disk path> wins, else ?config=, else default. */
export function sourceFromUrl(): ConfigSource {
  const p = new URLSearchParams(window.location.search);
  const cf = p.get('configFile');
  if (cf) return { url: '/load-config?path=' + encodeURIComponent(cf), file: cf, label: cf };
  const c = p.get('config');
  return c ? specToSource(c) : DEFAULT;
}

export function useConfig() {
  const [config, setConfig] = useState<GandalfConfig | null>(null);
  const [source, setSource] = useState<ConfigSource>(() => sourceFromUrl());
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!source.url) return; // in-memory config (file picker) — nothing to fetch
    let alive = true;
    setConfig(null); setError(null);
    fetch(source.url)
      .then((r) => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then((j) => { if (alive) setConfig(j as GandalfConfig); })
      .catch((e) => { if (alive) setError(String(e?.message || e)); });
    return () => { alive = false; };
  }, [source.url]);

  /** Load an in-memory config (from the file picker) — no fetch; not round-trippable to disk. */
  function loadObject(obj: GandalfConfig, file: string) { setError(null); setSource({ url: '', file, label: file }); setConfig(obj); }
  function loadSpec(spec: string) { setSource(specToSource(spec)); }

  return { config, source, error, loadObject, loadSpec };
}
