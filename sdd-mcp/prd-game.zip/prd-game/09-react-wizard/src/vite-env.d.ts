/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Base URL of the standalone dynamic backend (server/api.mjs). Empty = same origin. */
  readonly VITE_API_BASE?: string;
}
interface ImportMeta {
  readonly env: ImportMetaEnv;
}
