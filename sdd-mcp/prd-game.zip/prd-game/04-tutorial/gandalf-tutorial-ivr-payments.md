# Tutorial: Writing a PRD with Gandalf

### A worked example — adding payments to an IVR customer-service platform

This tutorial shows you how to *use* the Game-Theoretic Discovery Framework, step by step, on one realistic feature. By the end you'll have watched a vague request ("let customers pay over the phone") turn into a defended PRD — and you'll have seen the framework surface roughly a dozen requirements that a normal feature-list PRD would have missed until production.

You don't need a background in payments or telephony. Every term is explained the first time it appears.

---

## The setup: what we're working with

**CustomerCo** runs a phone-based customer-service platform. When a customer calls, they reach an **IVR** — an *Interactive Voice Response* system, the automated "press 1 for billing, press 2 for support" menu that answers the phone and collects keypad presses or spoken input. Around that IVR sits a whole system:

- **The IVR platform** — answers calls, plays prompts, collects keypad tones (called *DTMF* — the beeps your phone makes) and voice.
- **A telephony carrier** — the outside vendor that actually connects the phone calls.
- **Orchestration APIs** — the services the IVR calls to look things up: "what's this account's balance?", "is this caller verified?"
- **The account & billing database** — balances, due dates, payment history.
- **A data pipeline** — a stream that carries events from calls into a warehouse for reporting, analytics, and finance reconciliation.
- **Customers** — calling in, often stressed, sometimes in public, unable to *see* anything. Only audio.
- **Agents** — live human reps who take escalations.

**The request that lands on your desk:**

> *"Customers keep calling just to pay their bill and then waiting for an agent. Let's let them pay during the IVR call."*

That sounds like a small feature. It is not. Let's walk it through Gandalf and see what's hiding.

---

## Step 0 — Decide how deep to go

**The move.** Before anything, sort the effort to the stakes with two questions: *Can we undo this cheaply?* and *How many players does it touch?*

**Applied.** Taking payments moves real money, and it drags our systems into **PCI DSS** — the *Payment Card Industry Data Security Standard*, the set of rules that governs anyone who touches card numbers. Once you're in scope, getting out is slow and audited. So this is **hard to undo**. And it touches customers, telephony, APIs, the database, the pipeline, finance, security, and compliance — clearly **wide**.

> **Depth: Deep.** Every step, full Pattern Check, a payoff matrix, and a recorded decision. This is exactly the kind of change the framework exists for.

---

## Step 1 — Name the outcome (not the feature)

**The move.** Describe the change in the world you want, not the thing to build. A feature is a solution in disguise; naming it early throws away alternatives.

**Applied.** The request says "let them pay in the IVR." That's already a solution. The *outcome* is broader:

> A customer can settle what they owe during a phone call — quickly, confirmed, and accessibly — **without any human or any system of ours ever touching their raw card number**, and **without a dropped call ever causing a double charge.**

Notice what just happened. By stating the outcome carefully, we baked two hard requirements into the very definition of "done" — *no raw card data in our systems* (a compliance outcome) and *no double charges* (a reliability outcome). Neither was in the original request. A feature-list PRD would have written "add a payment menu" and discovered both of these the hard way.

**Status: Core.** This is the yardstick every later step is measured against.

---

## Step 2 — List the players

**The move.** Write down everyone affected or who will react, in four buckets, including the ones who can't speak up: non-human systems and future features.

**Applied.**

- **People:** the customer (audio-only, possibly in public, possibly stressed); the agent (for assisted flows); the on-call engineer; finance/reconciliation staff.
- **Technical:** the IVR platform; the telephony carrier; the orchestration APIs; the billing database; the data pipeline; **a payment gateway** (a new player — the PCI-compliant service that will actually process cards); call recording.
- **Organizational:** the security/fraud team; compliance/legal; finance; the telephony vendor; the gateway vendor.
- **Future:** autopay/recurring billing; refunds; an AI voice agent that may handle calls later; the analytics team building payment dashboards.

> **🔎 Discovered:** call recording is a player. IVR calls are often recorded for quality — and if a customer reads their card number aloud, that recording now contains card data and is in PCI scope. We hadn't thought about recording at all. It surfaced just by listing players.

**Status: Core.**

---

## Step 3 — Find the incentives, and circle the conflicts

**The move.** Write what each player is optimizing, then mark every pair whose goals collide. Each conflict is a hidden requirement.

**Applied.**

| Player | Optimizes for | |
|---|---|---|
| Customer | Speed, privacy, "did it work?" certainty | |
| Compliance | Smallest possible PCI scope | |
| Security/fraud | Stopping stolen-card abuse | |
| Finance | Every payment reconciles to the penny | |
| Data pipeline | Rich event data for analytics | |
| Telephony carrier | Call stability, low latency | |
| Agent | Getting the customer paid quickly | |

Now the collisions:

- **Pipeline (wants rich data) × Compliance (no card data anywhere):** the pipeline must carry payment *events* — amount, status, a token — but **never the card number**. → Requirement: tokenization, and a pipeline schema that is physically incapable of carrying a PAN (the *Primary Account Number*, i.e. the card number).
- **Agent (wants to help) × Compliance (agent must not hear the card):** if an agent reads the card aloud or types it, the agent, their screen, and the recording all enter scope. → Requirement: the agent must be able to *help the customer pay* without ever perceiving the card digits.
- **Customer (wants it fast) × Security (must verify it's really them):** payment without identity checks invites fraud; too much checking makes people give up. → Requirement: a verification step calibrated to be firm but quick.

> **🔎 Discovered:** three concrete requirements — tokenization, agent-blind capture, and calibrated auth — none of which were requested. They came purely from noticing whose goals fight.

**Status: Core.**

---

## Step 4 — Understand today's equilibrium

**The move.** Ask why the system behaves the way it does today, and what holds that in place. Don't tear down a fence before you know why it's there — and remember a change only sticks if the *new* state is stable.

**Applied.** Today, customers who want to pay by phone get transferred to an agent, who takes the card manually. Why does this exist? Because there was never an automated capture path. It's clumsy and it puts agents in PCI scope — but it persists for a reason worth respecting: **some customers genuinely can't use the web or app** (no smartphone, accessibility needs, low connectivity), and the agent path is the only one that serves them.

> **🔎 Discovered (Chesterton's fence):** we cannot simply delete the agent path. Whatever we build must keep an accessible, human-backed route for customers who can't self-serve — otherwise we'll have "fixed" payments while abandoning a real segment of callers.

**Status: Recommended** (here it's load-bearing, because we're changing existing behavior).

---

## Step 5 — Lay out at least two options

**The move.** Force at least two genuinely different approaches, so you can see what each costs.

**Applied.**

- **Option A — IVR self-service with DTMF masking.** The customer keys their card on the phone. The tones are *masked* — suppressed so they never reach the agent, the recording, or our servers — and routed straight to the payment gateway. We get back only a token and a result. This keeps almost everything *out* of PCI scope.
- **Option B — Agent-assisted with DTMF suppression.** The agent stays on the line for help, but when it's time to pay, the customer keys the card while the agent's audio is suppressed; the agent never hears the digits and just sees "paid / declined."
- **Option C — SMS payment link.** The IVR sends a text with a secure web link; the customer pays on the web. Moves card capture entirely off the phone.

**Status: Core.** ("At least two" is non-negotiable; we have three.)

---

## Step 6 — Run the Strategic Pattern Check

**The move.** This is the engine. Run eight yes/no triggers. Each "yes" matches your change to a known strategic shape and hands you its known fixes — so you inherit solutions instead of discovering them in an incident. You don't *solve* anything; you recognize the shape.

**Applied.** Six of the eight fire hard.

| Trigger | Fires? | The shape | The fix it hands us |
|---|---|---|---|
| 1. Could someone misuse this, and see our defenses first? | **Yes** | Adversarial (the attacker probes your weakest point) | Fraudsters use IVRs to *test stolen cards* — small charges to see what works. Add velocity/rate limits, cap attempts per call and per card, and **never let the flow reveal whether a card is valid** (don't be a free card-checking oracle). |
| 2. Is a shared resource used by many, each for themselves? | **Yes** | The commons | **PCI scope is itself a shared liability** — one careless flow capturing card data pollutes scope for the whole platform. The gateway and telephony trunks are shared too. → A single owned, masked capture path; quotas on the trunk. |
| 3. Are we handing behavior to a party with different goals? | **Yes** | Delegation (principal–agent) | We delegate the actual card handling to a payment gateway, and assisted flows to human agents. → Use a certified gateway; design so the agent *physically cannot* capture the card. |
| 4. Must many teams agree on one format? | **Yes** | Coordination | The IVR, APIs, and pipeline must agree on one payment-event shape (token, amount, status, idempotency key). → Publish that schema first, before building any consumer. |
| 5. Are we making a promise others build on? | **Yes** | Commitment | Our PCI attestation and a payment-availability SLA are promises auditors and customers rely on. → Version the payment API; document what we will and won't store; make breaking it costly and visible. |
| 6. Same players again and again? | **Yes** | Repeated game | Same gateway, same auditor every year, same internal teams. → Pay for the clean, properly-scoped design now; a shortcut that "passes this year" costs trust and rework every year after. |
| 7. Does one side know more than the other? | partial | Asymmetric info | The customer can't *see* whether payment succeeded if the call drops. → Always confirm by audio **and** an SMS/email receipt. |
| 8. Are we setting the rules? | **Yes** | Mechanism design | We design the flow. → Make the **compliant path the default and easiest path**: masked capture on by default, so no agent or engineer is ever tempted to "just read me the number." |

> **🔎 Discovered:** the *card-testing* attack (trigger 1), the *PCI-scope-as-commons* insight (trigger 2), the *no-validity-oracle* rule, and the schema-first coordination need — all surfaced by eight quick questions, each with a known countermeasure attached.

**Status: Core** (this is a Deep change).

---

## Step 7 — Predict reactions, trace the ripple

**The move.** For each player, what's their best response once this exists? Then follow consequences out to the second and third order, where the expensive surprises live.

**Applied — the most important ripple:**

- **First-order:** the customer keys their card and pays during the call.
- **Second-order:** phone calls *drop*. A call can disconnect right after the gateway charges the card but before we play the "you're all set" confirmation. The customer has no idea if it worked. They call back and **pay again.**
- **Third-order:** now we have **double charges**, angry customers, chargebacks (which carry fees and hurt our standing with the gateway), and manual refunds clogging finance.

The fix surfaces immediately and was invisible at Step 1:

> **🔎 Discovered:** every payment attempt needs an **idempotency key** — a unique token for that attempt so the gateway recognizes a retry and refuses to charge twice — plus a **"check my last payment" path** so a customer who got disconnected can confirm status instead of re-paying.

**Other reactions worth noting:** a declined card makes the customer retry → that retry loop is also the fraudster's tool, so retries must be capped (ties back to Pattern 1). The pipeline, on receiving payment events, will try to store everything → it must be built to *reject* any field that looks like a PAN.

**Status: Core.**

---

## Step 8 — Write down the constraints

**The move.** Capture the hard boundaries. An option that violates one isn't a worse choice — it's not a choice.

**Applied.**

- **Compliance:** PCI DSS. Card data must never reach the IVR app, agents, recordings, our databases, or the pipeline. (This eliminates any option that keys the card "through" our systems unmasked.)
- **Security:** fraud velocity limits; capped attempts; no validity oracle.
- **Telephony:** masking has to work reliably across carriers and survive moderate latency; entering 16 digits by keypad needs generous timeouts.
- **Accessibility:** keep a human-backed path (from Step 4); support customers who key slowly or need to repeat.
- **Vendor:** gateway rate limits and supported regions/currencies.
- **Finance:** every payment must reconcile against the gateway and the billing database.

**Status: Core.**

---

## Step 9 — Make the decision (and record it)

**The move.** Build a trade-off table across your options. For a genuinely interactive decision, sketch a small payoff matrix. Record the choice as a decision record (an **ADR** — *Architecture Decision Record*) because it's hard to undo.

**Trade-off table:**

| | A — IVR self-service (masked) | B — Agent-assisted (suppressed) | C — SMS link |
|---|---|---|---|
| PCI scope | **Smallest** | Small | Smallest (off-phone) |
| Accessibility | Good | **Best** (human help) | Poor (needs smartphone) |
| Speed for customer | **Fast** | Medium | Slow (context switch) |
| Build effort | Medium | Medium | **Low** |
| Serves "can't use web" segment | Yes | **Yes** | No |

**The interactive decision** — should masking be mandatory, or "available"? Here a payoff matrix clarifies it. Our move down the side; what an agent under time pressure does across the top:

| Platform choice ↓ \ Agent will… → | Follow the safe path | Take a shortcut |
|---|---|---|
| **Mask by default, no override** | Compliant | Still compliant (no shortcut exists) |
| Make masking optional | Compliant | **Card exposed → scope breach** |

Mandatory masking is the **dominant** choice — at least as good no matter what the agent does, and strictly safer if anyone is ever tempted to cut a corner. This is mechanism design (Pattern 8) in action.

> **Decision:** Ship **Option A** (IVR self-service, masked, tokenized, idempotent) as the primary path, with **Option B** as the accessible human-backed fallback. Masking is **mandatory**, with no override. Recorded as an ADR, since the PCI scoping and tokenization choices are expensive to reverse.

**Status: Core** for a Deep change.

---

## Step 10 — Roll out reversibly

**The move.** Move toward the design in steps you can undo. Don't bet everything on being right the first time.

**Applied.**

1. **Shadow:** route a handful of internal test numbers through the masked flow end to end, charging test cards. Verify nothing card-shaped reaches recordings, logs, or the pipeline.
2. **Flag + canary:** enable for a small customer segment (say one region or 5% of billing calls) behind a feature flag. Watch the metrics below.
3. **Keep the fallback:** the agent-assisted path stays available the whole time, so no customer is stranded.
4. **Ramp, then retire:** expand region by region; only once self-service is healthy do we deprecate the old "agent reads the card aloud" practice — on a published date.

**Status: Strongly recommended** (effectively required here, given money and compliance are involved).

---

## Step 11 — Decide how you'll measure success

**The move.** Pick the few numbers that prove it worked — or warn you early. Tie each to the outcome (Step 1) and the incentives (Step 3).

**Applied.**

- **Payment completion rate** (started vs. successfully paid) — the core outcome.
- **Drop-during-payment rate** and **double-charge incidents** — the latter must hold at **zero**; it's the early warning that idempotency is failing.
- **Decline rate** and **chargeback/fraud rate** — watches the adversarial risk.
- **PCI scope** — confirmed by audit that the IVR app, agents, recordings, and pipeline remain *out* of scope.
- **Reconciliation mismatch rate** — finance's number; should be ~0.
- **Fallback-to-agent rate** — tells us whether self-service is actually usable.

**Status: Core.**

---

# Part 2 — Assembling the PRD

Discovery is done. Now the PRD almost writes itself, because every section maps to a step you've already worked through. Here is the document that falls out.

---

> ## PRD: Pay-by-Phone in the IVR
>
> **Summary.** Enable customers to pay their bill during an IVR call via masked, tokenized card entry, with an agent-assisted fallback. No human or CustomerCo system ever handles raw card data. *(Step 1)*
>
> **Problem & desired outcome.** Customers calling to pay are forced to wait for an agent, and the current agent-reads-the-card practice puts staff and recordings in PCI scope. We want customers to settle balances during the call — fast, confirmed, accessible — with no raw card data in our systems and no double charges on dropped calls. *(Step 1)*
>
> **Stakeholders.** Customers, agents, on-call, finance; IVR platform, telephony carrier, orchestration APIs, billing DB, data pipeline, payment gateway, call recording; security, compliance, finance, vendors; future autopay/refunds/AI-agent. *(Step 2)*
>
> **Goals**
> - A customer can pay during the call without reaching an agent.
> - Card data never touches the IVR app, agents, recordings, DB, or pipeline.
> - A dropped call never produces a double charge.
> - An accessible, human-backed path remains for customers who can't self-serve. *(Steps 1, 3, 4)*
>
> **Non-goals**
> - Recurring/autopay billing (future).
> - Refund initiation by phone (future).
>
> **Functional requirements**
> 1. Masked DTMF card entry routed directly to the payment gateway; tokenized result only. *(Step 5A, 6·3)*
> 2. Mandatory masking with no agent override. *(Step 9)*
> 3. Identity verification before payment, calibrated to be quick. *(Step 3)*
> 4. Idempotency key per attempt; gateway rejects duplicate charges. *(Step 7)*
> 5. "Check my last payment" path for disconnected callers. *(Step 7)*
> 6. Audio confirmation **and** SMS/email receipt. *(Step 6·7)*
> 7. Capped payment attempts per call and per card; no card-validity oracle. *(Step 6·1)*
> 8. Agent-assisted fallback with audio suppression during entry. *(Step 5B, 4)*
> 9. Payment-event schema (token, amount, status, idempotency key) that cannot carry a PAN. *(Steps 3, 6·4)*
>
> **Constraints & compliance.** PCI DSS scope minimized and audited; fraud velocity limits; carrier-agnostic masking with generous keypad timeouts; gateway region/rate limits; finance reconciliation to the penny. *(Step 8)*
>
> **Chosen approach & alternatives.** Primary: masked IVR self-service (Option A). Fallback: agent-assisted (Option B). Considered and deferred: SMS link (Option C) — poor accessibility for the can't-use-web segment. See ADR-payments-01. *(Steps 5, 9)*
>
> **Key risks & mitigations**
> - *Card testing / fraud* → velocity limits, attempt caps, no validity oracle. *(6·1)*
> - *Double charge on drop* → idempotency + status lookup. *(7)*
> - *Scope creep into recordings/pipeline* → mandatory masking, PAN-incapable schema. *(6·2, 9)*
> - *Stranding non-web customers* → preserve agent path. *(4)*
>
> **Rollout.** Shadow on test numbers → flagged canary by region → ramp → retire manual card-reading on a published date. Fallback live throughout. *(Step 10)*
>
> **Success metrics.** Completion rate; drop-during-payment and double-charge (=0); decline & chargeback rate; PCI scope (audited out); reconciliation mismatch (~0); fallback-to-agent rate. *(Step 11)*
>
> **Open questions.** Which gateway/regions for phase 1? Verification method (account PIN vs. knowledge check)? Retention policy for payment *events* in the pipeline?

---

# What a feature-list PRD would have missed

If someone had simply written *"add a payment option to the IVR menu,"* here's what would have shown up later as incidents, audit findings, or angry calls — every one of which the framework caught *before* a line of code:

- Card data leaking into **call recordings** and the **data pipeline** (Step 2, 3) — a PCI breach.
- **Double charges** from dropped calls (Step 7) — chargebacks and refunds.
- **Card-testing fraud** through the payment loop (Step 6·1).
- Accidentally building a **card-validity oracle** for attackers (Step 6·1).
- **Stranding** customers who can't use the web by deleting the agent path (Step 4).
- No way for a disconnected customer to know if they **already paid** (Step 7).
- Agents and their screens **dragged into PCI scope** (Step 3, 9).

The feature was never "a payment menu." It was a strategic situation with adversaries, shared liabilities, promises, and reactions — and the framework's job was to read that situation before committing.

---

## How to use this tutorial on your own feature

1. Copy the eleven step headers into an empty doc.
2. Answer each one for your feature, in order — don't skip; each answer feeds the next.
3. Pay special attention to **Step 3** (circle the conflicts) and **Step 6** (the Pattern Check) — that's where hidden requirements surface.
4. When you're done, assemble the PRD exactly as in Part 2: each section is just the output of a step.
5. The goal isn't a bigger PRD. It's a decision you can defend — and one anyone, from intern to senior engineer, can follow.
