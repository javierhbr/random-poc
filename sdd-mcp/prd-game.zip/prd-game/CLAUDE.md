# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

This repo is **Gandalf — the Game-Theoretic Discovery Framework** (named for the wizard who sees the
larger picture and *advises rather than commands*): a method (and the artifacts that
teach/deliver it) for reading a proposed software change as a strategic game — players, incentives,
conflicts, reactions, equilibria — *before* committing, to surface requirements a feature-list PRD
misses. It is **content + Skill packages**, not an application: there is no build, test, or lint
step, and this is **not a git repository**. "Running" Gandalf means a model loads a Skill and
facilitates a discovery session with a user.

Read [INDEX.md](INDEX.md) first — it is the authoritative map of the seven numbered directories and
how they relate.

## The one rule that governs everything: GUIDE, DON'T DECIDE

Every Skill, agent, and doc here enforces a single prime directive: **the user does the thinking;
the tooling only guides, challenges, and records.** When editing any SKILL.md, agent, or framework
file, preserve this — do not add behavior that auto-fills the analysis. Concretely:

- Never populate players, incentives, conflicts, chosen strategy, or the final decision *for* the
  user. Surface candidates **as questions**, capped at **three at a time**.
- Never assign a number/weight/priority/value to an actor — ask the user, then ask them to justify.
- Always **reflect the impact** of a choice before recording it.
- The deliverable is the user's *understanding*; the PRD/dossier is "just the residue."

The canonical statement lives in [06-skill-single/gandalf/SKILL.md](06-skill-single/gandalf/SKILL.md)
("The prime directive") and the suite README's "two rules" section.

## Architecture: one method, two Skill generations

The method is defined once and packaged two ways. When changing the method, decide which layer you
are touching and keep the others consistent.

**The method (specs, human-readable):**
- `01-framework/Gandalf-v2.md` — operational reference: the 11-step spine, the depth gate, the
  8-pattern "Pattern Check."
- `02-paper/Gandalf-paper.md` — the teaching paper (game theory from zero, per-step rationale).
- `04-tutorial/` — a worked IVR-payments example showing the framework finding hidden requirements.
- `03-explainer/`, `05-wizards/` — HTML visualizations (open in a browser; no server needed).

**Skill generation 1 — single facilitator** (`06-skill-single/gandalf/`):
- One Skill runs the entire 11-step loop. Source of truth at runtime is two files the Skill loads:
  `framework.yaml` (the rulebook — depth gate, player categories, patterns, all 11 steps with
  Socratic prompts + skip-costs, PRD assembly map) and `game_state.template.yaml` (the resumable
  save file, copied to `game_state.yaml` per session).
- `references/example_session.md` calibrates the guide-don't-decide *tone* — read it before editing
  facilitation prose.

**Skill generation 2 — the suite** (`07-suite/gandalf-suite/`): the single Skill split into stages.
- `core/framework.yaml` (rulebook, YAML) + `core/state.schema.json` (game state, **JSON**,
  validated). Rationale for the YAML/JSON split is documented in the suite README: rulebook is
  human-edited and stable → YAML; state accumulates large free-text blocks and is read/written
  programmatically → JSON.
- `skills/`: `gandalf-setup` (load sources, set depth, identify the board) → `gandalf-play` (run steps,
  summon agents) → `gandalf-decide` (weigh options, write ADR stubs, export the dossier).
  `gandalf-export-wizard` converts a played `game_state.json` into a `gandalf.config.json`.
- `agents/`: challenger personas the user plays *against* — `judge` (referee/coverage),
  `security-analyst` (attacks the design), `risk-analyst` (surfaces assumptions/ripples).
- `wizard/gandalf-game-configurable.html` — a self-contained copy of the config-driven wizard.

**The flow:** `gandalf-setup → gandalf-play → gandalf-decide` produces `discovery-dossier.md` +
`game_state.json`. **The suite deliberately does not write a PRD** — it produces a *dossier* of
findings the user turns into a PRD elsewhere. (The single Skill's `assemble` does draft a PRD.)
Don't conflate the two outputs when editing.

## The runtime data contract (most likely thing to break)

`game_state` is the source of truth for a session and is **written after every step**, not just at
the end, so sessions are always resumable. If you change a field, change it in lockstep across:

- the single Skill: `06-skill-single/gandalf/game_state.template.yaml`
- the suite: `07-suite/gandalf-suite/core/state.schema.json` (+ keep `state.example.json` valid)
- the wizard config path: `07-suite/gandalf-suite/core/wizard.config.schema.json` and any
  `gandalf-export-wizard` mapping that produces `gandalf.config.json`

The depth gate (Step 0) selects which steps are required: `light` = steps [1,2,3,5,10,11];
`standard`/`deep` = all 11. The 8 strategic patterns and the 11 steps are defined in each
generation's `framework.yaml` — edit the rulebook, not the per-step prose in SKILL.md, when
changing the method itself.

## Working conventions

- **Two-way edits.** A change to the method usually touches at least: the spec in `01-framework/`,
  the relevant `framework.yaml`, and the SKILL.md prose that references it. Note in your summary
  which layers you synced and which you intentionally did not.
- The wizard replays a user's *own* recorded choices — never fabricate decoy options in a generated
  config. Only the built-in IVR sample is an authored teaching quiz.
